"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Boxes, FolderKanban, BookMarked } from "lucide-react";
import { cx } from "@/components/ui";
import { ThemeToggle } from "@/components/ThemeToggle";
import { BIMCOST_VERSION } from "@/lib/version";

export function Nav() {
  const pathname = usePathname();
  const links = [
    { href: "/", label: "Proyectos", icon: FolderKanban, exact: true },
    { href: "/catalogo", label: "Catálogo maestro", icon: BookMarked, exact: false },
  ];
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-ink-900/85 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-[1500px] items-center justify-between px-4 sm:px-6">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg border border-acc/40 bg-acc/10 text-acc">
            <Boxes size={17} />
          </span>
          <span className="leading-none">
            <span className="block text-[13px] font-bold tracking-tight text-white">
              BIMCost <span className="text-acc">Quantity</span>
            </span>
            <span className="mt-0.5 block text-[9.5px] font-medium uppercase tracking-[0.18em] text-fog">
              Evidencia → Cantidad validada · v{BIMCOST_VERSION}
            </span>
          </span>
        </Link>
        <nav className="flex items-center gap-1">
          {links.map((l) => {
            const active = l.exact ? pathname === l.href : pathname.startsWith(l.href);
            return (
              <Link
                key={l.href}
                href={l.href}
                className={cx(
                  "flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors",
                  active ? "bg-ink-750 text-acc" : "text-mist hover:bg-ink-800 hover:text-white"
                )}
              >
                <l.icon size={14} />
                {l.label}
              </Link>
            );
          })}
          <span className="mx-1 h-5 w-px bg-line" />
          <ThemeToggle />
        </nav>
      </div>
    </header>
  );
}
