"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Search, Check, Plus, Loader2, CircleDollarSign } from "lucide-react";
import { Btn, Chip, Input, cx } from "@/components/ui";
import { api, METHOD_META, fmt } from "@/lib/client";
import { ActivityForm, type CatalogActivityFull } from "./ActivityForm";

export type CatalogActivity = CatalogActivityFull & { scopeActive?: boolean };

/**
 * Selector de actividades con búsqueda en el servidor: soporta catálogos
 * de miles de ítems sin cargarlos todos en el navegador.
 */
export function ActivityPicker({
  onPick,
  filterIds,
  onlyIds,
  placeholder,
  allowCreate,
  createSuggestion,
}: {
  onPick: (a: CatalogActivity) => void;
  filterIds?: Set<string>;
  onlyIds?: Set<string>;
  placeholder?: string;
  allowCreate?: boolean;
  createSuggestion?: { name?: string; ifcClasses?: string[]; unit?: string; method?: string; keywords?: string[] };
}) {
  const [rows, setRows] = useState<CatalogActivity[]>([]);
  const [total, setTotal] = useState(0);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const load = useCallback(async (needle: string) => {
    setLoading(true);
    try {
      const d = await api<{ flat: CatalogActivity[]; total: number }>(
        `/api/catalog?q=${encodeURIComponent(needle)}&limit=120&onlyActive=1`
      );
      setRows(d.flat);
      setTotal(d.total);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(""); }, [load]);

  const onSearch = (v: string) => {
    setQ(v);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => load(v), 220);
  };

  const visible = rows
    .filter((a) => !filterIds || !filterIds.has(a.id))
    .filter((a) => !onlyIds || onlyIds.has(a.id));

  if (creating) {
    return (
      <ActivityForm
        suggest={createSuggestion}
        onCancel={() => setCreating(false)}
        onCreated={(a) => { setCreating(false); onPick(a as CatalogActivity); }}
      />
    );
  }

  return (
    <div>
      <div className="mb-2 flex gap-2">
        <div className="relative flex-1">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-fog" />
          <Input
            value={q}
            onChange={(e) => onSearch(e.target.value)}
            placeholder={placeholder ?? "Buscar por código, nombre o capítulo…"}
            className="pl-8"
            autoFocus
          />
          {loading && <Loader2 size={13} className="absolute right-3 top-1/2 -translate-y-1/2 animate-spin text-fog" />}
        </div>
        {allowCreate && (
          <Btn variant="primary" size="sm" icon={Plus} onClick={() => setCreating(true)}>
            Crear actividad
          </Btn>
        )}
      </div>

      <div className="max-h-80 overflow-y-auto rounded-lg border border-line">
        {visible.length === 0 ? (
          <div className="px-4 py-6 text-center">
            <p className="text-xs text-mist">Sin actividades que coincidan con «{q}».</p>
            {allowCreate && (
              <Btn className="mt-3" size="sm" variant="primary" icon={Plus} onClick={() => setCreating(true)}>
                Crear esta actividad en el catálogo
              </Btn>
            )}
          </div>
        ) : (
          visible.map((a) => (
            <button
              key={a.id}
              onClick={() => onPick(a)}
              className="group flex w-full items-center justify-between gap-3 border-b border-line/50 px-3 py-2 text-left transition-colors last:border-0 hover:bg-ink-750"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="shrink-0 font-mono text-[11px] font-bold text-acc">{a.code}</span>
                  <span className="truncate text-xs font-medium text-slate-100">{a.name}</span>
                </div>
                <p className="mt-0.5 truncate text-[10.5px] text-fog">
                  {a.chapterName} · {a.sectionName}
                  {a.unitPrice > 0 && (
                    <span className="ml-1.5 text-emerald-300/80">· ${fmt(a.unitPrice, 0)}</span>
                  )}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-1.5">
                {a.unitPrice > 0 && <CircleDollarSign size={12} className="text-emerald-400/70" />}
                <Chip className="border-line-strong bg-ink-750 font-mono">{a.unit}</Chip>
                <Chip className="border-violet-400/30 bg-violet-400/10 text-violet-300">
                  {METHOD_META[a.method]?.short ?? a.method}
                </Chip>
                <Check size={14} className={cx("text-emerald-400 opacity-0 transition-opacity group-hover:opacity-100")} />
              </div>
            </button>
          ))
        )}
      </div>
      <p className="mt-1.5 text-[10.5px] text-fog">
        {visible.length} de {total} actividades del catálogo maestro {q ? `· filtrando «${q}»` : "· escriba para buscar"}
      </p>
    </div>
  );
}
