"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Building2, FileText, FolderPen, Save, Upload, ExternalLink, RotateCcw } from "lucide-react";
import { Alert, Btn, Card, Field, Input, SectionTitle, Spinner, Textarea } from "@/components/ui";
import { api } from "@/lib/client";

interface DocumentTemplate {
  budgetTitle: string;
  budgetSubtitle: string;
  budgetIntroduction: string;
  budgetScope: string;
  reportTitle: string;
  reportSubtitle: string;
  reportIntroduction: string;
  reportScope: string;
  sourcesTitle: string;
  decisionsTitle: string;
  observationsTitle: string;
  footerText: string;
  preparedByLabel: string;
  reviewedByLabel: string;
  showCompany: boolean;
  showPrices: boolean;
  showAIU: boolean;
}

const DEFAULT_DOCS: DocumentTemplate = {
  budgetTitle: "Presupuesto preliminar",
  budgetSubtitle: "Estructura de cantidades y valores de referencia — sin APU",
  budgetIntroduction: "El presente documento consolida las cantidades de obra validadas profesionalmente a partir de modelos BIM, hojas de cálculo y mediciones manuales.",
  budgetScope: "Los valores unitarios son referencias del catálogo maestro. Este documento no constituye un análisis de precios unitarios: no desagrega materiales, mano de obra, equipos ni desperdicios.",
  reportTitle: "Informe de trazabilidad de cantidades",
  reportSubtitle: "Evidencia BIM, reglas de medición y decisiones profesionales",
  reportIntroduction: "Este informe documenta cómo se obtuvieron las cantidades del proyecto y resume las decisiones profesionales que modificaron, rechazaron o complementaron la evidencia original.",
  reportScope: "BIMCost Quantity determina qué actividades participan, cuánto se mide y de dónde proviene cada cantidad. No realiza APU, programación ni modelado BIM.",
  sourcesTitle: "Fuentes utilizadas",
  decisionsTitle: "Decisiones con observaciones",
  observationsTitle: "Cantidades que requieren atención",
  footerText: "Documento generado con BIMCost Quantity.",
  preparedByLabel: "Elaboró",
  reviewedByLabel: "Revisó / Aprobó",
  showCompany: true,
  showPrices: true,
  showAIU: true,
};

export function DocumentosConfig({ projectId, actor, onChanged }: { projectId: string; actor: string; onChanged: () => void }) {
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [project, setProject] = useState({ name: "", client: "", location: "", description: "" });
  const [company, setCompany] = useState<Record<string, string>>({});
  const [settings, setSettings] = useState<Record<string, unknown>>({});
  const [docs, setDocs] = useState<DocumentTemplate>(DEFAULT_DOCS);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await api<{
        project: {
          name: string; client: string | null; location: string | null; description: string | null;
          company: Record<string, string> | null;
          settings: (Record<string, unknown> & { documents?: Partial<DocumentTemplate> }) | null;
        };
      }>(`/api/projects/${projectId}`);
      setProject({
        name: d.project.name,
        client: d.project.client ?? "",
        location: d.project.location ?? "",
        description: d.project.description ?? "",
      });
      setCompany(d.project.company ?? {});
      const st = d.project.settings ?? {};
      setSettings(st);
      setDocs({ ...DEFAULT_DOCS, ...(st.documents ?? {}) });
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [projectId]);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      await api(`/api/projects/${projectId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...project,
          company,
          settings: { ...settings, documents: docs },
          actor: actor || undefined,
        }),
      });
      setSettings((s) => ({ ...s, documents: docs }));
      setNotice("Información del proyecto y configuración documental guardadas.");
      onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const readLogo = (file: File) => {
    if (file.size > 2 * 1024 * 1024) {
      setError("El logo no debe superar 2 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setCompany((c) => ({ ...c, logo: String(reader.result) }));
    reader.readAsDataURL(file);
  };

  if (loading) return <Spinner label="Cargando configuración documental…" />;

  return (
    <div className="space-y-5 bc-fade-up">
      <SectionTitle
        title="Proyecto y documentos"
        desc="Modifique la información del proyecto y todos los textos principales antes de generar el presupuesto preliminar o el informe de trazabilidad."
        right={
          <div className="flex gap-2">
            <Btn icon={RotateCcw} onClick={() => setDocs(DEFAULT_DOCS)}>Restablecer textos</Btn>
            <Link href={`/proyectos/${projectId}/documentos`}>
              <Btn icon={ExternalLink}>Vista previa</Btn>
            </Link>
            <Btn variant="primary" icon={Save} loading={busy} onClick={save}>Guardar cambios</Btn>
          </div>
        }
      />

      {notice && <Alert tone="ok">{notice}</Alert>}
      {error && <Alert tone="error">{error}</Alert>}

      <Card className="p-5">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-white"><FolderPen size={15} className="text-acc" /> Información del proyecto</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Nombre del proyecto"><Input value={project.name} onChange={(e) => setProject({ ...project, name: e.target.value })} /></Field>
          <Field label="Cliente / contratante"><Input value={project.client} onChange={(e) => setProject({ ...project, client: e.target.value })} /></Field>
          <Field label="Ubicación"><Input value={project.location} onChange={(e) => setProject({ ...project, location: e.target.value })} /></Field>
          <Field label="Descripción / objeto del proyecto"><Textarea value={project.description} onChange={(e) => setProject({ ...project, description: e.target.value })} /></Field>
        </div>
      </Card>

      <Card className="p-5">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-white"><Building2 size={15} className="text-acc" /> Empresa y responsable</h3>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Empresa"><Input value={company.name ?? ""} onChange={(e) => setCompany({ ...company, name: e.target.value })} /></Field>
          <Field label="NIT / identificación"><Input value={company.nit ?? ""} onChange={(e) => setCompany({ ...company, nit: e.target.value })} /></Field>
          <Field label="Dirección"><Input value={company.address ?? ""} onChange={(e) => setCompany({ ...company, address: e.target.value })} /></Field>
          <Field label="Teléfono"><Input value={company.phone ?? ""} onChange={(e) => setCompany({ ...company, phone: e.target.value })} /></Field>
          <Field label="Correo"><Input value={company.email ?? ""} onChange={(e) => setCompany({ ...company, email: e.target.value })} /></Field>
          <Field label="Responsable"><Input value={company.responsible ?? ""} onChange={(e) => setCompany({ ...company, responsible: e.target.value })} /></Field>
          <Field label="Cargo"><Input value={company.role ?? ""} onChange={(e) => setCompany({ ...company, role: e.target.value })} /></Field>
          <Field label="Matrícula profesional"><Input value={company.license ?? ""} onChange={(e) => setCompany({ ...company, license: e.target.value })} /></Field>
        </div>
        <div className="mt-3 flex items-center gap-3">
          <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-line-strong bg-ink-800 px-3 py-2 text-xs text-mist hover:border-acc/50">
            <Upload size={13} /> {company.logo ? "Cambiar logo" : "Subir logo"}
            <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e) => e.target.files?.[0] && readLogo(e.target.files[0])} />
          </label>
          {company.logo && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={company.logo} alt="Logo de empresa" className="h-12 max-w-48 rounded border border-line bg-white object-contain p-1" />
          )}
          {company.logo && <button className="text-xs text-rose-300 hover:underline" onClick={() => setCompany({ ...company, logo: "" })}>Quitar logo</button>}
        </div>
      </Card>

      <Card className="p-5">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-white"><FileText size={15} className="text-acc" /> Presupuesto preliminar</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Título"><Input value={docs.budgetTitle} onChange={(e) => setDocs({ ...docs, budgetTitle: e.target.value })} /></Field>
          <Field label="Subtítulo"><Input value={docs.budgetSubtitle} onChange={(e) => setDocs({ ...docs, budgetSubtitle: e.target.value })} /></Field>
          <Field label="Texto introductorio"><Textarea value={docs.budgetIntroduction} onChange={(e) => setDocs({ ...docs, budgetIntroduction: e.target.value })} /></Field>
          <Field label="Alcance / descargo"><Textarea value={docs.budgetScope} onChange={(e) => setDocs({ ...docs, budgetScope: e.target.value })} /></Field>
        </div>
      </Card>

      <Card className="p-5">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-white"><FileText size={15} className="text-acc" /> Informe de trazabilidad</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Título"><Input value={docs.reportTitle} onChange={(e) => setDocs({ ...docs, reportTitle: e.target.value })} /></Field>
          <Field label="Subtítulo"><Input value={docs.reportSubtitle} onChange={(e) => setDocs({ ...docs, reportSubtitle: e.target.value })} /></Field>
          <Field label="Texto introductorio"><Textarea value={docs.reportIntroduction} onChange={(e) => setDocs({ ...docs, reportIntroduction: e.target.value })} /></Field>
          <Field label="Declaración de alcance"><Textarea value={docs.reportScope} onChange={(e) => setDocs({ ...docs, reportScope: e.target.value })} /></Field>
          <Field label="Título de fuentes"><Input value={docs.sourcesTitle} onChange={(e) => setDocs({ ...docs, sourcesTitle: e.target.value })} /></Field>
          <Field label="Título de decisiones"><Input value={docs.decisionsTitle} onChange={(e) => setDocs({ ...docs, decisionsTitle: e.target.value })} /></Field>
          <Field label="Título de observaciones"><Input value={docs.observationsTitle} onChange={(e) => setDocs({ ...docs, observationsTitle: e.target.value })} /></Field>
          <Field label="Pie de página"><Input value={docs.footerText} onChange={(e) => setDocs({ ...docs, footerText: e.target.value })} /></Field>
          <Field label="Etiqueta de firma 1"><Input value={docs.preparedByLabel} onChange={(e) => setDocs({ ...docs, preparedByLabel: e.target.value })} /></Field>
          <Field label="Etiqueta de firma 2"><Input value={docs.reviewedByLabel} onChange={(e) => setDocs({ ...docs, reviewedByLabel: e.target.value })} /></Field>
        </div>
        <div className="mt-3 flex flex-wrap gap-4">
          {[
            ["showCompany", "Mostrar empresa y logo"],
            ["showPrices", "Mostrar precios en presupuesto"],
            ["showAIU", "Mostrar AIU e IVA"],
          ].map(([key, label]) => (
            <label key={key} className="flex cursor-pointer items-center gap-2 text-xs text-mist">
              <input type="checkbox" checked={Boolean(docs[key as keyof DocumentTemplate])}
                onChange={(e) => setDocs({ ...docs, [key]: e.target.checked })} className="accent-cyan-400" />
              {label}
            </label>
          ))}
        </div>
      </Card>

      <div className="flex justify-end">
        <Btn variant="primary" icon={Save} loading={busy} onClick={save}>Guardar toda la configuración</Btn>
      </div>
    </div>
  );
}
