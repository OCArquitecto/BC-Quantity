"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  GitCompareArrows, ShieldCheck, XCircle, Search, ScanSearch, Layers3,
  ArrowRight, CheckCircle2, Undo2, ClipboardCheck, CheckSquare, Square,
  Box as BoxIcon, TriangleAlert, CopyPlus, Sparkles,
} from "lucide-react";
import {
  Alert, Btn, Card, Chip, Empty, Modal, SectionTitle, Spinner, StatusChip, Textarea, cx,
} from "@/components/ui";
import { api, fmt, METHOD_META, STATUS_META, nuevaFecha } from "@/lib/client";
import { ActivityPicker, type CatalogActivity } from "./ActivityPicker";
import { Viewer3D, type ViewerElement } from "./Viewer3D";

interface MatchRow {
  id: string;
  runId: string;
  activityId: string | null;
  score: number;
  status: "PENDIENTE" | "PROPUESTA" | "VALIDADA" | "RECHAZADA";
  candidates: { activityId: string; code: string; name: string; unit: string; method: string; score: number; matched: string[]; classOk?: boolean }[];
  evidence: Record<string, unknown> | null;
  decidedBy: string | null;
  decidedAt: string | null;
  decisionNote: string | null;
  esCorridaActual: boolean;
  grupo: {
    id: string; groupKey: string; criteriaValues: Record<string, string>;
    elementCount: number; ifcClasses: string[]; fuentes: string[]; elementIds?: string[];
  } | null;
  actividad: CatalogActivity | null;
}

const FILTROS = ["TODAS", "PROPUESTA", "PENDIENTE", "VALIDADA", "RECHAZADA"];

export function Correspondencias({
  projectId, actor, onChanged, goTab,
}: {
  projectId: string; actor: string; onChanged: () => void; goTab: (t: "agrupacion" | "cantidades") => void;
}) {
  const [rows, setRows] = useState<MatchRow[] | null>(null);
  const [filtro, setFiltro] = useState("TODAS");
  const [busyId, setBusyId] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [pickerFor, setPickerFor] = useState<MatchRow | null>(null);
  const [noteFor, setNoteFor] = useState<MatchRow | null>(null);
  const [note, setNote] = useState("");
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [dupWarn, setDupWarn] = useState<{ match: MatchRow; activityId?: string; info: { mensaje: string; sugerencia: string } } | null>(null);
  const [viewerFor, setViewerFor] = useState<MatchRow | null>(null);
  const [viewerEls, setViewerEls] = useState<ViewerElement[] | null>(null);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [bulkNote, setBulkNote] = useState("");
  const [bulkModal, setBulkModal] = useState<"validate" | "reject" | null>(null);

  const load = useCallback(() => {
    api<{ matches: MatchRow[] }>(`/api/matches?projectId=${projectId}`).then((d) => {
      setRows(d.matches);
      setSelected(new Set());
    });
  }, [projectId]);
  useEffect(() => { load(); }, [load]);

  /* --------------------------- decisiones --------------------------- */
  const decide = async (
    m: MatchRow,
    action: "validate" | "reject" | "reopen",
    activityId?: string,
    decisionNote?: string,
    allowDuplicate?: boolean
  ) => {
    setBusyId(m.id);
    setNotice(null);
    setError(null);
    try {
      const res = await fetch(`/api/matches/${m.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, activityId, actor: actor || undefined, note: decisionNote, allowDuplicate }),
      });
      const data = await res.json();
      if (res.status === 409 && data.error === "DUPLICADO") {
        setDupWarn({ match: m, activityId, info: data.duplicado });
        return;
      }
      if (!res.ok) throw new Error(data.error || "Error al registrar la decisión");

      if (action === "validate") {
        const q = data.quantity;
        setNotice(
          q?.value !== null && q?.value !== undefined
            ? `Decisión registrada. Cantidad calculada: ${fmt(q.value)} ${q.unit} desde ${q.elementCount} elementos → queda como PROPUESTA en «Cantidades».${data.aviso ? ` Aviso: ${data.aviso}.` : ""}`
            : "Decisión registrada. La actividad requiere medición manual: complete el valor en «Cantidades»."
        );
      } else if (action === "reject") {
        setNotice("Propuesta rechazada. La decisión quedó registrada con su firma profesional.");
      } else {
        setNotice("Correspondencia reabierta para nueva decisión.");
      }
      setPickerFor(null);
      setNoteFor(null);
      setDupWarn(null);
      setNote("");
      load();
      onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusyId(null);
    }
  };

  const runBulk = async (action: "validate" | "reject") => {
    setBulkBusy(true);
    setError(null);
    try {
      const d = await api<{ validadas: number; rechazadas: number; omitidasSinActividad: number; omitidasPorDuplicado: number; totalElementosSinDato: number }>(
        "/api/matches/bulk",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ids: [...selected], action, actor: actor || undefined, note: bulkNote || undefined }),
        }
      );
      const partes: string[] = [];
      if (d.validadas) partes.push(`${d.validadas} validadas`);
      if (d.rechazadas) partes.push(`${d.rechazadas} rechazadas`);
      if (d.omitidasSinActividad) partes.push(`${d.omitidasSinActividad} omitidas por no tener actividad (decídalas una a una)`);
      if (d.omitidasPorDuplicado) partes.push(`${d.omitidasPorDuplicado} omitidas por duplicado (valide individualmente para autorizar)`);
      if (d.totalElementosSinDato) partes.push(`${d.totalElementosSinDato} elementos sin datos de medición`);
      setNotice(`Lote procesado: ${partes.join(" · ") || "sin cambios"}.`);
      setBulkModal(null);
      setBulkNote("");
      load();
      onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBulkBusy(false);
    }
  };

  /* --------------------------- visor -------------------------------- */
  const openViewer = async (m: MatchRow) => {
    setViewerFor(m);
    setViewerEls(null);
    if (!m.grupo) return;
    const d = await api<{ elements: ViewerElement[] }>(`/api/elements?projectId=${projectId}&groupId=${m.grupo.id}`);
    setViewerEls(d.elements);
  };

  /* --------------------------- filtros ------------------------------ */
  const filtered = useMemo(
    () => (rows ?? []).filter((r) => filtro === "TODAS" || r.status === filtro),
    [rows, filtro]
  );
  const counts = {
    PROPUESTA: rows?.filter((r) => r.status === "PROPUESTA").length ?? 0,
    PENDIENTE: rows?.filter((r) => r.status === "PENDIENTE").length ?? 0,
    VALIDADA: rows?.filter((r) => r.status === "VALIDADA").length ?? 0,
    RECHAZADA: rows?.filter((r) => r.status === "RECHAZADA").length ?? 0,
  };

  const selectable = filtered.filter((r) => r.status === "PROPUESTA" || r.status === "PENDIENTE");
  const allSelected = selectable.length > 0 && selectable.every((r) => selected.has(r.id));
  const toggleAll = () => {
    setSelected(allSelected ? new Set() : new Set(selectable.map((r) => r.id)));
  };
  const toggleOne = (id: string) => {
    setSelected((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  if (rows !== null && rows.length === 0) {
    return (
      <Empty
        icon={GitCompareArrows}
        title="Sin correspondencias todavía"
        hint="Ejecute primero la agrupación de evidencia. Las propuestas respetan la familia BIM de cada clase IFC, pero la decisión siempre es suya."
        action={<Btn variant="primary" onClick={() => goTab("agrupacion")}>Ir a Agrupación</Btn>}
      />
    );
  }

  return (
    <div className="space-y-5 bc-fade-up">
      <SectionTitle
        title="Correspondencias evidencia → catálogo maestro"
        desc="Una sola propuesta por grupo (nunca dos actividades para los mismos elementos). Las propuestas respetan la semántica BIM: IfcWall→muro, IfcBeam→viga, IfcSlab→placa."
      />

      {notice && (
        <Alert tone="ok">
          <div className="flex items-start justify-between gap-3">
            <span>{notice}</span>
            <Btn size="sm" variant="ok" onClick={() => goTab("cantidades")}>Ir a Cantidades <ArrowRight size={12} /></Btn>
          </div>
        </Alert>
      )}
      {error && <Alert tone="error">{error}</Alert>}

      {/* Filtros + barra de selección */}
      <div className="flex flex-wrap items-center gap-2">
        {FILTROS.map((f) => {
          const n = f === "TODAS" ? (rows?.length ?? 0) : counts[f as keyof typeof counts];
          return (
            <button key={f} onClick={() => setFiltro(f)}
              className={cx("flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors",
                filtro === f ? "border-acc/60 bg-acc/10 text-acc" : "border-line bg-ink-800 text-mist hover:text-white")}>
              {f === "TODAS" ? "Todas" : STATUS_META[f].label}
              <span className="rounded bg-ink-700 px-1.5 font-mono text-[10px]">{n}</span>
            </button>
          );
        })}
        {selectable.length > 0 && (
          <Btn size="sm" icon={allSelected ? CheckSquare : Square} onClick={toggleAll}>
            {allSelected ? "Quitar selección" : `Seleccionar ${selectable.length} pendientes`}
          </Btn>
        )}
      </div>

      {selected.size > 0 && (
        <Card className="sticky top-16 z-20 flex flex-wrap items-center gap-2 border-acc/40 bg-ink-800/95 p-3 backdrop-blur bc-glow">
          <span className="text-xs font-bold text-white">{selected.size} correspondencia(s) seleccionada(s)</span>
          <span className="text-[11px] text-mist">— aplique una decisión profesional en lote</span>
          <div className="ml-auto flex gap-2">
            <Btn size="sm" variant="ok" icon={ShieldCheck} onClick={() => setBulkModal("validate")}>Validar y medir seleccionadas</Btn>
            <Btn size="sm" variant="danger" icon={XCircle} onClick={() => setBulkModal("reject")}>Rechazar seleccionadas</Btn>
            <Btn size="sm" onClick={() => setSelected(new Set())}>Cancelar</Btn>
          </div>
        </Card>
      )}

      {rows === null ? (
        <Spinner label="Cargando correspondencias…" />
      ) : (
        <div className="space-y-3">
          {filtered.map((m) => {
            const evid = (m.evidence ?? {}) as {
              coincidencias?: string[]; umbral_propuesta?: number; familiaBIM?: string[];
              ambiguo?: boolean; reglaBIM?: string; sinCandidatoCompatible?: boolean;
            };
            const alternativos = m.candidates?.filter((c) => c.activityId !== m.activityId) ?? [];
            const pendiente = m.status === "PENDIENTE" || m.status === "PROPUESTA";
            const isSel = selected.has(m.id);
            return (
              <Card key={m.id} className={cx("overflow-hidden transition-colors",
                m.status === "RECHAZADA" && "opacity-60",
                isSel && "border-acc/60 bc-glow")}>
                <div className="grid lg:grid-cols-2">
                  {/* Evidencia */}
                  <div className="border-b border-line/60 p-4 lg:border-b-0 lg:border-r">
                    <div className="mb-2 flex items-center gap-2">
                      {pendiente && (
                        <button onClick={() => toggleOne(m.id)} className="text-mist hover:text-acc" title="Seleccionar para decisión en lote">
                          {isSel ? <CheckSquare size={15} className="text-acc" /> : <Square size={15} />}
                        </button>
                      )}
                      <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-fog">
                        <ScanSearch size={11} /> Evidencia agrupada
                      </p>
                      {evid.familiaBIM?.length ? (
                        <Chip className="border-cyan-400/30 bg-cyan-400/10 text-cyan-300">{evid.familiaBIM[0]}</Chip>
                      ) : null}
                      <button onClick={() => openViewer(m)} className="ml-auto flex items-center gap-1 rounded-md border border-line-strong bg-ink-800 px-2 py-1 text-[10.5px] font-semibold text-mist hover:border-acc/50 hover:text-acc">
                        <BoxIcon size={11} /> Ver en 3D
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {m.grupo && Object.entries(m.grupo.criteriaValues).map(([k, v]) => (
                        <Chip key={k} className="border-line bg-ink-750 text-slate-300">
                          <span className="text-fog">{k.replace(/^prop:/, "prop.")}:</span>&nbsp;<span className="font-mono">{v}</span>
                        </Chip>
                      ))}
                      <Chip className="border-cyan-400/30 bg-cyan-400/10 font-mono text-cyan-300">{m.grupo?.elementCount ?? 0} elementos</Chip>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1">
                      {m.grupo?.fuentes.map((f) => <Chip key={f} className="border-line-strong bg-ink-800 text-mist">{f}</Chip>)}
                      {!m.esCorridaActual && <Chip className="border-amber-400/40 bg-amber-400/10 text-amber-300">corrida anterior</Chip>}
                    </div>
                    {evid.coincidencias?.length ? (
                      <p className="mt-2 text-[11px] leading-relaxed text-mist">
                        <span className="font-semibold text-slate-300">Evidencia que sustenta:</span> {evid.coincidencias.join(" · ")}
                      </p>
                    ) : null}
                    {evid.reglaBIM ? <p className="mt-1 text-[10.5px] italic text-fog">{evid.reglaBIM}</p> : null}
                  </div>

                  {/* Propuesta + decisión */}
                  <div className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <p className="mb-1 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-fog">
                          <Layers3 size={11} /> {m.status === "PENDIENTE" ? "Sin propuesta confiable" : "Actividad propuesta"}
                        </p>
                        {m.actividad ? (
                          <>
                            <p className="truncate text-sm font-bold text-white">
                              <span className="mr-1.5 font-mono text-xs text-acc">{m.actividad.code}</span>
                              {m.actividad.name}
                            </p>
                            <div className="mt-1.5 flex flex-wrap gap-1">
                              <Chip className="border-line-strong bg-ink-750 font-mono">{m.actividad.unit}</Chip>
                              <Chip className="border-violet-400/30 bg-violet-400/10 text-violet-300">
                                {METHOD_META[m.actividad.method]?.label ?? m.actividad.method}
                              </Chip>
                              {m.actividad.unitPrice > 0 && (
                                <Chip className="border-emerald-400/30 bg-emerald-400/10 text-emerald-300">${fmt(m.actividad.unitPrice, 0)}/{m.actividad.unit}</Chip>
                              )}
                            </div>
                          </>
                        ) : (
                          <p className="text-xs leading-relaxed text-mist">
                            {evid.sinCandidatoCompatible
                              ? "Ninguna actividad del catálogo es compatible con esta familia BIM. Elija una o cree la actividad que falta."
                              : `Ningún candidato supera el umbral (${evid.umbral_propuesta ?? 55} puntos). Elija usted la actividad.`}
                          </p>
                        )}
                      </div>
                      <div className="flex shrink-0 flex-col items-end gap-1.5">
                        <StatusChip status={m.status} meta={STATUS_META} />
                        {m.score > 0 && (
                          <span className={cx("font-mono text-[11px] font-bold",
                            m.score >= 75 ? "text-emerald-400" : m.score >= 55 ? "text-sky-300" : "text-amber-300")}>
                            {m.score} pts
                          </span>
                        )}
                      </div>
                    </div>

                    {evid.ambiguo && pendiente && (
                      <p className="mt-2 flex items-start gap-1.5 rounded-md border border-amber-400/30 bg-amber-400/5 px-2 py-1.5 text-[10.5px] text-amber-200">
                        <TriangleAlert size={11} className="mt-0.5 shrink-0" />
                        Dos actividades obtuvieron puntajes muy próximos: conviene revisar antes de validar.
                      </p>
                    )}

                    {alternativos.length > 0 && (
                      <div className="mt-2.5 flex flex-wrap items-center gap-1">
                        <span className="text-[10px] text-fog">Alternativas:</span>
                        {alternativos.slice(0, 3).map((c) => (
                          <Chip key={c.activityId}
                            className={cx(c.classOk ? "border-line bg-ink-800 text-mist" : "border-rose-400/20 bg-rose-400/5 text-rose-300/70")}
                            title={`${c.matched.join(" · ")}${c.classOk ? "" : " — clase IFC no compatible"}`}>
                            <span className="font-mono">{c.code}</span> · {c.score} pts
                          </Chip>
                        ))}
                      </div>
                    )}

                    {pendiente ? (
                      <div className="mt-3 flex flex-wrap gap-2 border-t border-line/60 pt-3">
                        {m.actividad && (
                          <Btn size="sm" variant="ok" icon={ShieldCheck} loading={busyId === m.id} onClick={() => decide(m, "validate")}>
                            Validar y medir
                          </Btn>
                        )}
                        <Btn size="sm" icon={Search} onClick={() => setPickerFor(m)}>
                          {m.actividad ? "Otra actividad / crear…" : "Elegir o crear actividad…"}
                        </Btn>
                        <Btn size="sm" variant="danger" icon={XCircle} onClick={() => { setNoteFor(m); setNote(""); }}>
                          Rechazar
                        </Btn>
                      </div>
                    ) : (
                      <div className="mt-3 rounded-lg border border-line/60 bg-ink-800/50 px-3 py-2 text-[11px] leading-relaxed text-mist">
                        <div className="flex items-center gap-1.5">
                          {m.status === "VALIDADA" ? <CheckCircle2 size={12} className="text-emerald-400" /> : <Undo2 size={12} className="text-rose-400" />}
                          <span className="font-semibold text-slate-200">
                            {m.status === "VALIDADA" ? "Decisión profesional: validada" : "Decisión profesional: rechazada"}
                          </span>
                        </div>
                        <p className="mt-1">Por <span className="text-slate-200">{m.decidedBy ?? "—"}</span> · {nuevaFecha(m.decidedAt)}</p>
                        {m.decisionNote ? <p className="mt-0.5 italic">«{m.decisionNote}»</p> : null}
                        <div className="mt-1.5 flex gap-2">
                          {m.status === "VALIDADA" && (
                            <button className="text-acc hover:underline" onClick={() => goTab("cantidades")}>Ver cantidad →</button>
                          )}
                          <button className="text-mist hover:text-white hover:underline" onClick={() => decide(m, "reopen")}>Reabrir decisión</button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
          {filtered.length === 0 && (
            <Card className="p-8 text-center text-xs text-mist">No hay correspondencias en este estado.</Card>
          )}
        </div>
      )}

      {/* Elegir / crear actividad */}
      <Modal open={!!pickerFor} onClose={() => setPickerFor(null)} title="Elegir o crear la actividad del catálogo" wide>
        <p className="mb-3 flex items-start gap-2 text-[11px] leading-relaxed text-mist">
          <ClipboardCheck size={13} className="mt-0.5 shrink-0 text-acc" />
          Si la actividad no existe en el catálogo (p. ej. vigas de madera), créela aquí mismo: quedará
          disponible para todos los proyectos y vinculada a la familia BIM de este grupo.
        </p>
        {pickerFor && (
          <ActivityPicker
            allowCreate
            createSuggestion={{
              name: pickerFor.grupo ? Object.values(pickerFor.grupo.criteriaValues).filter((v) => v !== "(sin dato)").join(" ") : undefined,
              ifcClasses: pickerFor.grupo?.ifcClasses,
              keywords: pickerFor.grupo
                ? Object.values(pickerFor.grupo.criteriaValues).filter((v) => v !== "(sin dato)").join(" ").toLowerCase().split(/[^a-záéíóúñ0-9]+/).filter((t) => t.length > 3).slice(0, 8)
                : undefined,
            }}
            onPick={(a) => decide(pickerFor, "validate", a.id, pickerFor.decisionNote ?? undefined)}
          />
        )}
      </Modal>

      {/* Nota de rechazo */}
      <Modal open={!!noteFor} onClose={() => setNoteFor(null)} title="Rechazar propuesta">
        <div className="space-y-3">
          <p className="text-xs text-mist">Explique por qué la evidencia no corresponde a esta actividad. El rechazo queda registrado en el informe.</p>
          <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Motivo del rechazo (recomendado)…" />
          <div className="flex justify-end gap-2">
            <Btn onClick={() => setNoteFor(null)}>Cancelar</Btn>
            <Btn variant="danger" icon={XCircle} loading={busyId === noteFor?.id} onClick={() => noteFor && decide(noteFor, "reject", undefined, note)}>
              Confirmar rechazo
            </Btn>
          </div>
        </div>
      </Modal>

      {/* Confirmación de duplicado */}
      <Modal open={!!dupWarn} onClose={() => setDupWarn(null)} title="Estos elementos ya fueron medidos">
        {dupWarn && (
          <div className="space-y-3">
            <Alert tone="warn">
              <span className="flex items-start gap-2">
                <CopyPlus size={13} className="mt-0.5 shrink-0" />
                {dupWarn.info.mensaje}
              </span>
            </Alert>
            <p className="text-[11px] leading-relaxed text-mist">{dupWarn.info.sugerencia}</p>
            <div className="flex justify-end gap-2">
              <Btn onClick={() => setDupWarn(null)}>Cancelar</Btn>
              <Btn variant="warn" icon={CopyPlus} loading={busyId === dupWarn.match.id}
                onClick={() => decide(dupWarn.match, "validate", dupWarn.activityId, note || "Duplicación autorizada por el profesional", true)}>
                Autorizar duplicación
              </Btn>
            </div>
          </div>
        )}
      </Modal>

      {/* Lote */}
      <Modal open={!!bulkModal} onClose={() => setBulkModal(null)} title={bulkModal === "validate" ? "Validar y medir en lote" : "Rechazar en lote"}>
        <div className="space-y-3">
          <p className="text-xs text-mist">
            {bulkModal === "validate"
              ? `Se validarán ${selected.size} correspondencias y se medirán con el método de cada actividad. Las que no tengan actividad asignada o dupliquen elementos ya medidos se omitirán para que las decida individualmente.`
              : `Se rechazarán ${selected.size} correspondencias. Podrá reabrirlas después.`}
          </p>
          <Textarea value={bulkNote} onChange={(e) => setBulkNote(e.target.value)} placeholder="Observación común del lote (opcional)…" />
          <div className="flex justify-end gap-2">
            <Btn onClick={() => setBulkModal(null)}>Cancelar</Btn>
            <Btn variant={bulkModal === "validate" ? "ok" : "danger"} icon={bulkModal === "validate" ? ShieldCheck : XCircle}
              loading={bulkBusy} onClick={() => runBulk(bulkModal === "validate" ? "validate" : "reject")}>
              Confirmar {selected.size} decisiones
            </Btn>
          </div>
        </div>
      </Modal>

      {/* Visor 3D del grupo */}
      <Modal open={!!viewerFor} onClose={() => { setViewerFor(null); setViewerEls(null); }} title={
        <span className="flex items-center gap-2"><BoxIcon size={14} className="text-acc" /> Visor 3D del grupo</span>
      } wide>
        {viewerFor && (
          <div className="space-y-3">
            <div className="flex flex-wrap gap-1">
              {Object.entries(viewerFor.grupo?.criteriaValues ?? {}).map(([k, v]) => (
                <Chip key={k} className="border-line bg-ink-750 text-slate-300"><span className="text-fog">{k}:</span>&nbsp;{v}</Chip>
              ))}
            </div>
            {viewerEls === null ? <Spinner label="Cargando geometría…" /> : <Viewer3D elements={viewerEls} height={420} />}
            <Alert tone="info">
              <span className="flex items-start gap-2">
                <Sparkles size={12} className="mt-0.5 shrink-0" />
                El visor muestra la caja envolvente de cada elemento calculada desde el IFC. Úselo para confirmar
                qué está midiendo antes de validar; las dimensiones exactas están en «Evidencia IFC».
              </span>
            </Alert>
          </div>
        )}
      </Modal>
    </div>
  );
}
