"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Layers3, Play, TriangleAlert, ArrowRight, History, CheckSquare, Square,
  PowerOff, Power, Filter,
} from "lucide-react";
import { Alert, Btn, Card, Chip, Empty, Spinner, SectionTitle, HelpIcon, cx } from "@/components/ui";
import { api, fmt, nuevaFecha } from "@/lib/client";

interface Criterio { key: string; label: string; hint: string }
interface Run { id: string; criteria: string[]; excludedClasses: string[]; elementCount: number; groupCount: number; durationMs: number; createdAt: string }
interface GroupRow {
  id: string; groupKey: string; criteriaValues: Record<string, string>;
  elementCount: number; ifcClasses: string[];
  correspondencias: { total: number; propuestas: number; pendientes: number; validadas: number; rechazadas: number; mejorScore: number } | null;
}
interface ClaseRow { ifcClass: string; count: number; familia: string; familiaLabel: string; presupuestable: boolean }
interface Summary { propiedades: { clave: string; elementos: number }[]; fuentes: { id: string; name: string; kind: string; elementos: number }[] }

export function Agrupacion({
  projectId, actor, onChanged, goTab,
}: { projectId: string; actor: string; onChanged: () => void; goTab: (t: "correspondencias") => void }) {
  const [criterios, setCriterios] = useState<string[]>(["ifcClass", "typeName", "material", "level"]);
  const [sourceIds, setSourceIds] = useState<string[]>([]);
  const [defCriterios, setDefCriterios] = useState<Criterio[]>([]);
  const [clases, setClases] = useState<ClaseRow[]>([]);
  const [excluidas, setExcluidas] = useState<Set<string>>(new Set());
  const [summary, setSummary] = useState<Summary | null>(null);
  const [runs, setRuns] = useState<Run[]>([]);
  const [groups, setGroups] = useState<GroupRow[]>([]);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [initialized, setInitialized] = useState(false);

  const load = useCallback(async (runId?: string) => {
    const p = new URLSearchParams({ projectId });
    if (runId) p.set("runId", runId);
    const d = await api<{
      runs: Run[]; groups: GroupRow[]; criteriosDisponibles: Criterio[];
      clases: ClaseRow[]; exclusionesSugeridas: string[];
    }>(`/api/grouping?${p}`);
    setRuns(d.runs);
    setGroups(d.groups);
    setDefCriterios(d.criteriosDisponibles);
    setClases(d.clases);
    setLoading(false);
    if (!initialized) {
      const previas = d.runs[0]?.excludedClasses;
      setExcluidas(new Set(previas?.length ? previas : d.exclusionesSugeridas));
      setInitialized(true);
    }
  }, [projectId, initialized]);

  useEffect(() => {
    load();
    api<Summary>(`/api/evidence-summary?projectId=${projectId}`).then((d) => {
      setSummary(d);
      setSourceIds(d.fuentes.filter((f) => f.kind === "IFC" && f.elementos > 0).map((f) => f.id));
    });
  }, [projectId, load]);

  const propCriteria = (summary?.propiedades ?? []).slice(0, 8).map((p) => ({
    key: `prop:${p.clave}`, label: `Propiedad: ${p.clave.split(".").pop()}`, hint: `${p.clave} · ${p.elementos} elementos`,
  }));
  const allCriteria = [...defCriterios, ...propCriteria];

  const toggle = (k: string) => setCriterios((c) => (c.includes(k) ? c.filter((x) => x !== k) : [...c, k]));
  const toggleSource = (id: string) => setSourceIds((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  const toggleClase = (cls: string) =>
    setExcluidas((s) => {
      const next = new Set(s);
      if (next.has(cls)) next.delete(cls); else next.add(cls);
      return next;
    });

  const run = async () => {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const d = await api<{ grupos: number; propuestas: number; pendientes: number; ambiguas: number }>("/api/grouping", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectId, sourceIds, criteria: criterios, excludedClasses: [...excluidas], actor }),
      });
      setResult(
        `Corrida completa: ${d.grupos} grupos → ${d.propuestas} propuestas y ${d.pendientes} sin candidato compatible.` +
        (d.ambiguas ? ` ${d.ambiguas} con puntajes muy próximos (revise antes de validar).` : "")
      );
      await load();
      onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const ifcSources = summary?.fuentes.filter((f) => f.kind === "IFC" && f.elementos > 0) ?? [];
  const heavy = criterios.length >= 5;
  const activos = clases.filter((c) => !excluidas.has(c.ifcClass)).reduce((a, c) => a + c.count, 0);
  const apagados = clases.filter((c) => excluidas.has(c.ifcClass)).reduce((a, c) => a + c.count, 0);

  return (
    <div className="space-y-5 bc-fade-up">
      <SectionTitle
        title="Agrupación de elementos BIM"
        desc="Usted elige los criterios y qué clases participan. Agrupar es analizar evidencia común: no es todavía una clasificación presupuestal."
      />

      {error && <Alert tone="error">{error}</Alert>}
      {result && (
        <Alert tone="ok">
          {result}{" "}
          <button className="font-semibold underline" onClick={() => goTab("correspondencias")}>Revisar correspondencias →</button>
        </Alert>
      )}

      <div className="grid gap-4 lg:grid-cols-5">
        <Card className="p-5 lg:col-span-3">
          <h3 className="mb-1 flex items-center gap-2 text-sm font-bold text-white">
            <Layers3 size={15} className="text-acc" /> Criterios de agrupación
            <HelpIcon text="Cada combinación distinta de valores forma un grupo. Los números se redondean a 3 decimales." />
          </h3>
          <p className="mb-3 text-[11px] text-fog">Seleccionados: <span className="font-mono text-acc">{criterios.length}</span></p>
          <div className="grid gap-1.5 sm:grid-cols-2">
            {allCriteria.map((c) => {
              const on = criterios.includes(c.key);
              return (
                <button key={c.key} onClick={() => toggle(c.key)}
                  className={cx("flex items-start gap-2.5 rounded-lg border px-3 py-2.5 text-left transition-colors",
                    on ? "border-acc/60 bg-acc/10" : "border-line bg-ink-800 hover:border-line-strong")}>
                  {on ? <CheckSquare size={15} className="mt-0.5 shrink-0 text-acc" /> : <Square size={15} className="mt-0.5 shrink-0 text-fog" />}
                  <span>
                    <span className={cx("block text-xs font-semibold", on ? "text-white" : "text-slate-300")}>{c.label}</span>
                    <span className="block text-[10.5px] text-fog">{c.hint}</span>
                  </span>
                </button>
              );
            })}
          </div>
          {heavy && (
            <div className="mt-3">
              <Alert tone="warn">
                <div className="flex items-start gap-2">
                  <TriangleAlert size={14} className="mt-0.5 shrink-0" />
                  Con {criterios.length} criterios se generan más grupos y el análisis tarda más. Verifique que cada criterio aporte discriminación real.
                </div>
              </Alert>
            </div>
          )}
        </Card>

        <Card className="p-5 lg:col-span-2">
          <h3 className="mb-3 text-sm font-bold text-white">Fuentes que participan</h3>
          {ifcSources.length === 0 ? (
            <p className="text-xs text-mist">No hay fuentes IFC con elementos.</p>
          ) : (
            <div className="space-y-1.5">
              {ifcSources.map((f) => {
                const on = sourceIds.includes(f.id);
                return (
                  <button key={f.id} onClick={() => toggleSource(f.id)}
                    className={cx("flex w-full items-center gap-2.5 rounded-lg border px-3 py-2.5 text-left transition-colors",
                      on ? "border-acc/60 bg-acc/10" : "border-line bg-ink-800")}>
                    {on ? <CheckSquare size={15} className="shrink-0 text-acc" /> : <Square size={15} className="shrink-0 text-fog" />}
                    <span className="flex-1 text-xs font-semibold text-slate-200">{f.name}</span>
                    <Chip className="font-mono">{f.elementos}</Chip>
                  </button>
                );
              })}
            </div>
          )}
          <Btn variant="primary" icon={Play} loading={busy} onClick={run} className="mt-4 w-full"
            disabled={criterios.length === 0 || ifcSources.length === 0}>
            Ejecutar agrupación y buscar correspondencias
          </Btn>
          <p className="mt-2 text-center text-[10.5px] text-fog">
            Se conservan las decisiones ya tomadas; solo se recalcula lo pendiente.
          </p>
        </Card>
      </div>

      {/* Clases IFC participantes */}
      <Card className="p-5">
        <div className="mb-1 flex flex-wrap items-center justify-between gap-2">
          <h3 className="flex items-center gap-2 text-sm font-bold text-white">
            <Filter size={15} className="text-acc" /> Clases de elementos que participan
          </h3>
          <div className="flex items-center gap-2 text-[11px]">
            <Chip className="border-emerald-400/30 bg-emerald-400/10 text-emerald-300">{fmt(activos, 0)} elementos activos</Chip>
            {apagados > 0 && <Chip className="border-rose-400/30 bg-rose-400/10 text-rose-300">{fmt(apagados, 0)} apagados</Chip>}
          </div>
        </div>
        <p className="mb-3 text-[11px] text-fog">
          Apague lo que no entra en su alcance (mobiliario, vanos) o lo que no contrataron (p. ej. solo acabados: apague muros y estructura).
          Los elementos apagados conservan su evidencia y pueden reactivarse.
        </p>
        <div className="grid gap-1.5 sm:grid-cols-2 lg:grid-cols-3">
          {clases.map((c) => {
            const off = excluidas.has(c.ifcClass);
            return (
              <button key={c.ifcClass} onClick={() => toggleClase(c.ifcClass)}
                className={cx("flex items-center gap-2.5 rounded-lg border px-3 py-2 text-left transition-colors",
                  off ? "border-line bg-ink-800/40 opacity-60" : "border-emerald-400/25 bg-emerald-400/5")}>
                {off ? <PowerOff size={14} className="shrink-0 text-rose-300" /> : <Power size={14} className="shrink-0 text-emerald-400" />}
                <span className="min-w-0 flex-1">
                  <span className={cx("block truncate font-mono text-[11px] font-bold", off ? "text-fog line-through" : "text-slate-100")}>
                    {c.ifcClass.replace(/^IFC/, "Ifc")}
                  </span>
                  <span className="block truncate text-[10px] text-fog">{c.familiaLabel}</span>
                </span>
                <Chip className={cx("font-mono", off ? "border-line bg-ink-800 text-fog" : "border-line-strong bg-ink-750 text-mist")}>
                  {c.count}
                </Chip>
                {!c.presupuestable && !off && (
                  <span title="Normalmente no entra en presupuesto"><TriangleAlert size={12} className="text-amber-300" /></span>
                )}
              </button>
            );
          })}
        </div>
      </Card>

      {runs.length > 1 && (
        <Card className="p-4">
          <p className="mb-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-widest text-fog"><History size={12} /> Corridas de análisis</p>
          <div className="flex flex-wrap gap-2">
            {runs.map((r, i) => (
              <button key={r.id} onClick={() => load(r.id)}
                className={cx("rounded-lg border px-3 py-1.5 text-left text-[11px] transition-colors",
                  i === 0 ? "border-acc/50 bg-acc/10 text-acc" : "border-line bg-ink-800 text-mist hover:text-white")}>
                <span className="font-mono font-bold">{r.groupCount} grupos</span> · {r.elementCount} elem. · {fmt(r.durationMs, 0)} ms
                <span className="block text-[10px] text-fog">
                  {nuevaFecha(r.createdAt)} · {r.criteria.length} criterios
                  {r.excludedClasses?.length ? ` · ${r.excludedClasses.length} clases apagadas` : ""}
                  {i === 0 ? " · actual" : ""}
                </span>
              </button>
            ))}
          </div>
        </Card>
      )}

      {loading ? (
        <Spinner label="Cargando grupos…" />
      ) : groups.length === 0 ? (
        <Empty icon={Layers3} title="Aún no hay agrupación" hint="Elija criterios, clases y fuentes, y ejecute el análisis." />
      ) : (
        <Card className="overflow-hidden">
          <div className="max-h-[520px] overflow-auto">
            <table className="w-full text-left text-xs">
              <thead className="sticky top-0 z-10 bg-ink-800 text-[10px] uppercase tracking-wider text-fog">
                <tr>
                  <th className="px-4 py-2.5 font-semibold">Grupo de evidencia</th>
                  <th className="w-24 px-4 py-2.5 text-right font-semibold">Elementos</th>
                  <th className="w-44 px-4 py-2.5 font-semibold">Correspondencia</th>
                  <th className="w-28 px-4 py-2.5" />
                </tr>
              </thead>
              <tbody>
                {groups.map((g) => (
                  <tr key={g.id} className="border-t border-line/50 transition-colors hover:bg-ink-800/60">
                    <td className="px-4 py-2.5">
                      <div className="flex flex-wrap gap-1">
                        {Object.entries(g.criteriaValues).map(([k, v]) => (
                          <Chip key={k} className="border-line bg-ink-750 text-slate-300">
                            <span className="text-fog">{k.replace(/^prop:/, "prop.")}:</span>&nbsp;
                            <span className={v === "(sin dato)" ? "italic text-amber-300/80" : "font-mono"}>{v}</span>
                          </Chip>
                        ))}
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono text-sm font-bold tabular-nums text-white">{g.elementCount}</td>
                    <td className="px-4 py-2.5">
                      {g.correspondencias ? (
                        <div className="flex flex-wrap gap-1">
                          {g.correspondencias.propuestas > 0 && <Chip className="border-sky-400/40 bg-sky-400/10 text-sky-300">propuesta</Chip>}
                          {g.correspondencias.pendientes > 0 && <Chip className="border-amber-400/40 bg-amber-400/10 text-amber-300">pendiente</Chip>}
                          {g.correspondencias.validadas > 0 && <Chip className="border-emerald-400/40 bg-emerald-400/10 text-emerald-300">validada</Chip>}
                          {g.correspondencias.rechazadas > 0 && <Chip className="border-rose-400/40 bg-rose-400/10 text-rose-300">rechazada</Chip>}
                          {g.correspondencias.mejorScore > 0 && <Chip className="border-line bg-ink-750 font-mono text-mist">{g.correspondencias.mejorScore} pts</Chip>}
                        </div>
                      ) : <span className="text-fog">—</span>}
                    </td>
                    <td className="px-4 py-2.5 text-right">
                      <Btn size="sm" onClick={() => goTab("correspondencias")}>Decidir <ArrowRight size={12} /></Btn>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="border-t border-line bg-ink-800/60 px-4 py-2 text-[10.5px] text-fog">
            {groups.length} grupos · cada grupo produce una sola propuesta de actividad para no duplicar cantidades.
          </div>
        </Card>
      )}
    </div>
  );
}
