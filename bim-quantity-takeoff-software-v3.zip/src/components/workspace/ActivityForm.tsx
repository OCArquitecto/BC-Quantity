"use client";

import { useEffect, useMemo, useState } from "react";
import { Copy, FolderPlus, Save, Wand2, Boxes } from "lucide-react";
import { Alert, Btn, Chip, Field, Input, Select, Textarea, cx } from "@/components/ui";
import { api, METHOD_META } from "@/lib/client";
import { nextFreeCode, compareCodes } from "@/lib/codes";

export interface CatalogActivityFull {
  id: string;
  code: string;
  name: string;
  unit: string;
  method: string;
  chapterCode: string;
  chapterName: string;
  sectionCode: string;
  sectionName: string;
  keywords: string[];
  ifcClasses: string[];
  unitPrice: number;
  description: string | null;
  active: boolean;
}

interface GroupRow { id: string; kind: string; code: string; name: string; parentCode: string | null; active: boolean; actividades: number }

const UNITS = ["M2", "M3", "M", "UND", "KG", "TON", "GLB", "DIA", "HORA", "MES", "LT"];

/**
 * Formulario ordenado para crear una actividad del catálogo maestro:
 * capítulo y sección se ELIGEN de los existentes o se crean al vuelo, y
 * se puede partir duplicando una actividad similar.
 */
export function ActivityForm({
  onCreated,
  onCancel,
  duplicateFrom,
  suggest,
}: {
  onCreated: (a: CatalogActivityFull) => void;
  onCancel?: () => void;
  duplicateFrom?: CatalogActivityFull | null;
  /** Sugerencias tomadas de la evidencia BIM del grupo que se está validando. */
  suggest?: { name?: string; ifcClasses?: string[]; unit?: string; method?: string; keywords?: string[] };
}) {
  const [groups, setGroups] = useState<{ capitulos: GroupRow[]; secciones: GroupRow[] } | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [chapterMode, setChapterMode] = useState<"EXISTENTE" | "NUEVO">("EXISTENTE");
  const [sectionMode, setSectionMode] = useState<"EXISTENTE" | "NUEVA">("EXISTENTE");

  const [form, setForm] = useState({
    code: duplicateFrom ? `${duplicateFrom.code}-B` : "",
    name: duplicateFrom?.name ?? suggest?.name ?? "",
    chapterCode: duplicateFrom?.chapterCode ?? "",
    chapterName: duplicateFrom?.chapterName ?? "",
    sectionCode: duplicateFrom?.sectionCode ?? "",
    sectionName: duplicateFrom?.sectionName ?? "",
    unit: duplicateFrom?.unit ?? suggest?.unit ?? "M2",
    method: duplicateFrom?.method ?? suggest?.method ?? "SUPERFICIE_GEOMETRICA",
    keywords: (duplicateFrom?.keywords ?? suggest?.keywords ?? []).join(", "),
    ifcClasses: (duplicateFrom?.ifcClasses ?? suggest?.ifcClasses ?? []).join(", "),
    unitPrice: duplicateFrom ? String(duplicateFrom.unitPrice ?? 0) : "0",
    description: duplicateFrom?.description ?? "",
  });

  useEffect(() => {
    api<{ capitulos: GroupRow[]; secciones: GroupRow[] }>("/api/catalog/groups").then((d) => {
      setGroups(d);
      setForm((f) => {
        if (f.chapterCode) return f;
        const first = d.capitulos[0];
        if (!first) return f;
        const sec = d.secciones.find((s) => s.parentCode === first.code);
        return {
          ...f,
          chapterCode: first.code, chapterName: first.name,
          sectionCode: sec?.code ?? "", sectionName: sec?.name ?? "",
        };
      });
    });
  }, []);

  const sectionsOfChapter = useMemo(
    () => (groups?.secciones ?? [])
      .filter((s) => s.parentCode === form.chapterCode)
      .sort((a, b) => compareCodes(a.code, b.code)),
    [groups, form.chapterCode]
  );

  /** Propone el siguiente código libre dentro del subcapítulo elegido.
      Respeta el orden jerárquico: tras 1.2.9 viene 1.2.10, no 1.2.91. */
  const suggestCode = async () => {
    if (!form.sectionCode) return;
    const d = await api<{ flat: { code: string }[] }>(`/api/catalog?q=${encodeURIComponent(form.sectionCode)}&limit=500`);
    const codes = d.flat.map((a) => a.code).sort(compareCodes);
    setForm((f) => ({ ...f, code: nextFreeCode(form.sectionCode, codes) }));
  };

  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      const d = await api<{ activity: CatalogActivityFull }>("/api/catalog", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          duplicateFrom: duplicateFrom?.id,
          code: form.code.trim(),
          name: form.name.trim(),
          chapterCode: form.chapterCode.trim(),
          chapterName: form.chapterName.trim(),
          sectionCode: form.sectionCode.trim(),
          sectionName: form.sectionName.trim(),
          unit: form.unit,
          method: form.method,
          keywords: form.keywords,
          ifcClasses: form.ifcClasses,
          unitPrice: Number(form.unitPrice.replace(",", ".")) || 0,
          description: form.description,
        }),
      });
      onCreated(d.activity);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      {error ? <Alert tone="error">{error}</Alert> : null}
      {duplicateFrom ? (
        <Alert tone="info">
          <span className="flex items-center gap-1.5">
            <Copy size={12} /> Duplicando <strong>{duplicateFrom.code} — {duplicateFrom.name}</strong>. Cambie el código y ajuste lo necesario.
          </span>
        </Alert>
      ) : null}
      {suggest?.ifcClasses?.length ? (
        <Alert tone="ok">
          <span className="flex items-center gap-1.5">
            <Boxes size={12} /> Clases IFC tomadas de la evidencia del grupo: <strong>{suggest.ifcClasses.join(", ")}</strong>.
            Así la actividad quedará vinculada a esa familia BIM.
          </span>
        </Alert>
      ) : null}

      {/* CAPÍTULO */}
      <div className="rounded-xl border border-line bg-ink-800/40 p-3.5">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-mist">1. Capítulo</span>
          <div className="flex gap-1">
            {(["EXISTENTE", "NUEVO"] as const).map((m) => (
              <button key={m} onClick={() => setChapterMode(m)}
                className={cx("rounded-md px-2 py-1 text-[10.5px] font-semibold transition-colors",
                  chapterMode === m ? "bg-acc/15 text-acc" : "text-fog hover:text-slate-200")}>
                {m === "EXISTENTE" ? "Elegir existente" : "Crear nuevo"}
              </button>
            ))}
          </div>
        </div>
        {chapterMode === "EXISTENTE" ? (
          <Select
            value={form.chapterCode}
            onChange={(e) => {
              const ch = groups?.capitulos.find((c) => c.code === e.target.value);
              const sec = groups?.secciones.find((s) => s.parentCode === e.target.value);
              setForm({
                ...form, chapterCode: e.target.value, chapterName: ch?.name ?? "",
                sectionCode: sec?.code ?? "", sectionName: sec?.name ?? "",
              });
            }}
          >
            <option value="">— Seleccione un capítulo —</option>
            {[...(groups?.capitulos ?? [])].sort((a, b) => compareCodes(a.code, b.code)).map((c) => (
              <option key={c.id} value={c.code}>{c.code} · {c.name} ({c.actividades})</option>
            ))}
          </Select>
        ) : (
          <div className="grid grid-cols-3 gap-2">
            <Input placeholder="Código (18)" value={form.chapterCode} onChange={(e) => setForm({ ...form, chapterCode: e.target.value })} className="font-mono" />
            <Input placeholder="Nombre del capítulo" value={form.chapterName} onChange={(e) => setForm({ ...form, chapterName: e.target.value })} className="col-span-2" />
          </div>
        )}
      </div>

      {/* SECCIÓN */}
      <div className="rounded-xl border border-line bg-ink-800/40 p-3.5">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-mist">2. Subcapítulo / sección</span>
          <div className="flex gap-1">
            {(["EXISTENTE", "NUEVA"] as const).map((m) => (
              <button key={m} onClick={() => setSectionMode(m)}
                className={cx("rounded-md px-2 py-1 text-[10.5px] font-semibold transition-colors",
                  sectionMode === m ? "bg-acc/15 text-acc" : "text-fog hover:text-slate-200")}>
                {m === "EXISTENTE" ? "Elegir existente" : "Crear nueva"}
              </button>
            ))}
          </div>
        </div>
        {sectionMode === "EXISTENTE" ? (
          <Select
            value={form.sectionCode}
            onChange={(e) => {
              const sec = sectionsOfChapter.find((s) => s.code === e.target.value);
              setForm({ ...form, sectionCode: e.target.value, sectionName: sec?.name ?? "" });
            }}
          >
            <option value="">— Seleccione una sección —</option>
            {sectionsOfChapter.map((s) => (
              <option key={s.id} value={s.code}>{s.code} · {s.name} ({s.actividades})</option>
            ))}
          </Select>
        ) : (
          <div className="grid grid-cols-3 gap-2">
            <Input placeholder={`Código (${form.chapterCode || "18"}.01)`} value={form.sectionCode} onChange={(e) => setForm({ ...form, sectionCode: e.target.value })} className="font-mono" />
            <Input placeholder="Nombre de la sección" value={form.sectionName} onChange={(e) => setForm({ ...form, sectionName: e.target.value })} className="col-span-2" />
          </div>
        )}
      </div>

      {/* ACTIVIDAD */}
      <div className="rounded-xl border border-line bg-ink-800/40 p-3.5 space-y-3">
        <span className="block text-[11px] font-bold uppercase tracking-[0.14em] text-mist">3. Actividad</span>
        <div className="grid gap-3 sm:grid-cols-[180px_1fr]">
          <Field label="Código *">
            <div className="flex gap-1">
              <Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} className="font-mono" placeholder="18.01.001" />
              <Btn size="sm" icon={Wand2} onClick={suggestCode} title="Sugerir el siguiente código libre" />
            </div>
          </Field>
          <Field label="Nombre de la actividad *">
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Viga de madera cepillada 0.10×0.20" />
          </Field>
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Unidad *">
            <Select value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })}>
              {UNITS.map((u) => <option key={u}>{u}</option>)}
            </Select>
          </Field>
          <Field label="Método de medición *">
            <Select value={form.method} onChange={(e) => setForm({ ...form, method: e.target.value })}>
              {Object.entries(METHOD_META).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </Select>
          </Field>
          <Field label="Precio unitario" hint="Referencia; BC Budget lo puede actualizar">
            <Input value={form.unitPrice} onChange={(e) => setForm({ ...form, unitPrice: e.target.value })} className="font-mono" inputMode="decimal" />
          </Field>
        </div>
        <Field label="Clases IFC compatibles" hint="Determina con qué elementos BIM puede corresponder esta actividad">
          <Input value={form.ifcClasses} onChange={(e) => setForm({ ...form, ifcClasses: e.target.value })} className="font-mono" placeholder="IFCBEAM, IFCBEAMSTANDARDCASE" />
        </Field>
        {form.ifcClasses ? (
          <div className="flex flex-wrap gap-1">
            {form.ifcClasses.split(",").map((c) => c.trim()).filter(Boolean).map((c) => (
              <Chip key={c} className="border-cyan-400/25 bg-cyan-400/5 font-mono text-cyan-300">{c.toUpperCase()}</Chip>
            ))}
          </div>
        ) : null}
        <Field label="Palabras clave" hint="Mejoran las propuestas automáticas">
          <Input value={form.keywords} onChange={(e) => setForm({ ...form, keywords: e.target.value })} placeholder="viga, madera, cepillada" />
        </Field>
        <Field label="Descripción / alcance de la medición">
          <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        </Field>
      </div>

      <div className="flex justify-end gap-2">
        {onCancel ? <Btn onClick={onCancel}>Cancelar</Btn> : null}
        <Btn variant="primary" icon={duplicateFrom ? Copy : FolderPlus} loading={busy} onClick={save}>
          {duplicateFrom ? "Crear duplicado en el catálogo" : "Guardar en el catálogo maestro"}
        </Btn>
      </div>
      <p className="flex items-center gap-1.5 text-[10.5px] text-fog">
        <Save size={11} /> La actividad queda disponible para todos los proyectos: el catálogo es una base maestra reutilizable.
      </p>
    </div>
  );
}
