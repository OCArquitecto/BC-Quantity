"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft, FolderInput, ScanSearch, Layers3, GitCompareArrows,
  Ruler, Network, History, UserRound, Boxes, FileText, FileCog,
} from "lucide-react";
import { Btn } from "@/components/ui";
import { Nav } from "@/components/Nav";
import { Chip, cx, Input, Spinner } from "@/components/ui";
import { api, KIND_META } from "@/lib/client";
import { Fuentes } from "./Fuentes";
import { Evidencia } from "./Evidencia";
import { Agrupacion } from "./Agrupacion";
import { Correspondencias } from "./Correspondencias";
import { Cantidades } from "./Cantidades";
import { Estructura } from "./Estructura";
import { Trazabilidad } from "./Trazabilidad";
import { DocumentosConfig } from "./DocumentosConfig";

export interface ProjectDetail {
  project: {
    id: string; code: string; name: string; client: string | null;
    location: string | null; description: string | null; status: string;
    company?: Record<string, string> | null;
    settings?: Record<string, unknown> | null;
  };
  sources: { id: string; kind: string; name: string; discipline: string | null; fileName: string | null; fileSize: number | null; ifcSchema: string | null; stats: Record<string, unknown> | null; createdAt: string }[];
  stats: {
    fuentes: number;
    fuentesIfc: number;
    elementos: number;
    excluidos: number;
    corridas: number;
    ultimaCorrida: { id: string; criteria: string[]; groupCount: number; elementCount: number; createdAt: string } | null;
    matchesPorEstado: Record<string, number>;
    cantidadesPorEstado: Record<string, number>;
    decisiones: number;
  };
}

type TabId = "fuentes" | "evidencia" | "agrupacion" | "correspondencias" | "cantidades" | "estructura" | "documentos" | "trazabilidad";

const TABS: { id: TabId; label: string; icon: typeof FolderInput; badge?: (s: ProjectDetail["stats"]) => number }[] = [
  { id: "fuentes", label: "Fuentes", icon: FolderInput, badge: (s) => s.fuentes },
  { id: "evidencia", label: "Evidencia IFC", icon: ScanSearch, badge: (s) => s.elementos },
  { id: "agrupacion", label: "Agrupación", icon: Layers3 },
  { id: "correspondencias", label: "Correspondencias", icon: GitCompareArrows, badge: (s) => (s.matchesPorEstado.PENDIENTE ?? 0) + (s.matchesPorEstado.PROPUESTA ?? 0) },
  { id: "cantidades", label: "Cantidades", icon: Ruler, badge: (s) => (s.cantidadesPorEstado.PROPUESTA ?? 0) + (s.cantidadesPorEstado.PENDIENTE ?? 0) },
  { id: "estructura", label: "Estructura", icon: Network },
  { id: "documentos", label: "Proyecto y documentos", icon: FileCog },
  { id: "trazabilidad", label: "Trazabilidad", icon: History, badge: (s) => s.decisiones },
];

export function Workspace({ projectId }: { projectId: string }) {
  const [data, setData] = useState<ProjectDetail | null>(null);
  const [tab, setTab] = useState<TabId>("fuentes");
  const [actor, setActor] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const saved = typeof window !== "undefined" ? localStorage.getItem("bc-actor") : null;
    if (saved) setActor(saved);
  }, []);

  const load = useCallback(() => {
    api<ProjectDetail>(`/api/projects/${projectId}`).then(setData).catch((e) => setError(e.message));
  }, [projectId]);
  useEffect(() => { load(); }, [load]);

  // elegir pestaña inicial inteligente
  useEffect(() => {
    if (!data) return;
    if (data.stats.fuentesIfc === 0 && data.stats.fuentes <= 1) setTab("fuentes");
  }, [data]);

  const setActorPersist = (v: string) => {
    setActor(v);
    localStorage.setItem("bc-actor", v);
  };

  if (error) {
    return (
      <div className="min-h-screen"><Nav /><div className="mx-auto max-w-xl px-6 py-24 text-center">
        <p className="text-sm text-rose-300">{error}</p>
        <Link href="/" className="mt-4 inline-flex items-center gap-1 text-xs text-acc"><ArrowLeft size={13} /> Volver a proyectos</Link>
      </div></div>
    );
  }

  if (!data) {
    return <div className="min-h-screen"><Nav /><Spinner label="Abriendo el proyecto…" /></div>;
  }

  const { project, stats } = data;
  const totalCantidades = Object.values(stats.cantidadesPorEstado).reduce((a, b) => a + b, 0);

  return (
    <div className="min-h-screen">
      <Nav />
      {/* Encabezado del proyecto */}
      <div className="border-b border-line bg-ink-850/60">
        <div className="mx-auto max-w-[1500px] px-4 py-4 sm:px-6">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <Link href="/" className="rounded-md p-1 text-mist hover:bg-ink-700 hover:text-white"><ArrowLeft size={15} /></Link>
                <span className="font-mono text-[11px] font-bold tracking-widest text-acc">{project.code}</span>
                <Chip className="border-line-strong bg-ink-750 text-mist">
                  <Boxes size={11} /> {stats.fuentesIfc} IFC
                </Chip>
              </div>
              <h1 className="mt-1 text-xl font-extrabold tracking-tight text-white">{project.name}</h1>
              <p className="text-xs text-mist">{project.client ?? "Sin cliente"}{project.location ? ` · ${project.location}` : ""}</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="hidden items-center gap-3 rounded-lg border border-line bg-ink-800 px-3 py-1.5 sm:flex">
                <Stat label="Elementos" value={stats.elementos} />
                <span className="h-6 w-px bg-line" />
                <Stat label="Correspondencias" value={Object.values(stats.matchesPorEstado).reduce((a, b) => a + b, 0)} />
                <span className="h-6 w-px bg-line" />
                <Stat label="Cantidades" value={totalCantidades} />
                <span className="h-6 w-px bg-line" />
                <Stat label="Validadas" value={stats.cantidadesPorEstado.VALIDADA ?? 0} accent />
              </div>
              <Link href={`/proyectos/${projectId}/documentos`}>
                <Btn size="sm" icon={FileText}>Documentos</Btn>
              </Link>
              <label className="flex items-center gap-1.5 rounded-lg border border-line bg-ink-800 px-2.5 py-1.5" title="Nombre del profesional que valida. Queda registrado en cada decisión.">
                <UserRound size={13} className="text-acc" />
                <Input
                  value={actor}
                  onChange={(e) => setActorPersist(e.target.value)}
                  placeholder="Profesional que valida"
                  className="h-6 w-44 border-0 bg-transparent px-1 py-0 text-xs focus:border-0"
                />
              </label>
            </div>
          </div>

          {/* Pestañas */}
          <div className="mt-4 flex gap-1 overflow-x-auto pb-0.5">
            {TABS.map((t) => {
              const n = t.badge?.(stats) ?? 0;
              const active = tab === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={cx(
                    "flex shrink-0 items-center gap-1.5 rounded-t-lg border-b-2 px-3.5 py-2 text-xs font-semibold transition-colors",
                    active ? "border-acc bg-ink-800/80 text-acc" : "border-transparent text-mist hover:bg-ink-800/50 hover:text-slate-200"
                  )}
                >
                  <t.icon size={14} />
                  {t.label}
                  {n > 0 && (
                    <span className={cx("rounded-md px-1.5 py-0.5 font-mono text-[10px] font-bold", active ? "bg-acc/15 text-acc" : "bg-ink-700 text-mist")}>{n}</span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-[1500px] px-4 py-6 sm:px-6">
        {tab === "fuentes" && <Fuentes projectId={projectId} actor={actor} onChanged={load} goTab={setTab} />}
        {tab === "evidencia" && <Evidencia projectId={projectId} actor={actor} onChanged={load} />}
        {tab === "agrupacion" && <Agrupacion projectId={projectId} actor={actor} onChanged={load} goTab={setTab} />}
        {tab === "correspondencias" && <Correspondencias projectId={projectId} actor={actor} onChanged={load} goTab={setTab} />}
        {tab === "cantidades" && <Cantidades projectId={projectId} actor={actor} onChanged={load} />}
        {tab === "estructura" && <Estructura projectId={projectId} actor={actor} onChanged={load} goTab={setTab} />}
        {tab === "documentos" && <DocumentosConfig projectId={projectId} actor={actor} onChanged={load} />}
        {tab === "trazabilidad" && <Trazabilidad projectId={projectId} />}
      </main>
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: number; accent?: boolean }) {
  return (
    <div className="text-center">
      <p className={cx("font-mono text-sm font-bold tabular-nums", accent ? "text-emerald-400" : "text-white")}>{value}</p>
      <p className="text-[9px] font-semibold uppercase tracking-wider text-fog">{label}</p>
    </div>
  );
}

export { KIND_META };
