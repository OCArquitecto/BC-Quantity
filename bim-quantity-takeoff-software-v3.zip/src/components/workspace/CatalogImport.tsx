"use client";

import { useRef, useState } from "react";
import { Upload, FileSpreadsheet, ArrowRight, CheckCircle2, TriangleAlert } from "lucide-react";
import { Alert, Btn, Card, Chip, Field, Input, Select, Spinner, cx } from "@/components/ui";
import { fmt } from "@/lib/client";

interface Analysis {
  hojas: string[];
  hoja: string;
  filas: number;
  sugerencia: { headerRow: number; code: number; name: number; unit: number; price: number; chapter: number; section: number };
  columnas: { index: number; letra: string; encabezado: string; muestra: string[] }[];
  preview: string[][];
}

interface Result {
  hoja: string; filasLeidas: number; actividadesCreadas: number; preciosActualizados: number;
  duplicadasOmitidas: number; codigosGenerados: number; itemsSinPrecio: number;
  totalCatalogo: number; encabezadosDetectados: number;
  muestra: { code: string; name: string; unit: string; price: number }[];
}

const CAMPOS: { key: keyof Analysis["sugerencia"]; label: string; hint: string; required?: boolean }[] = [
  { key: "code", label: "Código / ítem", hint: "Si no existe, se generará uno automático" },
  { key: "name", label: "Descripción de la actividad", hint: "Obligatorio", required: true },
  { key: "unit", label: "Unidad de medida", hint: "M2, M3, ML, UND…" },
  { key: "price", label: "Valor unitario", hint: "Precio de la empresa (sin necesidad de APU)" },
  { key: "chapter", label: "Capítulo (opcional)", hint: "Si el archivo trae una columna de capítulo" },
  { key: "section", label: "Subcapítulo (opcional)", hint: "Si el archivo trae una columna de subcapítulo" },
];

/** Asistente de importación de catálogos con mapeo manual de columnas. */
export function CatalogImport({ onDone }: { onDone: () => void }) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [map, setMap] = useState<Analysis["sugerencia"] | null>(null);
  const [sheet, setSheet] = useState("");
  const [headerRow, setHeaderRow] = useState(0);
  const [replacePrices, setReplacePrices] = useState(true);
  const [defaultChapter, setDefaultChapter] = useState({ code: "90", name: "CATÁLOGO IMPORTADO" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Result | null>(null);

  const analyze = async (f: File, sheetName?: string) => {
    setBusy(true);
    setError(null);
    try {
      const fd = new FormData();
      fd.set("file", f);
      if (sheetName) fd.set("sheet", sheetName);
      const res = await fetch("/api/catalog/import?mode=analyze", { method: "POST", body: fd });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "No se pudo leer el archivo");
      setAnalysis(d);
      setMap(d.sugerencia);
      setSheet(d.hoja);
      setHeaderRow(d.sugerencia.headerRow);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const onPick = () => {
    const f = fileRef.current?.files?.[0];
    if (!f) { setError("Seleccione un archivo Excel."); return; }
    setFile(f);
    setResult(null);
    analyze(f);
  };

  const runImport = async () => {
    if (!file || !map) return;
    setBusy(true);
    setError(null);
    try {
      const fd = new FormData();
      fd.set("file", file);
      fd.set("sheet", sheet);
      fd.set("headerRow", String(headerRow));
      fd.set("code", String(map.code));
      fd.set("name", String(map.name));
      fd.set("unit", String(map.unit));
      fd.set("price", String(map.price));
      fd.set("chapter", String(map.chapter));
      fd.set("section", String(map.section));
      fd.set("replacePrices", replacePrices ? "1" : "0");
      fd.set("defaultChapterCode", defaultChapter.code);
      fd.set("defaultChapterName", defaultChapter.name);
      const res = await fetch("/api/catalog/import?mode=import", { method: "POST", body: fd });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "No se pudo importar");
      setResult(d);
      onDone();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const colLabel = (i: number) => {
    if (i < 0) return "— no usar —";
    const c = analysis?.columnas.find((x) => x.index === i);
    return `${c?.letra ?? i}: ${c?.encabezado || "(sin encabezado)"}${c?.muestra.length ? ` · ej. ${c.muestra[0]}` : ""}`;
  };

  return (
    <div className="space-y-4">
      {error && <Alert tone="error">{error}</Alert>}

      {/* Paso 1: archivo */}
      <Card className="p-4">
        <p className="mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.14em] text-mist">
          <FileSpreadsheet size={12} /> 1. Archivo del catálogo o listado de precios
        </p>
        <div className="flex flex-wrap items-end gap-2">
          <div className="min-w-64 flex-1">
            <Input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" className="py-1.5 text-xs" onChange={onPick} />
          </div>
          {analysis && (
            <Select value={sheet} onChange={(e) => { setSheet(e.target.value); if (file) analyze(file, e.target.value); }} className="w-56">
              {analysis.hojas.map((h) => <option key={h} value={h}>{h}</option>)}
            </Select>
          )}
        </div>
        <p className="mt-2 text-[11px] leading-relaxed text-fog">
          Funciona con cualquier estructura de Excel: usted decide qué columna corresponde a cada dato.
          Ideal para presupuestar con los <strong>precios unitarios propios de cada empresa</strong>, sin elaborar APUs.
        </p>
      </Card>

      {busy && !analysis && <Spinner label="Analizando el archivo…" />}

      {/* Paso 2: mapeo */}
      {analysis && map && (
        <>
          <Card className="p-4">
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-mist">2. Asignación de columnas</p>
              <div className="flex items-center gap-2">
                <Chip className="border-line bg-ink-750 text-mist">{analysis.filas} filas de datos</Chip>
                <label className="flex items-center gap-1.5 text-[11px] text-mist">
                  Fila de encabezados
                  <Input value={String(headerRow + 1)} onChange={(e) => setHeaderRow(Math.max(0, (parseInt(e.target.value, 10) || 1) - 1))}
                    className="h-7 w-16 py-0 text-center font-mono text-xs" />
                </label>
              </div>
            </div>
            <div className="grid gap-2.5 sm:grid-cols-2">
              {CAMPOS.map((c) => (
                <Field key={c.key} label={`${c.label}${c.required ? " *" : ""}`} hint={c.hint}>
                  <Select
                    value={String(map[c.key])}
                    onChange={(e) => setMap({ ...map, [c.key]: parseInt(e.target.value, 10) })}
                    className={cx(c.required && map[c.key] < 0 && "border-rose-400/60")}
                  >
                    <option value="-1">— no usar —</option>
                    {analysis.columnas.map((col) => (
                      <option key={col.index} value={col.index}>{colLabel(col.index)}</option>
                    ))}
                  </Select>
                </Field>
              ))}
            </div>
            {map.code < 0 && (
              <div className="mt-3">
                <Alert tone="warn">
                  Sin columna de código se generarán códigos automáticos. Indique el capítulo donde agrupar los ítems:
                  <div className="mt-2 flex gap-2">
                    <Input value={defaultChapter.code} onChange={(e) => setDefaultChapter({ ...defaultChapter, code: e.target.value })}
                      className="w-24 font-mono" placeholder="90" />
                    <Input value={defaultChapter.name} onChange={(e) => setDefaultChapter({ ...defaultChapter, name: e.target.value })}
                      placeholder="CATÁLOGO IMPORTADO" />
                  </div>
                </Alert>
              </div>
            )}
            <label className="mt-3 flex cursor-pointer items-center gap-2 text-xs text-mist">
              <input type="checkbox" checked={replacePrices} onChange={(e) => setReplacePrices(e.target.checked)} className="accent-cyan-400" />
              Actualizar el precio de las actividades que ya existan con el mismo código
            </label>
          </Card>

          {/* Paso 3: vista previa */}
          <Card className="overflow-hidden">
            <p className="border-b border-line bg-ink-800/60 px-4 py-2 text-[11px] font-bold uppercase tracking-[0.14em] text-mist">
              3. Vista previa de la interpretación
            </p>
            <div className="max-h-64 overflow-auto">
              <table className="w-full text-left text-[11px]">
                <thead className="sticky top-0 bg-ink-800 text-[10px] uppercase tracking-wider text-fog">
                  <tr>
                    <th className="px-3 py-1.5">Código</th>
                    <th className="px-3 py-1.5">Descripción</th>
                    <th className="px-3 py-1.5 text-center">Unidad</th>
                    <th className="px-3 py-1.5 text-right">Valor unitario</th>
                  </tr>
                </thead>
                <tbody>
                  {analysis.preview.slice(0, 12).map((row, i) => (
                    <tr key={i} className="border-t border-line/40">
                      <td className="px-3 py-1.5 font-mono text-slate-300">{map.code >= 0 ? row[map.code] ?? "" : <span className="text-fog">auto</span>}</td>
                      <td className="max-w-80 truncate px-3 py-1.5 text-slate-100">{map.name >= 0 ? row[map.name] ?? "" : ""}</td>
                      <td className="px-3 py-1.5 text-center font-mono text-mist">{map.unit >= 0 ? row[map.unit] ?? "" : ""}</td>
                      <td className="px-3 py-1.5 text-right font-mono text-emerald-300">{map.price >= 0 ? row[map.price] ?? "" : ""}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <div className="flex items-center justify-end gap-2">
            <Btn variant="primary" icon={Upload} loading={busy} disabled={map.name < 0} onClick={runImport}>
              Importar al catálogo maestro <ArrowRight size={13} />
            </Btn>
          </div>
        </>
      )}

      {/* Resultado */}
      {result && (
        <Card className="border-emerald-400/30 bg-emerald-400/5 p-4">
          <p className="mb-2 flex items-center gap-1.5 text-sm font-bold text-emerald-300">
            <CheckCircle2 size={15} /> Importación completada
          </p>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {[
              ["Filas leídas", result.filasLeidas],
              ["Actividades creadas", result.actividadesCreadas],
              ["Precios actualizados", result.preciosActualizados],
              ["Total en catálogo", result.totalCatalogo],
            ].map(([l, v]) => (
              <div key={String(l)} className="rounded-lg border border-line bg-ink-800 px-2.5 py-2">
                <p className="font-mono text-base font-bold text-white">{fmt(Number(v), 0)}</p>
                <p className="text-[10px] uppercase tracking-wider text-fog">{String(l)}</p>
              </div>
            ))}
          </div>
          {result.itemsSinPrecio > 0 && (
            <p className="mt-2 flex items-center gap-1.5 text-[11px] text-amber-300">
              <TriangleAlert size={12} /> {result.itemsSinPrecio} ítem(s) quedaron sin precio: revise la columna de valor unitario.
            </p>
          )}
          {result.muestra.length > 0 && (
            <div className="mt-2 space-y-0.5">
              <p className="text-[10px] uppercase tracking-wider text-fog">Ejemplos importados</p>
              {result.muestra.slice(0, 5).map((m) => (
                <p key={m.code} className="font-mono text-[10.5px] text-mist">
                  {m.code} · {m.name.slice(0, 50)} · {m.unit} · $ {fmt(m.price, 0)}
                </p>
              ))}
            </div>
          )}
        </Card>
      )}
    </div>
  );
}
