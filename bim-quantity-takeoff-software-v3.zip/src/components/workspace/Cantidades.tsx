"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Ruler, ShieldCheck, XCircle, PencilLine, RefreshCcw, Plus, Link2,
  HelpCircle, FileSpreadsheet, Hand, Boxes, Database, SlidersHorizontal,
  CopyPlus, GitBranch, CheckSquare, Square, Box as BoxIcon, TriangleAlert, Trash2,
} from "lucide-react";
import {
  Alert, Btn, Card, Chip, Drawer, Empty, Input, Kv, Modal, SectionTitle,
  Select, Spinner, StatusChip, Textarea, cx,
} from "@/components/ui";
import { api, fmt, KIND_META, METHOD_META, STATUS_META, nuevaFecha } from "@/lib/client";
import { ActivityPicker, type CatalogActivity } from "./ActivityPicker";
import { Viewer3D, type ViewerElement } from "./Viewer3D";

interface MeasureConfig {
  areaBasis?: string; dimension?: string; volumeBasis?: string; factor?: number; note?: string;
}

interface QuantityRow {
  id: string;
  activityId: string | null;
  sourceId: string | null;
  sourceKind: string;
  derivedFromId: string | null;
  label: string | null;
  value: number | null;
  unit: string;
  method: string;
  measureConfig: MeasureConfig | null;
  rule: string | null;
  evidence: Record<string, unknown> | null;
  elementIds: string[];
  elementCount: number;
  status: "PENDIENTE" | "PROPUESTA" | "VALIDADA" | "RECHAZADA";
  note: string | null;
  validatedBy: string | null;
  validatedAt: string | null;
  createdAt: string;
  actividad: CatalogActivity | null;
  fuente: { id: string; name: string; kind: string } | null;
  derivadaDe: { id: string; actividad: string | null; valor: number | null; unidad: string; estado: string } | null;
  derivadas: number;
}

interface MeasurePreview {
  unidad: string;
  elementos: number;
  variantes: { key: string; label: string; config: MeasureConfig; value: number | null; medidos: number; sinDato: number; campos: string[] }[];
  detalle: {
    id: string; nombre: string | null; clase: string; nivel: string | null;
    largo: number | null; ancho: number | null; alto: number | null; espesor: number | null;
    areaNeta: number | null; areaBruta: number | null; superficie: number | null;
    perimetro: number | null; volumen: number | null; seccion: number | null;
  }[];
  alertas: string[];
}

const FILTROS = ["TODAS", "PROPUESTA", "PENDIENTE", "VALIDADA", "RECHAZADA"];

const AREA_OPTS = [
  { v: "NETA", l: "Área neta (descuenta vanos si el modelo los reporta)" },
  { v: "UNA_CARA", l: "Una sola cara (revestimientos por un lado)" },
  { v: "DOS_CARAS", l: "Ambas caras (×2) — pañete/pintura a dos lados" },
  { v: "BRUTA", l: "Área bruta (sin descuentos)" },
  { v: "PLANTA", l: "Área en planta (pisos, losas)" },
  { v: "LATERAL", l: "Superficie lateral (perímetro × longitud)" },
  { v: "SUPERFICIE_TOTAL", l: "Superficie total envolvente" },
];
const DIM_OPTS = [
  { v: "LARGO", l: "Longitud" }, { v: "ALTO", l: "Altura" }, { v: "ANCHO", l: "Ancho" },
  { v: "ESPESOR", l: "Espesor" }, { v: "PERIMETRO", l: "Perímetro" },
];

function digits(unit: string) { return unit === "M3" ? 3 : 2; }

export function Cantidades({ projectId, actor, onChanged }: { projectId: string; actor: string; onChanged: () => void }) {
  const [rows, setRows] = useState<QuantityRow[] | null>(null);
  const [filtro, setFiltro] = useState("TODAS");
  const [q, setQ] = useState("");
  const [detail, setDetail] = useState<QuantityRow | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [showAdd, setShowAdd] = useState(false);
  const [editQty, setEditQty] = useState<QuantityRow | null>(null);
  const [assignQty, setAssignQty] = useState<QuantityRow | null>(null);
  const [configQty, setConfigQty] = useState<QuantityRow | null>(null);
  const [deriveQty, setDeriveQty] = useState<QuantityRow | null>(null);
  const [viewerQty, setViewerQty] = useState<QuantityRow | null>(null);
  const [viewerEls, setViewerEls] = useState<ViewerElement[] | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [addActivity, setAddActivity] = useState<CatalogActivity | null>(null);
  const [addValue, setAddValue] = useState("");
  const [addNote, setAddNote] = useState("");
  const [editValue, setEditValue] = useState("");
  const [editNote, setEditNote] = useState("");
  const [cfg, setCfg] = useState<MeasureConfig>({});
  const [preview, setPreview] = useState<MeasurePreview | null>(null);
  const [deriveLabel, setDeriveLabel] = useState("");
  const [deriveEls, setDeriveEls] = useState<ViewerElement[] | null>(null);
  const [deriveSel, setDeriveSel] = useState<Set<string>>(new Set());
  const [derivePicks, setDerivePicks] = useState<
    { activity: CatalogActivity; config: MeasureConfig; label: string }[]
  >([]);
  const [deleteQty, setDeleteQty] = useState<QuantityRow | null>(null);
  const [deleteReason, setDeleteReason] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(() => {
    api<{ quantities: QuantityRow[] }>(`/api/quantities?projectId=${projectId}`).then((d) => {
      setRows(d.quantities);
      setSelected(new Set());
    });
  }, [projectId]);
  useEffect(() => { load(); }, [load]);

  const act = async (id: string, action: string, extra?: Record<string, unknown>) => {
    setBusyId(id);
    setNotice(null);
    setError(null);
    try {
      const d = await api<{ value?: number; rule?: string; aviso?: string | null }>(`/api/quantities/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, actor: actor || undefined, ...extra }),
      });
      if (action === "validate") setNotice("Cantidad VALIDADA: ya forma parte de la estructura del proyecto.");
      if (action === "reject") setNotice("Cantidad rechazada. La evidencia original se conserva.");
      if (action === "remeasure") setNotice(`Re-medición: ${fmt(d.value ?? null)} — queda como PROPUESTA.${d.aviso ? ` ${d.aviso}.` : ""}`);
      if (action === "configure") setNotice(`Regla de medición actualizada. Nueva cantidad: ${fmt(d.value ?? null)}.`);
      setDetail(null); setEditQty(null); setAssignQty(null); setConfigQty(null);
      load(); onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusyId(null);
    }
  };

  const runBulk = async (action: "validate" | "reject" | "delete") => {
    if (action === "delete" && !confirm(`¿Eliminar definitivamente ${selected.size} cantidad(es) y sus derivadas? La evidencia IFC no se modifica.`)) return;
    setBusy(true);
    try {
      const d = await api<{ validadas: number; rechazadas: number; eliminadas: number; omitidas: number; nodosEstructuraRetirados?: number }>("/api/quantities/bulk", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: [...selected], action, actor: actor || undefined }),
      });
      setNotice(action === "delete"
        ? `Lote eliminado: ${d.eliminadas} cantidad(es) retiradas${d.nodosEstructuraRetirados ? ` y ${d.nodosEstructuraRetirados} línea(s) vacías de la estructura` : ""}.`
        : `Lote: ${d.validadas} validadas, ${d.rechazadas} rechazadas${d.omitidas ? `, ${d.omitidas} omitidas sin valor` : ""}.`);
      load(); onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const addManual = async () => {
    if (!addActivity) return;
    const value = addValue.trim() === "" ? undefined : Number(addValue.replace(",", "."));
    if (value !== undefined && !isFinite(value)) { setError("Cantidad inválida."); return; }
    setBusy(true);
    try {
      await api("/api/quantities", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectId, activityId: addActivity.id, value, note: addNote || undefined, actor: actor || undefined }),
      });
      setNotice(value !== undefined ? "Medición manual registrada y firmada." : "Actividad añadida como PENDIENTE de medición.");
      setShowAdd(false); setAddActivity(null); setAddValue(""); setAddNote("");
      load(); onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const openDerive = async (r: QuantityRow) => {
    setDeriveQty(r);
    setDeriveLabel("");
    setDeriveEls(null);
    setDeriveSel(new Set());
    setDerivePicks([]);
    const d = await api<{ elements: ViewerElement[] }>(`/api/elements?projectId=${projectId}&quantityId=${r.id}`);
    setDeriveEls(d.elements);
    setDeriveSel(new Set(d.elements.map((e) => e.id)));
  };

  /** Añade una actividad a la lista de derivadas por crear. */
  const addDerivePick = (target: CatalogActivity) => {
    setDerivePicks((current) => {
      if (current.some((p) => p.activity.id === target.id)) return current;
      const base: MeasureConfig =
        target.method === "SUPERFICIE_GEOMETRICA" ? { areaBasis: "UNA_CARA", factor: 1 }
          : target.method === "DIMENSION" ? { dimension: "LARGO", factor: 1 }
            : target.method === "VOLUMEN_GEOMETRICO" ? { volumeBasis: "NETO", factor: 1 }
              : { factor: 1 };
      return [...current, { activity: target, config: base, label: "" }];
    });
  };

  /** Crea TODAS las actividades derivadas seleccionadas en una sola operación. */
  const deriveAll = async () => {
    if (!deriveQty || !derivePicks.length) return;
    setBusy(true);
    setError(null);
    try {
      const d = await api<{
        creadas: number;
        quantities: { value: number | null; unit: string }[];
        omitidas: { actividad: string; motivo: string }[];
        aviso: string | null;
      }>("/api/quantities/derive", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          quantityId: deriveQty.id,
          activities: derivePicks.map((p) => ({
            activityId: p.activity.id,
            measureConfig: p.config,
            label: p.label || deriveLabel || undefined,
          })),
          actor: actor || undefined,
          elementIds: deriveEls && deriveSel.size < deriveEls.length ? [...deriveSel] : undefined,
        }),
      });
      const partes = [`${d.creadas} actividad(es) derivadas sobre ${deriveSel.size} elemento(s)`];
      if (d.omitidas.length) partes.push(`${d.omitidas.length} omitida(s): ${d.omitidas.map((o) => `${o.actividad} — ${o.motivo}`).join(" · ")}`);
      if (d.aviso) partes.push(d.aviso);
      setNotice(partes.join(". ") + ". Cada una conserva el vínculo con su origen.");
      setDeriveQty(null); setDeriveLabel(""); setDeriveEls(null);
      setDeriveSel(new Set()); setDerivePicks([]);
      load(); onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  /** Elimina definitivamente una cantidad (y sus derivadas). */
  const removeQuantity = async (r: QuantityRow, motivo?: string) => {
    setBusyId(r.id);
    setError(null);
    try {
      const d = await api<{ eliminadas: number }>(
        `/api/quantities/${r.id}?actor=${encodeURIComponent(actor || "")}&motivo=${encodeURIComponent(motivo ?? "")}`,
        { method: "DELETE" }
      );
      setNotice(`Cantidad eliminada${d.eliminadas > 1 ? ` junto con ${d.eliminadas - 1} derivada(s)` : ""}. La evidencia IFC permanece intacta y la decisión quedó registrada.`);
      setDeleteQty(null);
      setDetail(null);
      load(); onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusyId(null);
    }
  };


  const openConfig = async (r: QuantityRow) => {
    setConfigQty(r);
    setCfg(r.measureConfig ?? {});
    setPreview(null);
    try {
      const d = await api<MeasurePreview>(`/api/measure-preview?quantityId=${r.id}&method=${r.method}`);
      setPreview(d);
    } catch {
      setPreview({ unidad: r.unit, elementos: r.elementCount, variantes: [], detalle: [], alertas: [] });
    }
  };

  const openViewer = async (qty: QuantityRow) => {
    setViewerQty(qty); setViewerEls(null);
    const d = await api<{ elements: ViewerElement[] }>(`/api/elements?projectId=${projectId}&quantityId=${qty.id}`);
    setViewerEls(d.elements);
  };

  const needle = q.trim().toLowerCase();
  const filtered = (rows ?? []).filter((r) => {
    if (filtro !== "TODAS" && r.status !== filtro) return false;
    if (needle && !`${r.actividad?.code ?? ""} ${r.actividad?.name ?? ""} ${r.label ?? ""} ${r.note ?? ""}`.toLowerCase().includes(needle)) return false;
    return true;
  });
  const counts = Object.fromEntries(FILTROS.slice(1).map((f) => [f, rows?.filter((r) => r.status === f).length ?? 0]));
  // Cualquier cantidad puede seleccionarse: validar/rechazar aplica a las
  // pendientes y propuestas; eliminar aplica a todas.
  const selectable = filtered;
  const allSel = selectable.length > 0 && selectable.every((r) => selected.has(r.id));

  return (
    <div className="space-y-5 bc-fade-up">
      <SectionTitle
        title="Cantidades del proyecto"
        desc="Cada cantidad declara actividad, valor, unidad, fuente, elementos, método, regla, evidencia y validación."
        right={<Btn variant="primary" icon={Plus} onClick={() => { setShowAdd(true); setAddActivity(null); setAddValue(""); setAddNote(""); }}>Medición manual</Btn>}
      />

      {notice && <Alert tone="ok">{notice}</Alert>}
      {error && <Alert tone="error">{error}</Alert>}

      <div className="flex flex-wrap items-center gap-2">
        {FILTROS.map((f) => (
          <button key={f} onClick={() => setFiltro(f)}
            className={cx("flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors",
              filtro === f ? "border-acc/60 bg-acc/10 text-acc" : "border-line bg-ink-800 text-mist hover:text-white")}>
            {f === "TODAS" ? "Todas" : STATUS_META[f].label}
            <span className="rounded bg-ink-700 px-1.5 font-mono text-[10px]">{f === "TODAS" ? rows?.length ?? 0 : counts[f]}</span>
          </button>
        ))}
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar actividad…" className="w-56" />
        {selectable.length > 0 && (
          <Btn size="sm" icon={allSel ? CheckSquare : Square}
            onClick={() => setSelected(allSel ? new Set() : new Set(selectable.map((r) => r.id)))}>
            {allSel ? "Quitar selección" : `Seleccionar ${selectable.length}`}
          </Btn>
        )}
      </div>

      {selected.size > 0 && (
        <Card className="sticky top-16 z-20 flex flex-wrap items-center gap-2 border-acc/40 bg-ink-800/95 p-3 backdrop-blur bc-glow">
          <span className="text-xs font-bold text-white">{selected.size} cantidad(es) seleccionada(s)</span>
          <div className="ml-auto flex gap-2">
            <Btn size="sm" variant="ok" icon={ShieldCheck} loading={busy} onClick={() => runBulk("validate")}>Validar seleccionadas</Btn>
            <Btn size="sm" variant="danger" icon={XCircle} loading={busy} onClick={() => runBulk("reject")}>Rechazar</Btn>
            <Btn size="sm" variant="danger" icon={Trash2} loading={busy} onClick={() => runBulk("delete")}>Eliminar</Btn>
            <Btn size="sm" onClick={() => setSelected(new Set())}>Cancelar</Btn>
          </div>
        </Card>
      )}

      {rows === null ? (
        <Spinner label="Cargando cantidades…" />
      ) : filtered.length === 0 ? (
        <Empty icon={Ruler} title={rows.length === 0 ? "Sin cantidades todavía" : "Sin resultados"}
          hint={rows.length === 0 ? "Las cantidades nacen al validar correspondencias, importar Excel o medir manualmente." : "Ajuste los filtros."} />
      ) : (
        <Card className="overflow-hidden">
          <div className="max-h-[560px] overflow-auto">
            <table className="w-full text-left text-xs">
              <thead className="sticky top-0 z-10 bg-ink-800 text-[10px] uppercase tracking-wider text-fog">
                <tr>
                  <th className="w-8 px-3 py-2.5" />
                  <th className="px-4 py-2.5 font-semibold">Actividad</th>
                  <th className="px-4 py-2.5 text-right font-semibold">Cantidad</th>
                  <th className="px-4 py-2.5 font-semibold">Regla de medición</th>
                  <th className="px-4 py-2.5 font-semibold">Origen</th>
                  <th className="px-4 py-2.5 text-right font-semibold">Elem.</th>
                  <th className="px-4 py-2.5 font-semibold">Estado</th>
                  <th className="px-4 py-2.5 text-right font-semibold">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((r) => {
                  const ev = (r.evidence ?? {}) as { elementosSinDato?: number };
                  const selectableRow = true;
                  return (
                    <tr key={r.id} onClick={() => setDetail(r)}
                      className={cx("cursor-pointer border-t border-line/50 transition-colors hover:bg-ink-800/70",
                        r.status === "RECHAZADA" && "opacity-50", selected.has(r.id) && "bg-acc/5")}>
                      <td className="px-3 py-2.5" onClick={(e) => e.stopPropagation()}>
                        {selectableRow && (
                          <button onClick={() => setSelected((s) => { const n = new Set(s); if (n.has(r.id)) n.delete(r.id); else n.add(r.id); return n; })}
                            className="text-mist hover:text-acc">
                            {selected.has(r.id) ? <CheckSquare size={14} className="text-acc" /> : <Square size={14} />}
                          </button>
                        )}
                      </td>
                      <td className="max-w-72 px-4 py-2.5">
                        {r.actividad ? (
                          <>
                            <p className="truncate font-medium text-slate-100">
                              <span className="mr-1.5 font-mono text-[11px] font-bold text-acc">{r.actividad.code}</span>
                              {r.label ?? r.actividad.name}
                            </p>
                            <div className="mt-0.5 flex flex-wrap items-center gap-1">
                              {r.derivadaDe && (
                                <Chip className="border-violet-400/30 bg-violet-400/10 text-violet-300" title={`Derivada de ${r.derivadaDe.actividad}`}>
                                  <GitBranch size={10} /> derivada
                                </Chip>
                              )}
                              {r.derivadas > 0 && <Chip className="border-line bg-ink-750 text-mist">{r.derivadas} derivada(s)</Chip>}
                              {(ev.elementosSinDato ?? 0) > 0 && (
                                <Chip className="border-amber-400/30 bg-amber-400/10 text-amber-300" title="Elementos sin datos de medición">
                                  <TriangleAlert size={10} /> {ev.elementosSinDato} sin datos
                                </Chip>
                              )}
                            </div>
                          </>
                        ) : (
                          <span className="text-amber-300">Sin actividad — asigne una</span>
                        )}
                      </td>
                      <td className="px-4 py-2.5 text-right">
                        <span className={cx("font-mono text-sm font-bold tabular-nums", r.value === null || r.value === 0 ? "text-amber-300" : "text-white")}>
                          {fmt(r.value, digits(r.unit))}
                        </span>
                        <span className="ml-1 font-mono text-[10px] text-fog">{r.unit}</span>
                      </td>
                      <td className="max-w-52 px-4 py-2.5">
                        <Chip className="border-violet-400/30 bg-violet-400/10 text-violet-300">{METHOD_META[r.method]?.short ?? r.method}</Chip>
                        {r.measureConfig?.areaBasis && <Chip className="ml-1 border-line bg-ink-750 text-mist">{r.measureConfig.areaBasis.replace("_", " ").toLowerCase()}</Chip>}
                        {r.measureConfig?.dimension && <Chip className="ml-1 border-line bg-ink-750 text-mist">{r.measureConfig.dimension.toLowerCase()}</Chip>}
                        {r.measureConfig?.factor && r.measureConfig.factor !== 1 && <Chip className="ml-1 border-amber-400/30 bg-amber-400/10 text-amber-300">×{r.measureConfig.factor}</Chip>}
                      </td>
                      <td className="px-4 py-2.5">
                        <Chip className={KIND_META[r.sourceKind]?.cls ?? "border-line text-mist"}>
                          {r.sourceKind === "MANUAL" ? <Hand size={11} /> : r.sourceKind === "EXCEL" ? <FileSpreadsheet size={11} /> : <Boxes size={11} />}
                          {r.fuente?.name ?? (r.sourceKind === "IFC" ? "IFC (grupo)" : r.sourceKind)}
                        </Chip>
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-300">{r.elementCount}</td>
                      <td className="px-4 py-2.5"><StatusChip status={r.status} meta={STATUS_META} /></td>
                      <td className="px-4 py-2.5" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          {(r.status === "PROPUESTA" || (r.status === "PENDIENTE" && r.value !== null)) && (
                            <Btn size="sm" variant="ok" icon={ShieldCheck} loading={busyId === r.id} onClick={() => act(r.id, "validate")}>Validar</Btn>
                          )}
                          {r.elementCount > 0 && r.method !== "MANUAL" && (
                            <Btn size="sm" title="Cambiar la regla de medición (cara, dimensión, factor)"
                              onClick={() => openConfig(r)}>
                              <SlidersHorizontal size={12} />
                            </Btn>
                          )}
                          {r.status === "VALIDADA" && r.elementCount > 0 && (
                            <Btn size="sm" title="Derivar acabado sobre estos mismos elementos" onClick={() => openDerive(r)}>
                              <CopyPlus size={12} />
                            </Btn>
                          )}
                          <Btn size="sm" title="Cambiar la actividad asignada" onClick={() => setAssignQty(r)}>
                            <Link2 size={12} />
                          </Btn>
                          <Btn size="sm" title="Corregir valor" onClick={() => { setEditQty(r); setEditValue(r.value?.toString() ?? ""); setEditNote(r.note ?? ""); }}>
                            <PencilLine size={12} />
                          </Btn>
                          <Btn size="sm" variant="danger" title="Eliminar esta cantidad"
                            onClick={() => { setDeleteQty(r); setDeleteReason(""); }}>
                            <Trash2 size={12} />
                          </Btn>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* ---------------- DRAWER DE TRAZABILIDAD ---------------- */}
      <Drawer open={!!detail} onClose={() => setDetail(null)} width="580px" title={
        <span className="flex items-center gap-2"><HelpCircle size={14} className="text-acc" /> ¿De dónde salió esta cantidad?</span>
      }>
        {detail && (
          <div className="space-y-4">
            <div className="rounded-xl border border-acc/30 bg-gradient-to-br from-acc/10 to-transparent p-4">
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-mono text-[11px] font-bold text-acc">{detail.actividad?.code ?? "SIN CÓDIGO"}</p>
                  <h4 className="mt-0.5 truncate text-sm font-bold text-white">{detail.label ?? detail.actividad?.name ?? "Actividad sin asignar"}</h4>
                </div>
                <div className="text-right">
                  <p className="font-mono text-2xl font-extrabold tabular-nums text-white">{fmt(detail.value, digits(detail.unit))}</p>
                  <p className="font-mono text-[11px] text-mist">{detail.unit}</p>
                </div>
              </div>
              <div className="mt-2 flex flex-wrap gap-1.5">
                <StatusChip status={detail.status} meta={STATUS_META} />
                <Chip className="border-violet-400/30 bg-violet-400/10 text-violet-300">{METHOD_META[detail.method]?.label ?? detail.method}</Chip>
                {detail.elementCount > 0 && (
                  <button onClick={() => openViewer(detail)} className="flex items-center gap-1 rounded-md border border-line-strong bg-ink-800 px-2 py-0.5 text-[11px] font-semibold text-mist hover:border-acc/50 hover:text-acc">
                    <BoxIcon size={11} /> Ver en 3D
                  </button>
                )}
              </div>
            </div>

            {detail.derivadaDe && (
              <Alert tone="info">
                <span className="flex items-start gap-2">
                  <GitBranch size={13} className="mt-0.5 shrink-0" />
                  <span>
                    Cantidad <strong>derivada</strong> de: {detail.derivadaDe.actividad} ({fmt(detail.derivadaDe.valor)} {detail.derivadaDe.unidad}).
                    Mide los mismos elementos con otra regla. Si el diseño cambia, re-mida el origen y luego esta derivada.
                  </span>
                </span>
              </Alert>
            )}

            <TraceQ n="1" q="¿QUÉ?" a="Actividad del catálogo maestro">
              <p className="text-xs text-slate-200">{detail.actividad ? `${detail.actividad.code} — ${detail.actividad.name}` : "Pendiente de asignación"}</p>
              <p className="text-[10.5px] text-fog">{detail.actividad?.chapterName} · {detail.actividad?.sectionName}</p>
            </TraceQ>

            <TraceQ n="2" q="¿CUÁNTO?" a="Cantidad y unidad">
              <p className="font-mono text-sm font-bold text-white">{fmt(detail.value, digits(detail.unit))} {detail.unit}</p>
              {detail.actividad && detail.actividad.unitPrice > 0 && (
                <p className="mt-0.5 text-[11px] text-emerald-300">
                  Valor de referencia: ${fmt((detail.value ?? 0) * detail.actividad.unitPrice, 0)} (precio catálogo ${fmt(detail.actividad.unitPrice, 0)}/{detail.unit})
                </p>
              )}
            </TraceQ>

            <TraceQ n="3" q="¿DE DÓNDE?" a="Fuente, elementos y evidencia">
              <div className="space-y-1 text-xs">
                <p className="text-slate-200">Origen: <span className="font-semibold">{detail.fuente?.name ?? (detail.sourceKind === "IFC" ? "IFC (agrupación BIM)" : detail.sourceKind)}</span></p>
                <p className="text-slate-200">Elementos: <span className="font-mono font-bold">{detail.elementCount}</span></p>
                {(() => {
                  const ev = (detail.evidence ?? {}) as { fuentes?: string[]; clases?: string[]; familiaBIM?: string[]; criteriosAgrupacion?: Record<string, string> };
                  return (
                    <>
                      {ev.fuentes && <p className="text-[11px] text-mist">Archivos: {ev.fuentes.join(" + ")}</p>}
                      {ev.familiaBIM && <p className="text-[11px] text-mist">Familia BIM: {[...new Set(ev.familiaBIM)].join(", ")}</p>}
                      {ev.criteriosAgrupacion && (
                        <div className="mt-1 flex flex-wrap gap-1">
                          {Object.entries(ev.criteriosAgrupacion).map(([k, v]) => (
                            <Chip key={k} className="border-line bg-ink-750 text-slate-300"><span className="text-fog">{k}:</span>&nbsp;{v}</Chip>
                          ))}
                        </div>
                      )}
                    </>
                  );
                })()}
              </div>
            </TraceQ>

            <TraceQ n="4" q="¿CÓMO?" a="Regla y método de medición">
              <p className="text-[11.5px] leading-relaxed text-slate-200">{detail.rule ?? "—"}</p>
              {(() => {
                const ev = (detail.evidence ?? {}) as { camposUtilizados?: Record<string, number>; elementosSinDato?: number; elementosSinDatoEjemplos?: string[] };
                return (
                  <>
                    {ev.camposUtilizados && (
                      <div className="mt-1.5 space-y-0.5">
                        {Object.entries(ev.camposUtilizados).map(([campo, n]) => (
                          <p key={campo} className="font-mono text-[10.5px] text-mist">{campo} → {n} elemento(s)</p>
                        ))}
                      </div>
                    )}
                    {(ev.elementosSinDato ?? 0) > 0 && (
                      <p className="mt-1.5 text-[10.5px] text-amber-300">
                        {ev.elementosSinDato} elemento(s) sin datos: {(ev.elementosSinDatoEjemplos ?? []).slice(0, 4).join(", ")}…
                      </p>
                    )}
                  </>
                );
              })()}
              {detail.elementCount > 0 && detail.method !== "MANUAL" && (
                <Btn size="sm" className="mt-2" icon={SlidersHorizontal} onClick={() => openConfig(detail)}>
                  Cambiar regla de medición
                </Btn>
              )}
            </TraceQ>

            <TraceQ n="5" q="¿POR QUÉ ESTA ACTIVIDAD?" a="Correspondencia y decisión">
              {(() => {
                const pq = ((detail.evidence ?? {}) as { porQueEstaActividad?: { puntaje?: number; coincidencias?: string[]; decision?: string; reglaBIM?: string } }).porQueEstaActividad;
                if (!pq) {
                  return <p className="text-[11.5px] text-slate-200">
                    {detail.sourceKind === "MANUAL" ? "Introducida por decisión profesional directa."
                      : detail.sourceKind === "EXCEL" ? "Declarada en hoja de cálculo importada."
                        : "Asignación profesional directa."}
                  </p>;
                }
                return (
                  <div className="text-[11.5px] leading-relaxed text-slate-200">
                    {pq.puntaje ? <p>Puntaje de compatibilidad: <span className="font-mono font-bold text-acc">{pq.puntaje}</span></p> : null}
                    {pq.coincidencias?.length ? <p className="mt-0.5">Evidencia: {pq.coincidencias.join(" · ")}</p> : null}
                    {pq.reglaBIM ? <p className="mt-0.5 text-[10.5px] italic text-fog">{pq.reglaBIM}</p> : null}
                    <p className="mt-0.5 text-emerald-300">{pq.decision}</p>
                  </div>
                );
              })()}
            </TraceQ>

            <TraceQ n="6" q="¿QUIÉN VALIDÓ?" a="Firma profesional">
              <Kv k="Validada por" v={detail.validatedBy ?? "Pendiente"} />
              <Kv k="Fecha" v={nuevaFecha(detail.validatedAt)} />
              <Kv k="Calculada" v={nuevaFecha(((detail.evidence ?? {}) as { computadaEn?: string }).computadaEn ?? detail.createdAt)} />
            </TraceQ>

            {(() => {
              const ev = (detail.evidence ?? {}) as { advertencias?: string[]; correccionProfesional?: { valorAnterior?: number; valorNuevo?: number; motivo?: string } };
              return (
                <>
                  {ev.advertencias?.length ? <Alert tone="warn">{ev.advertencias.map((w, i) => <p key={i}>{w}</p>)}</Alert> : null}
                  {ev.correccionProfesional ? (
                    <Alert tone="info">
                      Corrección profesional: {fmt(ev.correccionProfesional.valorAnterior ?? null)} → <strong>{fmt(ev.correccionProfesional.valorNuevo ?? null)}</strong>
                      {ev.correccionProfesional.motivo ? ` — «${ev.correccionProfesional.motivo}»` : ""}
                    </Alert>
                  ) : null}
                </>
              );
            })()}
            {detail.note ? <Alert tone="info">Nota: «{detail.note}»</Alert> : null}

            <div className="flex flex-wrap gap-2 border-t border-line pt-4">
              {(detail.status === "PROPUESTA" || (detail.status === "PENDIENTE" && detail.value !== null)) && (
                <Btn variant="ok" icon={ShieldCheck} loading={busyId === detail.id} onClick={() => act(detail.id, "validate")}>Validar</Btn>
              )}
              {detail.elementCount > 0 && detail.method !== "MANUAL" && (
                <Btn icon={RefreshCcw} loading={busyId === detail.id} onClick={() => act(detail.id, "remeasure")}>Re-medir</Btn>
              )}
              {detail.status === "VALIDADA" && detail.elementCount > 0 && (
                <Btn variant="warn" icon={CopyPlus} onClick={() => openDerive(detail)}>Derivar acabado</Btn>
              )}
              <Btn icon={PencilLine} onClick={() => { setEditQty(detail); setEditValue(detail.value?.toString() ?? ""); setEditNote(detail.note ?? ""); }}>Corregir valor</Btn>
              <Btn variant={detail.actividad ? "ghost" : "warn"} icon={Link2} onClick={() => setAssignQty(detail)}>
                {detail.actividad ? "Cambiar actividad" : "Asignar actividad"}
              </Btn>
              {detail.status !== "RECHAZADA" && (
                <Btn variant="danger" icon={XCircle} loading={busyId === detail.id} onClick={() => act(detail.id, "reject")}>Rechazar</Btn>
              )}
              <Btn variant="danger" icon={Trash2} onClick={() => { setDeleteQty(detail); setDeleteReason(""); }}>
                Eliminar cantidad
              </Btn>
            </div>
            <p className="flex items-center gap-1.5 text-[10.5px] text-fog"><Database size={11} /> Toda acción queda en el historial de decisiones.</p>
          </div>
        )}
      </Drawer>

      {/* Configurar regla de medición */}
      <Modal open={!!configQty} onClose={() => { setConfigQty(null); setPreview(null); }} wide
        title="Regla de medición — verifique qué se está midiendo">
        {configQty && (
          <div className="space-y-4">
            <Alert tone="info">
              Compare todas las reglas sobre los <strong>mismos {configQty.elementCount} elementos</strong> antes de decidir.
              Lo que verifique aquí se aplica a todo el grupo.
            </Alert>

            {preview === null ? (
              <Spinner label="Calculando todas las variantes…" />
            ) : (
              <>
                {preview.alertas.length > 0 && (
                  <Alert tone="error">
                    {preview.alertas.map((a, i) => (
                      <p key={i} className="flex items-start gap-1.5"><TriangleAlert size={12} className="mt-0.5 shrink-0" />{a}</p>
                    ))}
                  </Alert>
                )}
                <Card className="overflow-hidden">
                  <p className="border-b border-line bg-ink-800/60 px-3 py-1.5 text-[10px] font-bold uppercase tracking-widest text-fog">
                    Resultado de cada regla sobre este grupo
                  </p>
                  <div className="max-h-56 overflow-auto">
                    {preview.variantes.map((v) => {
                      const active =
                        (cfg.areaBasis ?? "NETA") === v.key || (cfg.dimension ?? "LARGO") === v.key ||
                        (cfg.volumeBasis ?? "NETO") === v.key;
                      return (
                        <button key={v.key}
                          onClick={() => setCfg({ ...cfg, ...v.config, factor: cfg.factor ?? 1 })}
                          className={cx("flex w-full items-center justify-between gap-3 border-b border-line/40 px-3 py-2 text-left transition-colors last:border-0",
                            active ? "bg-acc/10" : "hover:bg-ink-800")}>
                          <span className="min-w-0">
                            <span className={cx("block truncate text-[11.5px] font-semibold", active ? "text-acc" : "text-slate-200")}>{v.label}</span>
                            <span className="block text-[10px] text-fog">
                              {v.medidos} medidos{v.sinDato > 0 ? ` · ${v.sinDato} sin dato` : ""}
                              {v.campos.length ? ` · usa: ${v.campos.join(", ")}` : ""}
                            </span>
                          </span>
                          <span className={cx("shrink-0 font-mono text-sm font-bold tabular-nums", active ? "text-acc" : "text-white")}>
                            {fmt(v.value, 2)} {preview.unidad}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </Card>

                <details className="rounded-lg border border-line bg-ink-800/40">
                  <summary className="cursor-pointer px-3 py-2 text-[11px] font-semibold text-mist hover:text-white">
                    Ver dimensiones elemento por elemento ({preview.detalle.length})
                  </summary>
                  <div className="max-h-56 overflow-auto border-t border-line">
                    <table className="w-full text-left text-[10.5px]">
                      <thead className="sticky top-0 bg-ink-800 text-[9.5px] uppercase tracking-wide text-fog">
                        <tr>
                          <th className="px-2 py-1">Elemento</th>
                          <th className="px-2 py-1 text-right">Largo</th>
                          <th className="px-2 py-1 text-right">Ancho</th>
                          <th className="px-2 py-1 text-right">Alto</th>
                          <th className="px-2 py-1 text-right">Espesor</th>
                          <th className="px-2 py-1 text-right">Área neta</th>
                          <th className="px-2 py-1 text-right">Volumen</th>
                        </tr>
                      </thead>
                      <tbody>
                        {preview.detalle.slice(0, 60).map((d) => (
                          <tr key={d.id} className="border-t border-line/40">
                            <td className="max-w-48 truncate px-2 py-1 text-slate-200" title={`${d.clase} · ${d.nivel ?? ""}`}>{d.nombre ?? "(sin nombre)"}</td>
                            <td className="px-2 py-1 text-right font-mono text-mist">{fmt(d.largo, 3)}</td>
                            <td className="px-2 py-1 text-right font-mono text-mist">{fmt(d.ancho, 3)}</td>
                            <td className="px-2 py-1 text-right font-mono text-mist">{fmt(d.alto, 3)}</td>
                            <td className="px-2 py-1 text-right font-mono text-mist">{fmt(d.espesor, 3)}</td>
                            <td className="px-2 py-1 text-right font-mono text-slate-300">{fmt(d.areaNeta, 2)}</td>
                            <td className="px-2 py-1 text-right font-mono text-slate-300">{fmt(d.volumen, 3)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </details>

                {configQty.elementCount > 0 && (
                  <Btn size="sm" icon={BoxIcon} onClick={() => openViewer(configQty)}>Ver estos elementos en el visor</Btn>
                )}
              </>
            )}
            {configQty.method === "SUPERFICIE_GEOMETRICA" && (
              <div>
                <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-mist">Criterio de área</span>
                <Select value={cfg.areaBasis ?? "NETA"} onChange={(e) => setCfg({ ...cfg, areaBasis: e.target.value })}>
                  {AREA_OPTS.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
                </Select>
              </div>
            )}
            {configQty.method === "DIMENSION" && (
              <div>
                <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-mist">Dimensión a medir</span>
                <Select value={cfg.dimension ?? "LARGO"} onChange={(e) => setCfg({ ...cfg, dimension: e.target.value })}>
                  {DIM_OPTS.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
                </Select>
              </div>
            )}
            {configQty.method === "VOLUMEN_GEOMETRICO" && (
              <div>
                <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-mist">Criterio de volumen</span>
                <Select value={cfg.volumeBasis ?? "NETO"} onChange={(e) => setCfg({ ...cfg, volumeBasis: e.target.value })}>
                  <option value="NETO">Volumen neto (descuenta vanos si existen)</option>
                  <option value="BRUTO">Volumen bruto</option>
                </Select>
              </div>
            )}
            <div>
              <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-mist">Factor multiplicador</span>
              <Input value={String(cfg.factor ?? 1)} onChange={(e) => setCfg({ ...cfg, factor: Number(e.target.value.replace(",", ".")) || 1 })} className="font-mono" inputMode="decimal" />
              <p className="mt-1 text-[10.5px] text-fog">Ej. 2 para medir dos caras. No use este campo para desperdicios: eso corresponde a BC Budget.</p>
            </div>
            <div className="flex justify-end gap-2">
              <Btn onClick={() => setConfigQty(null)}>Cancelar</Btn>
              <Btn variant="primary" icon={SlidersHorizontal} loading={busyId === configQty.id}
                onClick={() => act(configQty.id, "configure", { measureConfig: cfg })}>
                Aplicar y recalcular
              </Btn>
            </div>
          </div>
        )}
      </Modal>

      {/* Derivar actividad */}
      <Modal open={!!deriveQty} onClose={() => setDeriveQty(null)} title="Derivar actividad sobre los mismos elementos" wide>
        {deriveQty && (
          <div className="space-y-3">
            <Alert tone="info">
              <span className="flex items-start gap-2">
                <GitBranch size={13} className="mt-0.5 shrink-0" />
                Se creará una actividad hija que mide elementos de «{deriveQty.actividad?.code} {deriveQty.actividad?.name}»
                con la regla de la nueva actividad. Puede aplicarla a <strong>todos o solo a algunos</strong> elementos;
                la cantidad queda vinculada a su actividad padre.
              </span>
            </Alert>

            <div>
              <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-mist">Etiqueta (opcional)</span>
              <Input value={deriveLabel} onChange={(e) => setDeriveLabel(e.target.value)} placeholder="Ej: Pintura cara interior — muros eje A" />
            </div>

            {/* Selección de elementos que reciben el acabado */}
            <div className="rounded-xl border border-line bg-ink-800/40">
              <div className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2">
                <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-mist">
                  ¿A qué elementos se aplica?
                </span>
                {deriveEls && (
                  <>
                    <Chip className={deriveSel.size === deriveEls.length
                      ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-300"
                      : "border-amber-400/30 bg-amber-400/10 text-amber-300"}>
                      {deriveSel.size} de {deriveEls.length} seleccionados
                    </Chip>
                    <div className="ml-auto flex gap-1.5">
                      <Btn size="sm" onClick={() => setDeriveSel(new Set(deriveEls.map((e) => e.id)))}>Todos</Btn>
                      <Btn size="sm" onClick={() => setDeriveSel(new Set())}>Ninguno</Btn>
                    </div>
                  </>
                )}
              </div>
              {deriveEls === null ? (
                <Spinner label="Cargando elementos del padre…" />
              ) : (
                <div className="max-h-44 overflow-auto">
                  {deriveEls.map((el) => {
                    const on = deriveSel.has(el.id);
                    return (
                      <button key={el.id}
                        onClick={() => setDeriveSel((s) => {
                          const n = new Set(s);
                          if (n.has(el.id)) n.delete(el.id); else n.add(el.id);
                          return n;
                        })}
                        className={cx("flex w-full items-center gap-2 border-b border-line/40 px-3 py-1.5 text-left transition-colors last:border-0",
                          on ? "bg-acc/5" : "opacity-55 hover:opacity-100")}>
                        {on ? <CheckSquare size={13} className="shrink-0 text-acc" /> : <Square size={13} className="shrink-0 text-fog" />}
                        <span className="min-w-0 flex-1 truncate text-[11px] text-slate-200">{el.name ?? "(sin nombre)"}</span>
                        <span className="shrink-0 font-mono text-[10px] text-fog">{el.level ?? ""}</span>
                        {el.dimensions?.netArea != null && (
                          <span className="shrink-0 font-mono text-[10px] text-mist">{fmt(el.dimensions.netArea, 2)} m²</span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Actividades derivadas elegidas, cada una con su propia regla */}
            {derivePicks.length > 0 && (
              <div className="rounded-xl border border-acc/40 bg-acc/5">
                <div className="flex items-center gap-2 border-b border-line px-3 py-2">
                  <GitBranch size={12} className="text-acc" />
                  <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-acc">
                    {derivePicks.length} actividad(es) por derivar
                  </span>
                  <button onClick={() => setDerivePicks([])} className="ml-auto text-[10.5px] text-mist hover:text-rose-300">
                    Quitar todas
                  </button>
                </div>
                <div className="divide-y divide-line/50">
                  {derivePicks.map((p, i) => (
                    <div key={p.activity.id} className="px-3 py-2.5">
                      <div className="flex items-start gap-2">
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-xs font-bold text-white">
                            <span className="mr-1.5 font-mono text-[11px] text-acc">{p.activity.code}</span>
                            {p.activity.name}
                          </p>
                          <p className="text-[10.5px] text-fog">
                            {METHOD_META[p.activity.method]?.label ?? p.activity.method} · {p.activity.unit}
                          </p>
                        </div>
                        <button onClick={() => setDerivePicks((c) => c.filter((_, j) => j !== i))}
                          className="shrink-0 rounded-md p-1 text-fog hover:bg-rose-500/15 hover:text-rose-300"
                          title="Quitar de la lista">
                          <XCircle size={13} />
                        </button>
                      </div>
                      <div className="mt-2 flex flex-wrap items-center gap-2">
                        {p.activity.method === "SUPERFICIE_GEOMETRICA" && (
                          <Select
                            value={p.config.areaBasis ?? "UNA_CARA"}
                            onChange={(e) => setDerivePicks((c) => c.map((x, j) =>
                              j === i ? { ...x, config: { ...x.config, areaBasis: e.target.value } } : x))}
                            className="h-8 w-64 py-0 text-[11px]">
                            {AREA_OPTS.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
                          </Select>
                        )}
                        {p.activity.method === "DIMENSION" && (
                          <Select
                            value={p.config.dimension ?? "LARGO"}
                            onChange={(e) => setDerivePicks((c) => c.map((x, j) =>
                              j === i ? { ...x, config: { ...x.config, dimension: e.target.value } } : x))}
                            className="h-8 w-56 py-0 text-[11px]">
                            {DIM_OPTS.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
                          </Select>
                        )}
                        {p.activity.method === "VOLUMEN_GEOMETRICO" && (
                          <Select
                            value={p.config.volumeBasis ?? "NETO"}
                            onChange={(e) => setDerivePicks((c) => c.map((x, j) =>
                              j === i ? { ...x, config: { ...x.config, volumeBasis: e.target.value } } : x))}
                            className="h-8 w-56 py-0 text-[11px]">
                            <option value="NETO">Volumen neto</option>
                            <option value="BRUTO">Volumen bruto</option>
                          </Select>
                        )}
                        <label className="flex items-center gap-1 text-[10.5px] text-mist">
                          Factor
                          <Input value={String(p.config.factor ?? 1)}
                            onChange={(e) => setDerivePicks((c) => c.map((x, j) =>
                              j === i ? { ...x, config: { ...x.config, factor: Number(e.target.value.replace(",", ".")) || 1 } } : x))}
                            className="h-8 w-16 py-0 text-center font-mono text-[11px]" inputMode="decimal" />
                        </label>
                        <Input value={p.label}
                          onChange={(e) => setDerivePicks((c) => c.map((x, j) => j === i ? { ...x, label: e.target.value } : x))}
                          placeholder="Etiqueta propia (opcional)"
                          className="h-8 w-56 py-0 text-[11px]" />
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between gap-2 border-t border-line px-3 py-2.5">
                  <p className="text-[10.5px] text-fog">
                    Se crearán sobre los mismos {deriveSel.size} elemento(s). Si una actividad ya existe para esos
                    elementos, se omite para no duplicar cantidades.
                  </p>
                  <Btn variant="primary" icon={CopyPlus} loading={busy}
                    disabled={deriveSel.size === 0}
                    onClick={deriveAll}>
                    Crear {derivePicks.length} derivada(s)
                  </Btn>
                </div>
              </div>
            )}

            <ActivityPicker allowCreate onPick={addDerivePick}
              createSuggestion={{ unit: "M2", method: "SUPERFICIE_GEOMETRICA" }}
              placeholder="Buscar y añadir acabados (friso, pintura, enchape…) — puede elegir varios" />
            {deriveSel.size === 0 && (
              <Alert tone="warn">Seleccione al menos un elemento antes de crear las actividades derivadas.</Alert>
            )}
          </div>
        )}
      </Modal>

      {/* Eliminar cantidad */}
      <Modal open={!!deleteQty} onClose={() => setDeleteQty(null)} title="Eliminar cantidad del proyecto">
        {deleteQty && (
          <div className="space-y-3">
            <Alert tone="error">
              <span className="flex items-start gap-2">
                <TriangleAlert size={14} className="mt-0.5 shrink-0" />
                <span>
                  Se eliminará <strong>{deleteQty.actividad ? `${deleteQty.actividad.code} — ${deleteQty.actividad.name}` : deleteQty.label ?? "esta cantidad"}</strong>
                  {" "}({fmt(deleteQty.value, digits(deleteQty.unit))} {deleteQty.unit})
                  {deleteQty.derivadas > 0 && <> junto con sus <strong>{deleteQty.derivadas} actividad(es) derivadas</strong></>}.
                  Si la actividad queda sin cantidades, también se retira de la estructura del presupuesto.
                </span>
              </span>
            </Alert>
            <p className="text-[11px] leading-relaxed text-fog">
              La evidencia IFC original no se modifica y la eliminación queda registrada en el historial de decisiones.
            </p>
            <div>
              <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-mist">Motivo (recomendado)</span>
              <Input value={deleteReason} onChange={(e) => setDeleteReason(e.target.value)}
                placeholder="Ej: quedó en cero al cambiar de ítem" />
            </div>
            <div className="flex justify-end gap-2">
              <Btn onClick={() => setDeleteQty(null)}>Cancelar</Btn>
              <Btn variant="danger" icon={Trash2} loading={busyId === deleteQty.id}
                onClick={() => removeQuantity(deleteQty, deleteReason)}>
                Eliminar definitivamente
              </Btn>
            </div>
          </div>
        )}
      </Modal>

      {/* Medición manual */}
      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Medición manual / añadir actividad" wide>
        {!addActivity ? (
          <div>
            <p className="mb-3 text-xs text-mist">Elija la actividad. Si la deja sin valor quedará como línea PENDIENTE en la estructura.</p>
            <ActivityPicker allowCreate onPick={setAddActivity} />
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between rounded-lg border border-acc/30 bg-acc/5 px-3.5 py-2.5">
              <div>
                <p className="text-sm font-bold text-white"><span className="mr-1.5 font-mono text-xs text-acc">{addActivity.code}</span>{addActivity.name}</p>
                <p className="text-[11px] text-mist">{addActivity.chapterName} · {addActivity.sectionName}</p>
              </div>
              <Btn size="sm" onClick={() => setAddActivity(null)}>Cambiar</Btn>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-mist">Cantidad ({addActivity.unit})</span>
                <Input value={addValue} onChange={(e) => setAddValue(e.target.value)} placeholder="Vacío = planificar" className="font-mono" inputMode="decimal" />
              </div>
              <div>
                <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-mist">Justificación</span>
                <Input value={addNote} onChange={(e) => setAddNote(e.target.value)} placeholder="Medido en obra…" />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Btn onClick={() => setShowAdd(false)}>Cancelar</Btn>
              <Btn variant="primary" icon={Hand} loading={busy} onClick={addManual}>
                {addValue.trim() ? "Registrar como VALIDADA" : "Añadir como PENDIENTE"}
              </Btn>
            </div>
          </div>
        )}
      </Modal>

      {/* Corregir valor */}
      <Modal open={!!editQty} onClose={() => setEditQty(null)} title="Corregir cantidad (decisión profesional)">
        {editQty && (
          <div className="space-y-4">
            <p className="text-xs text-mist">
              Valor actual: <span className="font-mono font-bold text-white">{fmt(editQty.value, digits(editQty.unit))} {editQty.unit}</span>.
              La corrección queda registrada en el informe de trazabilidad.
            </p>
            <div>
              <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-mist">Nuevo valor ({editQty.unit})</span>
              <Input value={editValue} onChange={(e) => setEditValue(e.target.value)} className="font-mono" inputMode="decimal" autoFocus />
            </div>
            <div>
              <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-mist">Justificación</span>
              <Textarea value={editNote} onChange={(e) => setEditNote(e.target.value)} placeholder="Motivo de la corrección…" />
            </div>
            <div className="flex justify-end gap-2">
              <Btn onClick={() => setEditQty(null)}>Cancelar</Btn>
              <Btn variant="primary" icon={PencilLine} loading={busyId === editQty.id}
                onClick={() => {
                  const v = Number(editValue.replace(",", "."));
                  if (!isFinite(v)) return setError("Valor inválido.");
                  act(editQty.id, "edit", { value: v, note: editNote || undefined });
                }}>
                Confirmar corrección
              </Btn>
            </div>
          </div>
        )}
      </Modal>

      {/* Asignar / cambiar actividad */}
      <Modal open={!!assignQty} onClose={() => setAssignQty(null)} wide
        title={assignQty?.actividad ? "Cambiar la actividad de esta cantidad" : "Asignar actividad del catálogo"}>
        {assignQty && (
          <div className="space-y-3">
            {assignQty.actividad && (
              <Alert tone="warn">
                Actividad actual: <strong>{assignQty.actividad.code} — {assignQty.actividad.name}</strong> ({assignQty.unit}).
                Al elegir otra, la cantidad se vuelve a medir con el método de la nueva actividad y el cambio queda
                registrado como decisión profesional.
              </Alert>
            )}
            <ActivityPicker allowCreate onPick={(a) => act(assignQty.id, "assign", { activityId: a.id })} />
          </div>
        )}
      </Modal>

      {/* Visor */}
      <Modal open={!!viewerQty} onClose={() => { setViewerQty(null); setViewerEls(null); }} wide title={
        <span className="flex items-center gap-2"><BoxIcon size={14} className="text-acc" /> Elementos medidos en esta cantidad</span>
      }>
        {viewerEls === null ? <Spinner label="Cargando geometría…" /> : (
          <Viewer3D
            elements={viewerEls}
            height={560}
            title={viewerQty?.actividad ? `${viewerQty.actividad.code} — ${viewerQty.actividad.name}` : "Revisión de elementos"}
            measurement={viewerQty && viewerQty.method !== "MANUAL" ? {
              method: viewerQty.method,
              config: viewerQty.measureConfig ?? {},
              value: viewerQty.value,
              unit: viewerQty.unit,
              onApply: async (config) => {
                await act(viewerQty.id, "configure", { measureConfig: config });
                setNotice("Regla cambiada desde el visor y aplicada a todos los elementos del grupo.");
              },
            } : undefined}
          />
        )}
      </Modal>
    </div>
  );
}

function TraceQ({ n, q, a, children }: { n: string; q: string; a: string; children: React.ReactNode }) {
  return (
    <div className="overflow-hidden rounded-xl border border-line bg-ink-800/50">
      <div className="flex items-center gap-2 border-b border-line/60 bg-ink-800 px-3.5 py-2">
        <span className="flex h-5 w-5 items-center justify-center rounded-md bg-acc/15 font-mono text-[10px] font-bold text-acc">{n}</span>
        <span className="font-mono text-xs font-bold tracking-wide text-white">{q}</span>
        <span className="text-[10.5px] text-fog">{a}</span>
      </div>
      <div className="px-3.5 py-2.5">{children}</div>
    </div>
  );
}
