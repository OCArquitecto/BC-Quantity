import {
  pgTable,
  uuid,
  text,
  integer,
  doublePrecision,
  boolean,
  jsonb,
  timestamp,
  index,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Tipos compartidos                                                   */
/* ------------------------------------------------------------------ */
export type MeasurementMethod =
  | "SUPERFICIE_GEOMETRICA"
  | "VOLUMEN_GEOMETRICO"
  | "DIMENSION"
  | "COUNT"
  | "CANTIDAD_IFC"
  | "COMPONENTES"
  | "MANUAL";

/** Cómo se interpreta la geometría al medir (elegible por el profesional). */
export interface MeasureConfig {
  /** Para métodos de área. */
  areaBasis?: "NETA" | "BRUTA" | "UNA_CARA" | "DOS_CARAS" | "LATERAL" | "PLANTA" | "SUPERFICIE_TOTAL";
  /** Para el método DIMENSION. */
  dimension?: "LARGO" | "ALTO" | "ANCHO" | "ESPESOR" | "PERIMETRO";
  /** Para métodos de volumen. */
  volumeBasis?: "NETO" | "BRUTO";
  /** Multiplicador profesional (p. ej. 2 caras, mermas no aplican aquí). */
  factor?: number;
  /** Nota de la configuración. */
  note?: string;
}

export interface ElementDimensions {
  length?: number | null;
  width?: number | null;
  height?: number | null;
  thickness?: number | null;
  area?: number | null;
  grossArea?: number | null;
  netArea?: number | null;
  surfaceArea?: number | null;
  crossSectionArea?: number | null;
  perimeter?: number | null;
  volume?: number | null;
  netVolume?: number | null;
  count?: number | null;
}

export interface ElementGeometry {
  kind: string;
  size: [number, number, number];
  center: [number, number, number];
  yaw: number;
  /** Cara principal real del elemento, con vanos, ya recortada. */
  face?: {
    outline: [number, number][];
    holes: [number, number][][];
    thickness: number;
    origin: [number, number, number];
    uAxis: [number, number, number];
    vAxis: [number, number, number];
    nAxis: [number, number, number];
    clipped: boolean;
    /** Área real tras restar sólidos de corte. */
    exactArea?: number;
  };
  /** Vanos que perforan el elemento (puertas, ventanas, pasos). */
  openings?: { width: number; height: number; area: number; name: string | null }[];
  /** Caja orientada a los ejes propios: [longitud, canto, ancho]. */
  oriented?: {
    size: [number, number, number];
    center: [number, number, number];
    axes: [[number, number, number], [number, number, number], [number, number, number]];
  };
}

/* ------------------------------------------------------------------ */
/* Proyectos                                                           */
/* ------------------------------------------------------------------ */
export interface CompanyInfo {
  name?: string;
  nit?: string;
  address?: string;
  phone?: string;
  email?: string;
  responsible?: string;
  role?: string;
  license?: string;
  logo?: string; // data URL
}

export interface DocumentTemplate {
  budgetTitle?: string;
  budgetSubtitle?: string;
  budgetIntroduction?: string;
  budgetScope?: string;
  reportTitle?: string;
  reportSubtitle?: string;
  reportIntroduction?: string;
  reportScope?: string;
  sourcesTitle?: string;
  decisionsTitle?: string;
  observationsTitle?: string;
  footerText?: string;
  preparedByLabel?: string;
  reviewedByLabel?: string;
  showCompany?: boolean;
  showPrices?: boolean;
  showAIU?: boolean;
}

export interface ProjectSettings {
  administracion?: number;
  imprevistos?: number;
  utilidad?: number;
  iva?: number;
  /** Compatibilidad con proyectos anteriores. */
  ivaSobreUtilidad?: boolean;
  /** Bases sobre las que se calcula el IVA (Colombia: normalmente solo utilidad). */
  ivaBases?: ("DIRECTO" | "ADMINISTRACION" | "IMPREVISTOS" | "UTILIDAD")[];
  currency?: string;
  notes?: string;
  documents?: DocumentTemplate;
}

export const projects = pgTable("bc_projects", {
  id: uuid("id").defaultRandom().primaryKey(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  client: text("client"),
  location: text("location"),
  description: text("description"),
  units: text("units").notNull().default("SI"),
  status: text("status").notNull().default("ACTIVO"),
  company: jsonb("company").$type<CompanyInfo>(),
  settings: jsonb("settings").$type<ProjectSettings>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Fuentes de información                                              */
/* ------------------------------------------------------------------ */
export type SourceKind = "IFC" | "EXCEL" | "MANUAL" | "TEMPLATE";

export const sources = pgTable(
  "bc_sources",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    kind: text("kind").notNull().$type<SourceKind>(),
    name: text("name").notNull(),
    discipline: text("discipline"),
    fileName: text("file_name"),
    fileSize: integer("file_size"),
    ifcSchema: text("ifc_schema"),
    /** Huella SHA-256 del contenido: identifica archivos idénticos. */
    contentHash: text("content_hash"),
    /** Huella de los GlobalId del modelo: detecta el mismo modelo reexportado. */
    modelHash: text("model_hash"),
    status: text("status").notNull().default("ACTIVA"),
    stats: jsonb("stats").$type<Record<string, unknown>>(),
    meta: jsonb("meta").$type<Record<string, unknown>>(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("sources_project_idx").on(t.projectId)]
);

/* ------------------------------------------------------------------ */
/* Elementos IFC = evidencia                                           */
/* ------------------------------------------------------------------ */
export const elements = pgTable(
  "bc_elements",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    sourceId: uuid("source_id")
      .notNull()
      .references(() => sources.id, { onDelete: "cascade" }),
    globalId: text("global_id"),
    ifcClass: text("ifc_class").notNull(),
    name: text("name"),
    objectType: text("object_type"),
    description: text("description"),
    typeName: text("type_name"),
    semanticType: text("semantic_type"),
    material: text("material"),
    level: text("level"),
    layer: text("layer"),
    tag: text("tag"),
    properties: jsonb("properties").$type<
      Record<string, Record<string, string | number | boolean | null>>
    >(),
    quantities: jsonb("quantities").$type<Record<string, number>>(),
    dimensions: jsonb("dimensions").$type<ElementDimensions>(),
    dimensionSources: jsonb("dimension_sources").$type<Record<string, string>>(),
    geometry: jsonb("geometry").$type<ElementGeometry | null>(),
    excluded: boolean("excluded").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("elements_project_idx").on(t.projectId),
    index("elements_source_idx").on(t.sourceId),
    index("elements_global_idx").on(t.projectId, t.globalId),
  ]
);

/* ------------------------------------------------------------------ */
/* Corridas de agrupación                                              */
/* ------------------------------------------------------------------ */
export const groupingRuns = pgTable(
  "bc_grouping_runs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    sourceIds: jsonb("source_ids").$type<string[]>().notNull(),
    criteria: jsonb("criteria").$type<string[]>().notNull(),
    excludedClasses: jsonb("excluded_classes").$type<string[]>().notNull().default([]),
    elementCount: integer("element_count").notNull().default(0),
    groupCount: integer("group_count").notNull().default(0),
    durationMs: integer("duration_ms").notNull().default(0),
    createdBy: text("created_by"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("runs_project_idx").on(t.projectId)]
);

export const groups = pgTable(
  "bc_groups",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    runId: uuid("run_id")
      .notNull()
      .references(() => groupingRuns.id, { onDelete: "cascade" }),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    groupKey: text("group_key").notNull(),
    criteriaValues: jsonb("criteria_values").$type<Record<string, string>>().notNull(),
    elementIds: jsonb("element_ids").$type<string[]>().notNull(),
    elementCount: integer("element_count").notNull().default(0),
    ifcClasses: jsonb("ifc_classes").$type<string[]>().notNull(),
    semanticTypes: jsonb("semantic_types").$type<string[]>().notNull().default([]),
    sourceIds: jsonb("source_ids").$type<string[]>().notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("groups_run_idx").on(t.runId), index("groups_project_idx").on(t.projectId)]
);

/* ------------------------------------------------------------------ */
/* Catálogo maestro                                                    */
/* ------------------------------------------------------------------ */
/** Capítulos y secciones: permiten apagar ramas completas del catálogo. */
export const catalogGroups = pgTable(
  "bc_catalog_groups",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    kind: text("kind").notNull().$type<"CAPITULO" | "SECCION">(),
    code: text("code").notNull(),
    name: text("name").notNull(),
    parentCode: text("parent_code"),
    active: boolean("active").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("catalog_groups_code_idx").on(t.kind, t.code)]
);

export const catalogActivities = pgTable("bc_catalog_activities", {
  id: uuid("id").defaultRandom().primaryKey(),
  code: text("code").notNull().unique(),
  chapterCode: text("chapter_code").notNull(),
  chapterName: text("chapter_name").notNull(),
  sectionCode: text("section_code").notNull(),
  sectionName: text("section_name").notNull(),
  name: text("name").notNull(),
  unit: text("unit").notNull(),
  method: text("method").notNull().$type<MeasurementMethod>(),
  measureConfig: jsonb("measure_config").$type<MeasureConfig>(),
  keywords: jsonb("keywords").$type<string[]>().notNull().default([]),
  ifcClasses: jsonb("ifc_classes").$type<string[]>().notNull().default([]),
  /** Precio unitario de referencia (viene del listado de precios / BC Budget). */
  unitPrice: doublePrecision("unit_price").notNull().default(0),
  priceSource: text("price_source"),
  description: text("description"),
  origin: text("origin").notNull().default("SEED"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Correspondencias                                                    */
/* ------------------------------------------------------------------ */
export type MatchStatus = "PENDIENTE" | "PROPUESTA" | "VALIDADA" | "RECHAZADA";

export interface MatchCandidate {
  activityId: string;
  code: string;
  name: string;
  unit: string;
  method: string;
  score: number;
  matched: string[];
  classOk: boolean;
}

export const matches = pgTable(
  "bc_matches",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    runId: uuid("run_id")
      .notNull()
      .references(() => groupingRuns.id, { onDelete: "cascade" }),
    groupId: uuid("group_id")
      .notNull()
      .references(() => groups.id, { onDelete: "cascade" }),
    activityId: uuid("activity_id").references(() => catalogActivities.id),
    score: doublePrecision("score").notNull().default(0),
    status: text("status").notNull().$type<MatchStatus>().default("PENDIENTE"),
    candidates: jsonb("candidates").$type<MatchCandidate[]>().notNull().default([]),
    evidence: jsonb("evidence").$type<Record<string, unknown>>(),
    decidedBy: text("decided_by"),
    decidedAt: timestamp("decided_at"),
    decisionNote: text("decision_note"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("matches_project_idx").on(t.projectId)]
);

/* ------------------------------------------------------------------ */
/* Cantidades                                                          */
/* ------------------------------------------------------------------ */
export type QuantityStatus = "PENDIENTE" | "PROPUESTA" | "VALIDADA" | "RECHAZADA";

export const quantities = pgTable(
  "bc_quantities",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    matchId: uuid("match_id"),
    groupId: uuid("group_id"),
    activityId: uuid("activity_id").references(() => catalogActivities.id),
    sourceId: uuid("source_id").references(() => sources.id),
    sourceKind: text("source_kind").notNull().default("MANUAL"),
    /** Cantidad derivada de otra (p. ej. pintura sobre muros ya medidos). */
    derivedFromId: uuid("derived_from_id"),
    label: text("label"),
    value: doublePrecision("value"),
    unit: text("unit").notNull(),
    method: text("method").notNull(),
    measureConfig: jsonb("measure_config").$type<MeasureConfig>(),
    rule: text("rule"),
    evidence: jsonb("evidence").$type<Record<string, unknown>>(),
    elementIds: jsonb("element_ids").$type<string[]>().notNull().default([]),
    /** GlobalIds IFC: permiten detectar duplicados entre fuentes y corridas. */
    elementGlobalIds: jsonb("element_global_ids").$type<string[]>().notNull().default([]),
    elementCount: integer("element_count").notNull().default(0),
    status: text("status").notNull().$type<QuantityStatus>().default("PROPUESTA"),
    note: text("note"),
    validatedBy: text("validated_by"),
    validatedAt: timestamp("validated_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("quantities_project_idx").on(t.projectId)]
);

/* ------------------------------------------------------------------ */
/* Estructura del proyecto                                             */
/* ------------------------------------------------------------------ */
export const structureNodes = pgTable(
  "bc_structure_nodes",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    parentId: uuid("parent_id"),
    kind: text("kind").notNull().$type<"CAPITULO" | "SECCION" | "ACTIVIDAD">(),
    code: text("code").notNull(),
    name: text("name").notNull(),
    activityId: uuid("activity_id"),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("structure_project_idx").on(t.projectId)]
);

/* ------------------------------------------------------------------ */
/* Decisiones profesionales                                            */
/* ------------------------------------------------------------------ */
export const decisions = pgTable(
  "bc_decisions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    entityType: text("entity_type").notNull(),
    entityId: text("entity_id"),
    action: text("action").notNull(),
    detail: jsonb("detail").$type<Record<string, unknown>>(),
    actor: text("actor"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("decisions_project_idx").on(t.projectId)]
);
