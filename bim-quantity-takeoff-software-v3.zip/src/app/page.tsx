"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Plus, FolderKanban, ArrowRight, ScanSearch, Boxes, Layers3,
  GitCompareArrows, Ruler, ShieldCheck, FileBox, FileSpreadsheet, Hand,
  Trash2, TriangleAlert,
} from "lucide-react";
import { Nav } from "@/components/Nav";
import { Btn, Card, Chip, Modal, Input, Field, Textarea, Spinner, Empty, Alert } from "@/components/ui";
import { api } from "@/lib/client";

interface ProjectRow {
  id: string;
  code: string;
  name: string;
  client: string | null;
  location: string | null;
  createdAt: string;
  stats: { fuentes: number; elementos: number; cantidades: number; validadas: number; pendientesDecision: number };
}

const PIPELINE = [
  { icon: ScanSearch, label: "EVIDENCIA", desc: "Lo que el IFC realmente contiene" },
  { icon: Layers3, label: "AGRUPACIÓN", desc: "Criterios elegidos por usted" },
  { icon: GitCompareArrows, label: "PROPUESTA", desc: "Correspondencias con el catálogo" },
  { icon: ShieldCheck, label: "DECISIÓN", desc: "Validación profesional" },
  { icon: Ruler, label: "MEDICIÓN", desc: "Método de la actividad" },
  { icon: FileBox, label: "CANTIDAD", desc: "Trazable y exportable" },
];

export default function Dashboard() {
  const router = useRouter();
  const [projects, setProjects] = useState<ProjectRow[] | null>(null);
  const [showNew, setShowNew] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ code: "", name: "", client: "", location: "", description: "", template: false });
  const [toDelete, setToDelete] = useState<ProjectRow | null>(null);
  const [confirmCode, setConfirmCode] = useState("");
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const removeProject = async () => {
    if (!toDelete) return;
    setBusy(true);
    setDeleteError(null);
    try {
      await api(`/api/projects/${toDelete.id}?confirm=${encodeURIComponent(confirmCode.trim().toUpperCase())}`, { method: "DELETE" });
      setNotice(`Proyecto ${toDelete.code} eliminado junto con sus fuentes, cantidades y decisiones.`);
      setToDelete(null);
      setConfirmCode("");
      await load();
    } catch (e) {
      setDeleteError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const load = () => api<{ projects: ProjectRow[] }>("/api/projects").then((d) => setProjects(d.projects));
  useEffect(() => {
    load().catch(() => setProjects([]));
  }, []);

  const create = async () => {
    if (!form.code.trim() || !form.name.trim()) {
      setError("Código y nombre son obligatorios.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const d = await api<{ project: { id: string } }>("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      router.push(`/proyectos/${d.project.id}`);
    } catch (e) {
      setError((e as Error).message);
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen">
      <Nav />
      {/* HERO */}
      <section className="bc-grid-bg border-b border-line">
        <div className="mx-auto max-w-[1500px] px-4 py-12 sm:px-6 sm:py-16">
          <div className="max-w-3xl bc-fade-up">
            <Chip className="mb-4 border-acc/40 bg-acc/10 text-acc">
              <Boxes size={12} /> Cómputo de cantidades desde BIM — sin inventar información
            </Chip>
            <h1 className="text-4xl font-extrabold leading-[1.05] tracking-tight text-white sm:text-5xl">
              ¿Qué se construye, cuánto hay y{" "}
              <span className="text-acc">¿de dónde salió cada cantidad?</span>
            </h1>
            <p className="mt-4 max-w-2xl text-sm leading-relaxed text-mist sm:text-base">
              BIMCost Quantity convierte IFC, Excel y mediciones manuales en actividades con cantidades
              organizadas, evidencia y trazabilidad total. No calcula costos (eso es BC Budget), no es APU
              y no reemplaza a Revit o Archicad: <span className="text-slate-200">termina donde termina la cantidad.</span>
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Btn variant="primary" icon={Plus} onClick={() => setShowNew(true)}>Nuevo proyecto</Btn>
              <Link href="/catalogo"><Btn icon={Boxes}>Ver catálogo maestro</Btn></Link>
            </div>
          </div>

          {/* pipeline */}
          <div className="mt-10 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
            {PIPELINE.map((p, i) => (
              <div key={p.label} className="relative rounded-xl border border-line bg-ink-850/70 px-3 py-3 backdrop-blur bc-fade-up" style={{ animationDelay: `${i * 60}ms` }}>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[10px] font-bold text-acc">{String(i + 1).padStart(2, "0")}</span>
                  <p.icon size={14} className="text-acc" />
                  <span className="text-[11px] font-bold tracking-wide text-slate-200">{p.label}</span>
                </div>
                <p className="mt-1.5 text-[10.5px] leading-snug text-fog">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PROYECTOS */}
      <section className="mx-auto max-w-[1500px] px-4 py-10 sm:px-6">
        <div className="mb-5 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white">Proyectos</h2>
            <p className="text-xs text-mist">Cada proyecto consolida múltiples fuentes sin que una destruya la información de otra.</p>
          </div>
          <Btn variant="ghost" size="sm" icon={Plus} onClick={() => setShowNew(true)}>Crear proyecto</Btn>
        </div>

        {notice && <div className="mb-4"><Alert tone="ok">{notice}</Alert></div>}

        {projects === null ? (
          <Spinner label="Cargando proyectos…" />
        ) : projects.length === 0 ? (
          <Empty
            icon={FolderKanban}
            title="Aún no hay proyectos"
            hint="Cree su primer proyecto y cargue IFC de distintas disciplinas, Excel o mediciones manuales. Puede usar el proyecto de demostración CASA X desde la pestaña Fuentes."
            action={<Btn variant="primary" icon={Plus} onClick={() => setShowNew(true)}>Crear el primer proyecto</Btn>}
          />
        ) : (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {projects.map((p) => (
              <Link key={p.id} href={`/proyectos/${p.id}`} className="group">
                <Card className="relative h-full p-5 transition-all duration-200 hover:border-acc/50 hover:bc-glow">
                  <button
                    title="Eliminar proyecto"
                    onClick={(e) => { e.preventDefault(); e.stopPropagation(); setToDelete(p); setConfirmCode(""); setDeleteError(null); }}
                    className="absolute right-3 top-3 z-10 rounded-md p-1.5 text-fog opacity-0 transition-all hover:bg-rose-500/15 hover:text-rose-300 group-hover:opacity-100"
                  >
                    <Trash2 size={14} />
                  </button>
                  <div className="flex items-start justify-between gap-3 pr-8">
                    <div>
                      <span className="font-mono text-[11px] font-bold tracking-wider text-acc">{p.code}</span>
                      <h3 className="mt-1 text-base font-bold tracking-tight text-white group-hover:text-acc transition-colors">{p.name}</h3>
                      <p className="mt-0.5 text-xs text-mist">{p.client ?? "Sin cliente"} {p.location ? `· ${p.location}` : ""}</p>
                    </div>
                    {p.stats.pendientesDecision > 0 ? (
                      <Chip className="border-amber-400/40 bg-amber-400/10 text-amber-300">
                        <span className="h-1.5 w-1.5 rounded-full bg-amber-400 bc-pulse-dot" />
                        {p.stats.pendientesDecision} por decidir
                      </Chip>
                    ) : null}
                  </div>
                  <div className="mt-4 grid grid-cols-4 gap-2 border-t border-line pt-4">
                    {[
                      { n: p.stats.fuentes, l: "Fuentes" },
                      { n: p.stats.elementos, l: "Elementos IFC" },
                      { n: p.stats.cantidades, l: "Cantidades" },
                      { n: p.stats.validadas, l: "Validadas" },
                    ].map((s) => (
                      <div key={s.l}>
                        <p className="font-mono text-lg font-bold tabular-nums text-white">{s.n}</p>
                        <p className="text-[10px] uppercase tracking-wider text-fog">{s.l}</p>
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 flex items-center justify-end gap-1 text-[11px] font-semibold text-acc opacity-0 transition-opacity group-hover:opacity-100">
                    Abrir espacio de trabajo <ArrowRight size={13} />
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* Fuentes soportadas */}
      <section className="mx-auto max-w-[1500px] px-4 pb-16 sm:px-6">
        <div className="grid gap-3 sm:grid-cols-3">
          {[
            { icon: FileBox, t: "IFC multi-disciplina", d: "Arquitectura, estructura e instalaciones en un mismo proyecto. Cada archivo conserva su identidad." },
            { icon: FileSpreadsheet, t: "Excel / CSV", d: "Código, actividad, unidad y cantidad. Todas las filas llegan pendientes de validación profesional." },
            { icon: Hand, t: "Medición manual", d: "Cuando el modelo no basta, usted mide. El ingreso manual queda registrado como decisión." },
          ].map((f) => (
            <Card key={f.t} className="flex gap-3 p-4">
              <f.icon size={18} className="mt-0.5 shrink-0 text-acc" />
              <div>
                <p className="text-sm font-semibold text-slate-100">{f.t}</p>
                <p className="mt-0.5 text-xs leading-relaxed text-mist">{f.d}</p>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* Eliminar proyecto */}
      <Modal open={!!toDelete} onClose={() => setToDelete(null)} title="Eliminar proyecto">
        {toDelete && (
          <div className="space-y-3">
            <Alert tone="error">
              <span className="flex items-start gap-2">
                <TriangleAlert size={14} className="mt-0.5 shrink-0" />
                <span>
                  Se eliminarán <strong>definitivamente</strong> el proyecto «{toDelete.name}» y toda su información:
                  {" "}{toDelete.stats.fuentes} fuente(s), {toDelete.stats.elementos} elemento(s) IFC,
                  {" "}{toDelete.stats.cantidades} cantidad(es) y su historial de decisiones.
                  El catálogo maestro no se ve afectado.
                </span>
              </span>
            </Alert>
            {deleteError && <Alert tone="error">{deleteError}</Alert>}
            <Field label="Escriba el código del proyecto para confirmar" hint={`Código: ${toDelete.code}`}>
              <Input value={confirmCode} onChange={(e) => setConfirmCode(e.target.value)} placeholder={toDelete.code} className="font-mono" autoFocus />
            </Field>
            <div className="flex justify-end gap-2">
              <Btn onClick={() => setToDelete(null)}>Cancelar</Btn>
              <Btn variant="danger" icon={Trash2} loading={busy}
                disabled={confirmCode.trim().toUpperCase() !== toDelete.code.toUpperCase()}
                onClick={removeProject}>
                Eliminar definitivamente
              </Btn>
            </div>
          </div>
        )}
      </Modal>

      {/* Nuevo proyecto */}
      <Modal open={showNew} onClose={() => setShowNew(false)} title="Crear proyecto">
        <div className="space-y-4">
          {error ? <Alert tone="error">{error}</Alert> : null}
          <div className="grid grid-cols-2 gap-3">
            <Field label="Código *" hint="Ej. CASA-X-2026">
              <Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="CASA-X-2026" />
            </Field>
            <Field label="Ubicación">
              <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Ciudad" />
            </Field>
          </div>
          <Field label="Nombre del proyecto *">
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Casa X" />
          </Field>
          <Field label="Cliente">
            <Input value={form.client} onChange={(e) => setForm({ ...form, client: e.target.value })} placeholder="Nombre del cliente" />
          </Field>
          <Field label="Descripción">
            <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Alcance, observaciones…" />
          </Field>
          <label className="flex cursor-pointer items-start gap-2.5 rounded-lg border border-line bg-ink-800 px-3 py-2.5">
            <input type="checkbox" checked={form.template} onChange={(e) => setForm({ ...form, template: e.target.checked })} className="mt-0.5 accent-cyan-400" />
            <span>
              <span className="block text-xs font-semibold text-slate-200">Plantilla de estructura base</span>
              <span className="text-[11px] text-fog">Precarga los capítulos y secciones del catálogo maestro en la estructura del proyecto.</span>
            </span>
          </label>
          <div className="flex justify-end gap-2 pt-1">
            <Btn onClick={() => setShowNew(false)}>Cancelar</Btn>
            <Btn variant="primary" loading={busy} onClick={create}>Crear proyecto</Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
}
