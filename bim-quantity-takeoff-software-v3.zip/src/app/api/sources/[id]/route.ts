import { NextResponse } from "next/server";
import { and, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { sources, elements, quantities, groups, matches } from "@/db/schema";
import { addDecision } from "@/lib/server";

/** Resumen de lo que se perdería al eliminar la fuente. */
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const [source] = await db.select().from(sources).where(eq(sources.id, id)).limit(1);
  if (!source) return NextResponse.json({ error: "Fuente no encontrada" }, { status: 404 });

  const els = await db.select({ id: elements.id }).from(elements).where(eq(elements.sourceId, id));
  const elementIds = new Set(els.map((e) => e.id));

  const qs = await db.select().from(quantities).where(eq(quantities.projectId, source.projectId));
  const afectadas = qs.filter(
    (q) => q.sourceId === id || (q.elementIds ?? []).some((eid) => elementIds.has(eid))
  );

  return NextResponse.json({
    fuente: {
      id: source.id, nombre: source.name, kind: source.kind,
      archivo: source.fileName, importadaEl: source.createdAt,
    },
    impacto: {
      elementos: els.length,
      cantidades: afectadas.length,
      cantidadesValidadas: afectadas.filter((q) => q.status === "VALIDADA").length,
      cantidadesDerivadas: afectadas.filter((q) => q.derivedFromId).length,
    },
  });
}

/**
 * Elimina una fuente y toda la información que se derivó de ella:
 * elementos, cantidades medidas sobre esos elementos y correspondencias.
 * Las decisiones ya registradas permanecen en el historial de trazabilidad.
 */
export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const url = new URL(req.url);
  const actor = url.searchParams.get("actor");

  const [source] = await db.select().from(sources).where(eq(sources.id, id)).limit(1);
  if (!source) return NextResponse.json({ error: "Fuente no encontrada" }, { status: 404 });
  const projectId = source.projectId;

  const els = await db.select({ id: elements.id }).from(elements).where(eq(elements.sourceId, id));
  const elementIds = new Set(els.map((e) => e.id));

  /* --- cantidades que dependen de esta fuente --- */
  const qs = await db.select().from(quantities).where(eq(quantities.projectId, projectId));
  const toRemove = qs.filter(
    (q) => q.sourceId === id || (q.elementIds ?? []).some((eid) => elementIds.has(eid))
  );
  // Incluir las derivadas de las cantidades eliminadas
  const removeIds = new Set(toRemove.map((q) => q.id));
  let changed = true;
  while (changed) {
    changed = false;
    for (const q of qs) {
      if (!removeIds.has(q.id) && q.derivedFromId && removeIds.has(q.derivedFromId)) {
        removeIds.add(q.id);
        changed = true;
      }
    }
  }
  if (removeIds.size) {
    await db.delete(quantities).where(inArray(quantities.id, [...removeIds]));
  }

  /* --- grupos y correspondencias que incluyen esta fuente --- */
  const grps = await db.select().from(groups).where(eq(groups.projectId, projectId));
  const groupsToRemove = grps.filter((g) => (g.sourceIds ?? []).includes(id)).map((g) => g.id);
  if (groupsToRemove.length) {
    await db.delete(matches).where(inArray(matches.groupId, groupsToRemove));
    await db.delete(groups).where(inArray(groups.id, groupsToRemove));
  }

  /* --- la fuente (sus elementos caen en cascada) --- */
  await db.delete(sources).where(eq(sources.id, id));

  await addDecision(projectId, "FUENTE", id, "ELIMINO_FUENTE", {
    nombre: source.name, archivo: source.fileName, tipo: source.kind,
    elementosEliminados: els.length,
    cantidadesEliminadas: removeIds.size,
    gruposEliminados: groupsToRemove.length,
    nota: "La evidencia de esta fuente se retiró del proyecto. El historial de decisiones se conserva.",
  }, actor);

  const [{ n: restantes } = { n: 0 }] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(sources)
    .where(and(eq(sources.projectId, projectId), eq(sources.kind, "IFC")));

  return NextResponse.json({
    ok: true,
    eliminado: { fuente: source.name, elementos: els.length, cantidades: removeIds.size, grupos: groupsToRemove.length },
    fuentesIfcRestantes: restantes,
  });
}
