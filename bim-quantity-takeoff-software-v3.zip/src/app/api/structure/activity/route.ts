import { NextResponse } from "next/server";
import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { structureNodes, quantities, catalogActivities } from "@/db/schema";
import { addDecision, pruneEmptyStructure } from "@/lib/server";

/**
 * Elimina una actividad de la ESTRUCTURA del proyecto.
 *
 * Modos:
 *  · soloVacias = true  → solo la retira si no tiene cantidades con valor,
 *    útil para depurar líneas en cero que quedaron tras cambiar de ítem.
 *  · soloVacias = false → retira la actividad y todas sus cantidades
 *    (incluidas las derivadas), previa confirmación del profesional.
 *
 * Nunca toca el catálogo maestro ni la evidencia IFC.
 */
export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const projectId = url.searchParams.get("projectId");
  const activityId = url.searchParams.get("activityId");
  const actor = url.searchParams.get("actor");
  const soloVacias = url.searchParams.get("soloVacias") === "1";

  if (!projectId || !activityId) {
    return NextResponse.json({ error: "projectId y activityId son obligatorios." }, { status: 400 });
  }

  const [act] = await db.select().from(catalogActivities).where(eq(catalogActivities.id, activityId)).limit(1);
  const qtys = await db
    .select()
    .from(quantities)
    .where(and(eq(quantities.projectId, projectId), eq(quantities.activityId, activityId)));

  const conValor = qtys.filter((q) => (q.value ?? 0) > 0 && q.status !== "RECHAZADA");
  if (soloVacias && conValor.length > 0) {
    return NextResponse.json({
      error: "TIENE_CANTIDADES",
      detalle: {
        mensaje: `La actividad ${act?.code ?? ""} tiene ${conValor.length} cantidad(es) con valor.`,
        sugerencia: "Confirme la eliminación completa si desea retirarla junto con sus cantidades.",
        cantidades: conValor.length,
        validadas: conValor.filter((q) => q.status === "VALIDADA").length,
      },
    }, { status: 409 });
  }

  /* --- cantidades y sus derivadas --- */
  const all = await db.select().from(quantities).where(eq(quantities.projectId, projectId));
  const removeIds = new Set(qtys.map((q) => q.id));
  let changed = true;
  while (changed) {
    changed = false;
    for (const q of all) {
      if (!removeIds.has(q.id) && q.derivedFromId && removeIds.has(q.derivedFromId)) {
        removeIds.add(q.id);
        changed = true;
      }
    }
  }
  if (removeIds.size) await db.delete(quantities).where(inArray(quantities.id, [...removeIds]));

  /* --- nodos de estructura de esa actividad --- */
  const nodes = await db.select().from(structureNodes).where(eq(structureNodes.projectId, projectId));
  const activityNodes = nodes.filter((n) => n.kind === "ACTIVIDAD" && n.activityId === activityId);
  if (activityNodes.length) {
    await db.delete(structureNodes).where(inArray(structureNodes.id, activityNodes.map((n) => n.id)));
  }
  const podados = await pruneEmptyStructure(projectId);

  await addDecision(projectId, "ESTRUCTURA", activityId, "ELIMINO_ACTIVIDAD_ESTRUCTURA", {
    actividad: act ? `${act.code} ${act.name}` : activityId,
    cantidadesEliminadas: removeIds.size,
    nodosRetirados: activityNodes.length + podados,
    soloVacias,
    nota: "La actividad se retiró de la estructura del proyecto. El catálogo maestro y la evidencia IFC no se modifican.",
  }, actor);

  return NextResponse.json({
    ok: true,
    actividad: act ? `${act.code} ${act.name}` : activityId,
    cantidadesEliminadas: removeIds.size,
    nodosRetirados: activityNodes.length + podados,
  });
}

/** Depura de una sola vez todas las líneas sin cantidad del proyecto. */
export async function POST(req: Request) {
  const body = await req.json();
  const { projectId, actor, action } = body ?? {};
  if (!projectId) return NextResponse.json({ error: "projectId requerido." }, { status: 400 });
  if (action !== "prune") return NextResponse.json({ error: `Acción no soportada: ${action}` }, { status: 400 });

  const nodesBefore = await db.select().from(structureNodes).where(eq(structureNodes.projectId, projectId));
  const qtys = await db.select().from(quantities).where(eq(quantities.projectId, projectId));

  /* Actividades cuyas cantidades suman 0 o no existen */
  const sums = new Map<string, number>();
  for (const q of qtys) {
    if (!q.activityId) continue;
    if (q.status === "RECHAZADA") continue;
    sums.set(q.activityId, (sums.get(q.activityId) ?? 0) + (q.value ?? 0));
  }
  const emptyActivities = nodesBefore
    .filter((n) => n.kind === "ACTIVIDAD" && n.activityId)
    .filter((n) => (sums.get(n.activityId!) ?? 0) <= 0)
    .map((n) => n.activityId!) as string[];

  let eliminadas = 0;
  if (emptyActivities.length) {
    const toDelete = qtys.filter((q) => q.activityId && emptyActivities.includes(q.activityId));
    if (toDelete.length) {
      await db.delete(quantities).where(inArray(quantities.id, toDelete.map((q) => q.id)));
      eliminadas = toDelete.length;
    }
    const nodes = nodesBefore.filter((n) => n.kind === "ACTIVIDAD" && n.activityId && emptyActivities.includes(n.activityId));
    if (nodes.length) await db.delete(structureNodes).where(inArray(structureNodes.id, nodes.map((n) => n.id)));
  }
  const podados = await pruneEmptyStructure(projectId);

  await addDecision(projectId, "ESTRUCTURA", null, "DEPURO_ESTRUCTURA", {
    actividadesEnCero: emptyActivities.length,
    cantidadesEliminadas: eliminadas,
    nodosRetirados: podados,
    nota: "Depuración de líneas sin cantidad para que no aparezcan en el presupuesto ni en la exportación.",
  }, actor);

  return NextResponse.json({
    ok: true,
    actividadesEnCero: emptyActivities.length,
    cantidadesEliminadas: eliminadas,
    nodosRetirados: podados,
  });
}
