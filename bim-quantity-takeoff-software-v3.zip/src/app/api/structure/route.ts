import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { sortByCode } from "@/lib/codes";
import { structureNodes, quantities, catalogActivities, sources, projects } from "@/db/schema";

export interface Rollup {
  validada: number;
  propuesta: number;
  pendiente: number;
  lineas: number;
  fuentes: string[];
  unidad: string | null;
  derivadas: number;
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const projectId = url.searchParams.get("projectId");
  if (!projectId) return NextResponse.json({ error: "projectId requerido" }, { status: 400 });

  const [project] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!project) return NextResponse.json({ error: "Proyecto no encontrado" }, { status: 404 });

  const nodes = await db.select().from(structureNodes).where(eq(structureNodes.projectId, projectId));
  const qtys = await db.select().from(quantities).where(eq(quantities.projectId, projectId));
  const acts = await db.select().from(catalogActivities);
  const actMap = new Map(acts.map((a) => [a.id, a]));
  const src = await db.select({ id: sources.id, name: sources.name, kind: sources.kind }).from(sources).where(eq(sources.projectId, projectId));
  const srcMap = new Map(src.map((s) => [s.id, s]));

  const byActivity = new Map<string, Rollup>();
  for (const q of qtys) {
    if (!q.activityId) continue;
    const cur = byActivity.get(q.activityId) ?? { validada: 0, propuesta: 0, pendiente: 0, lineas: 0, fuentes: [], unidad: null, derivadas: 0 };
    cur.lineas++;
    cur.unidad = q.unit;
    if (q.derivedFromId) cur.derivadas++;
    if (q.status === "VALIDADA") cur.validada += q.value ?? 0;
    if (q.status === "PROPUESTA") cur.propuesta += q.value ?? 0;
    if (q.status === "PENDIENTE") cur.pendiente++;
    const fname = q.sourceId ? srcMap.get(q.sourceId)?.name : null;
    const origen = fname ?? ((q.evidence as { fuentes?: string[] } | null)?.fuentes?.join(" + ") || (q.sourceKind === "MANUAL" ? "Cantidades manuales" : "IFC"));
    if (origen && !cur.fuentes.includes(origen)) cur.fuentes.push(origen);
    byActivity.set(q.activityId, cur);
  }

  const chapters = sortByCode(nodes.filter((n) => n.kind === "CAPITULO"), (n) => n.code);
  const sections = sortByCode(nodes.filter((n) => n.kind === "SECCION"), (n) => n.code);
  /*
   * Consolidación: una actividad aparece UNA sola vez en el presupuesto,
   * aunque provenga de varios grupos, fuentes o derivaciones. Si existieran
   * nodos repetidos (p. ej. la actividad se añadió dos veces), se conserva
   * el primero en orden jerárquico y los demás se descartan de la vista.
   */
  const seenActivities = new Set<string>();
  const actNodes = sortByCode(nodes.filter((n) => n.kind === "ACTIVIDAD"), (n) => n.code)
    .filter((n) => {
      if (!n.activityId) return true;
      if (seenActivities.has(n.activityId)) return false;
      seenActivities.add(n.activityId);
      return true;
    });

  let directo = 0;
  const tree = chapters.map((ch) => {
    let chapterTotal = 0;
    const secs = sections
      .filter((s) => s.parentId === ch.id)
      .map((s) => {
        let sectionTotal = 0;
        const activities = actNodes
          .filter((a) => a.parentId === s.id)
          .map((a) => {
            const info = a.activityId ? actMap.get(a.activityId) : null;
            const rollup = a.activityId ? byActivity.get(a.activityId) ?? null : null;
            const unitPrice = info?.unitPrice ?? 0;
            const cantidad = rollup?.validada ?? 0;
            const total = Math.round(cantidad * unitPrice * 100) / 100;
            sectionTotal += total;
            const sinCantidad = (rollup?.lineas ?? 0) === 0 || (cantidad === 0 && (rollup?.propuesta ?? 0) === 0);
            return {
              ...a,
              unidad: info?.unit ?? null,
              metodo: info?.method ?? null,
              unitPrice,
              precioFuente: info?.priceSource ?? null,
              total,
              rollup,
              /** Línea vacía: candidata a depurar antes de exportar. */
              sinCantidad,
            };
          });
        chapterTotal += sectionTotal;
        return { ...s, activities, total: Math.round(sectionTotal * 100) / 100 };
      });
    directo += chapterTotal;
    return { ...ch, sections: secs, total: Math.round(chapterTotal * 100) / 100 };
  });

  const st = project.settings ?? {};
  const admin = (st.administracion ?? 0) / 100;
  const imp = (st.imprevistos ?? 0) / 100;
  const util = (st.utilidad ?? 0) / 100;
  const ivaPct = (st.iva ?? 0) / 100;

  const vAdmin = Math.round(directo * admin * 100) / 100;
  const vImp = Math.round(directo * imp * 100) / 100;
  const vUtil = Math.round(directo * util * 100) / 100;

  // Bases del IVA elegidas por el profesional (Colombia: por defecto solo utilidad)
  const bases = st.ivaBases ?? (st.ivaSobreUtilidad === false
    ? ["DIRECTO", "ADMINISTRACION", "IMPREVISTOS", "UTILIDAD"]
    : ["UTILIDAD"]);
  let baseIva = 0;
  if (bases.includes("DIRECTO")) baseIva += directo;
  if (bases.includes("ADMINISTRACION")) baseIva += vAdmin;
  if (bases.includes("IMPREVISTOS")) baseIva += vImp;
  if (bases.includes("UTILIDAD")) baseIva += vUtil;
  const vIva = Math.round(baseIva * ivaPct * 100) / 100;

  const participating = new Set(actNodes.map((a) => a.activityId).filter(Boolean));
  const sinPrecio = actNodes.filter((a) => {
    const info = a.activityId ? actMap.get(a.activityId) : null;
    return info ? !info.unitPrice : false;
  }).length;

  return NextResponse.json({
    tree,
    totales: {
      costoDirecto: Math.round(directo * 100) / 100,
      administracion: vAdmin,
      imprevistos: vImp,
      utilidad: vUtil,
      iva: vIva,
      total: Math.round((directo + vAdmin + vImp + vUtil + vIva) * 100) / 100,
      porcentajes: {
        administracion: st.administracion ?? 0,
        imprevistos: st.imprevistos ?? 0,
        utilidad: st.utilidad ?? 0,
        iva: st.iva ?? 0,
        ivaBases: bases,
        baseIva: Math.round(baseIva * 100) / 100,
      },
      moneda: st.currency ?? "COP",
      actividadesSinPrecio: sinPrecio,
      actividadesSinCantidad: tree.reduce(
        (acc, ch) => acc + ch.sections.reduce(
          (a2, s) => a2 + s.activities.filter((x) => x.sinCantidad).length, 0), 0),
    },
    participando: [...participating],
  });
}
