import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { quantities, catalogActivities, sources } from "@/db/schema";
import { addDecision, ensureManualSource, ensureStructureNodes } from "@/lib/server";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const projectId = url.searchParams.get("projectId");
  if (!projectId) return NextResponse.json({ error: "projectId requerido" }, { status: 400 });

  const rows = await db
    .select()
    .from(quantities)
    .where(eq(quantities.projectId, projectId))
    .orderBy(desc(quantities.createdAt));

  const acts = await db.select().from(catalogActivities);
  const actMap = new Map(acts.map((a) => [a.id, a]));
  const src = await db.select({ id: sources.id, name: sources.name, kind: sources.kind, discipline: sources.discipline }).from(sources).where(eq(sources.projectId, projectId));
  const srcMap = new Map(src.map((s) => [s.id, s]));

  const byId = new Map(rows.map((r) => [r.id, r]));
  return NextResponse.json({
    quantities: rows.map((q) => {
      const origin = q.derivedFromId ? byId.get(q.derivedFromId) : null;
      const originAct = origin?.activityId ? actMap.get(origin.activityId) : null;
      return {
        ...q,
        actividad: q.activityId ? actMap.get(q.activityId) ?? null : null,
        fuente: q.sourceId ? srcMap.get(q.sourceId) ?? null : null,
        derivadaDe: origin
          ? {
              id: origin.id,
              actividad: originAct ? `${originAct.code} ${originAct.name}` : null,
              valor: origin.value,
              unidad: origin.unit,
              estado: origin.status,
            }
          : null,
        derivadas: rows.filter((r) => r.derivedFromId === q.id).length,
      };
    }),
  });
}

export async function POST(req: Request) {
  const body = await req.json();
  const { projectId, activityId, value, note, actor, planned } = body ?? {};
  if (!projectId || !activityId) {
    return NextResponse.json({ error: "projectId y activityId son obligatorios." }, { status: 400 });
  }
  const [act] = await db.select().from(catalogActivities).where(eq(catalogActivities.id, activityId)).limit(1);
  if (!act) return NextResponse.json({ error: "Actividad no encontrada en el catálogo." }, { status: 404 });

  const manualSource = await ensureManualSource(projectId);
  const hasValue = typeof value === "number" && isFinite(value);

  const [qty] = await db
    .insert(quantities)
    .values({
      projectId,
      activityId: act.id,
      sourceId: manualSource.id,
      sourceKind: "MANUAL",
      value: hasValue ? value : null,
      unit: act.unit,
      method: "MANUAL",
      rule: hasValue
        ? "Cantidad medida manualmente por el profesional (medición directa, no proviene del modelo BIM)."
        : "Actividad planificada en la estructura del proyecto. Pendiente de medición.",
      evidence: {
        origen: "Medición manual",
        registradaEn: new Date().toISOString(),
        nota: note ?? null,
        advertencias: hasValue ? [] : ["Sin cantidad: complete el valor antes de validar."],
      },
      elementIds: [],
      elementCount: 0,
      status: hasValue ? "VALIDADA" : "PENDIENTE",
      note: note ?? null,
      validatedBy: hasValue ? actor ?? null : null,
      validatedAt: hasValue ? new Date() : null,
    })
    .returning();

  await ensureStructureNodes(projectId, act.id);
  await addDecision(
    projectId, "CANTIDAD", qty.id,
    hasValue ? "INGRESO_CANTIDAD_MANUAL" : planned ? "PLANIFICO_ACTIVIDAD" : "INGRESO_CANTIDAD_MANUAL",
    { actividad: `${act.code} ${act.name}`, valor: value ?? null, unidad: act.unit, nota: note ?? null },
    actor
  );

  return NextResponse.json({ quantity: qty });
}
