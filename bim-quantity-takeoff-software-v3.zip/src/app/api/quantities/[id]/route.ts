import { NextResponse } from "next/server";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { quantities, elements as elementsTable, catalogActivities, type MeasureConfig } from "@/db/schema";
import { measureElements, defaultConfigFor } from "@/lib/engine";
import { toWorkElement, addDecision, ensureStructureNodes, pruneEmptyStructure } from "@/lib/server";

/**
 * Elimina definitivamente una cantidad y sus derivadas.
 * Se usa para depurar líneas que quedaron en cero tras cambiar de actividad.
 * La decisión queda registrada en el historial de trazabilidad.
 */
export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const url = new URL(req.url);
  const actor = url.searchParams.get("actor");
  const motivo = url.searchParams.get("motivo");

  const [qty] = await db.select().from(quantities).where(eq(quantities.id, id)).limit(1);
  if (!qty) return NextResponse.json({ error: "Cantidad no encontrada" }, { status: 404 });

  const all = await db.select().from(quantities).where(eq(quantities.projectId, qty.projectId));
  const removeIds = new Set([id]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const q of all) {
      if (!removeIds.has(q.id) && q.derivedFromId && removeIds.has(q.derivedFromId)) {
        removeIds.add(q.id);
        changed = true;
      }
    }
  }

  const [act] = qty.activityId
    ? await db.select().from(catalogActivities).where(eq(catalogActivities.id, qty.activityId)).limit(1)
    : [undefined];

  await db.delete(quantities).where(inArray(quantities.id, [...removeIds]));
  await pruneEmptyStructure(qty.projectId);

  await addDecision(qty.projectId, "CANTIDAD", id, "ELIMINO_CANTIDAD", {
    actividad: act ? `${act.code} ${act.name}` : qty.label ?? null,
    valor: qty.value, unidad: qty.unit, estado: qty.status,
    derivadasEliminadas: removeIds.size - 1,
    motivo: motivo ?? null,
    nota: "La cantidad se retiró del proyecto. La evidencia IFC original permanece intacta.",
  }, actor);

  return NextResponse.json({ ok: true, eliminadas: removeIds.size });
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await req.json();
  const { action, value, note, actor, activityId, measureConfig, label } = body ?? {};

  const [qty] = await db.select().from(quantities).where(eq(quantities.id, id)).limit(1);
  if (!qty) return NextResponse.json({ error: "Cantidad no encontrada" }, { status: 404 });

  const remeasure = async (cfg: MeasureConfig, method: string, unit: string, activity?: string) => {
    const els = qty.elementIds?.length
      ? await db.select().from(elementsTable).where(inArray(elementsTable.id, qty.elementIds as string[]))
      : [];
    const work = els.map(toWorkElement).filter((w) => !w.excluded);
    const measured = measureElements(work, method, cfg);
    const prev = (qty.evidence ?? {}) as Record<string, unknown>;
    await db.update(quantities).set({
      value: measured.value,
      unit,
      method,
      measureConfig: cfg,
      rule: measured.rule,
      elementIds: work.map((w) => w.id),
      elementGlobalIds: work.map((w) => w.globalId).filter((g): g is string => !!g),
      elementCount: work.length,
      status: "PROPUESTA",
      activityId: activity ?? qty.activityId,
      evidence: {
        ...prev,
        recomputadaEn: new Date().toISOString(),
        camposUtilizados: measured.fields,
        elementosMedidos: measured.measuredCount,
        elementosSinDato: measured.missing,
        elementosSinDatoEjemplos: measured.missingElements,
        configuracionMedicion: cfg,
        valorAnterior: qty.value,
      },
    }).where(eq(quantities.id, id));
    return measured;
  };

  switch (action) {
    case "validate": {
      if (qty.value === null) {
        return NextResponse.json({ error: "No puede validar una cantidad sin valor. Complete la medición primero." }, { status: 400 });
      }
      await db.update(quantities).set({
        status: "VALIDADA", validatedBy: actor ?? null, validatedAt: new Date(), note: note ?? qty.note,
      }).where(eq(quantities.id, id));
      if (qty.activityId) await ensureStructureNodes(qty.projectId, qty.activityId);
      await addDecision(qty.projectId, "CANTIDAD", id, "VALIDO_CANTIDAD", {
        valor: qty.value, unidad: qty.unit, metodo: qty.method, nota: note ?? null,
      }, actor);
      return NextResponse.json({ ok: true, status: "VALIDADA" });
    }

    case "reject": {
      await db.update(quantities).set({ status: "RECHAZADA" }).where(eq(quantities.id, id));
      await addDecision(qty.projectId, "CANTIDAD", id, "RECHAZO_CANTIDAD", {
        valor: qty.value, unidad: qty.unit, nota: note ?? null,
      }, actor);
      return NextResponse.json({ ok: true, status: "RECHAZADA" });
    }

    case "edit": {
      if (typeof value !== "number" || !isFinite(value)) {
        return NextResponse.json({ error: "value numérico requerido." }, { status: 400 });
      }
      const prev = (qty.evidence ?? {}) as Record<string, unknown>;
      await db.update(quantities).set({
        value, status: "VALIDADA", validatedBy: actor ?? null, validatedAt: new Date(),
        note: note ?? qty.note,
        rule: qty.method === "MANUAL"
          ? "Cantidad medida manualmente por el profesional."
          : `Cantidad corregida profesionalmente (el método había calculado ${qty.value ?? "—"}). La corrección queda registrada como decisión.`,
        evidence: {
          ...prev,
          correccionProfesional: {
            valorAnterior: qty.value, valorNuevo: value,
            fecha: new Date().toISOString(), actor: actor ?? null, motivo: note ?? null,
          },
        },
      }).where(eq(quantities.id, id));
      if (qty.activityId) await ensureStructureNodes(qty.projectId, qty.activityId);
      await addDecision(qty.projectId, "CANTIDAD", id, "CORRIGIO_CANTIDAD", {
        valorAnterior: qty.value, valorNuevo: value, unidad: qty.unit, nota: note ?? null,
      }, actor);
      return NextResponse.json({ ok: true, status: "VALIDADA" });
    }

    case "remeasure": {
      if (!qty.elementIds?.length) {
        return NextResponse.json({ error: "Esta cantidad no tiene elementos BIM asociados para re-medir." }, { status: 400 });
      }
      if (qty.method === "MANUAL") {
        return NextResponse.json({ error: "El método de esta cantidad es manual." }, { status: 400 });
      }
      const cfg = (measureConfig as MeasureConfig | undefined) ?? (qty.measureConfig as MeasureConfig | null) ?? {};
      const measured = await remeasure(cfg, qty.method, qty.unit);
      await addDecision(qty.projectId, "CANTIDAD", id, "REMIDIO_CANTIDAD", {
        valorAnterior: qty.value, valorNuevo: measured.value, metodo: qty.method,
        configuracion: cfg, elementos: measured.measuredCount, nota: note ?? null,
      }, actor);
      return NextResponse.json({ ok: true, status: "PROPUESTA", value: measured.value, aviso: measured.missing ? `${measured.missing} elemento(s) sin datos` : null });
    }

    case "configure": {
      const cfg = (measureConfig as MeasureConfig | undefined) ?? {};
      if (!qty.elementIds?.length) {
        await db.update(quantities).set({ measureConfig: cfg }).where(eq(quantities.id, id));
        return NextResponse.json({ ok: true });
      }
      const measured = await remeasure(cfg, qty.method, qty.unit);
      await addDecision(qty.projectId, "CANTIDAD", id, "CAMBIO_REGLA_MEDICION", {
        configuracionAnterior: qty.measureConfig, configuracionNueva: cfg,
        valorAnterior: qty.value, valorNuevo: measured.value, nota: note ?? null,
      }, actor);
      return NextResponse.json({ ok: true, value: measured.value, rule: measured.rule });
    }

    case "assign": {
      if (!activityId) return NextResponse.json({ error: "activityId requerido." }, { status: 400 });
      const [act] = await db.select().from(catalogActivities).where(eq(catalogActivities.id, activityId)).limit(1);
      if (!act) return NextResponse.json({ error: "Actividad no encontrada." }, { status: 404 });
      const cfg = (act.measureConfig as MeasureConfig | null) ?? defaultConfigFor(act.method, []);
      if (qty.elementIds?.length && act.method !== "MANUAL") {
        await remeasure(cfg, act.method, act.unit || qty.unit, act.id);
      } else {
        await db.update(quantities).set({
          activityId: act.id, unit: act.unit || qty.unit, method: act.method, measureConfig: cfg,
        }).where(eq(quantities.id, id));
      }
      await ensureStructureNodes(qty.projectId, act.id);
      await addDecision(qty.projectId, "CANTIDAD", id, "ASIGNO_ACTIVIDAD", {
        actividad: `${act.code} ${act.name}`, nota: note ?? null,
      }, actor);
      return NextResponse.json({ ok: true });
    }

    case "rename": {
      await db.update(quantities).set({ label: label ?? null }).where(eq(quantities.id, id));
      return NextResponse.json({ ok: true });
    }

    default:
      return NextResponse.json({ error: `Acción no soportada: ${action}` }, { status: 400 });
  }
}
