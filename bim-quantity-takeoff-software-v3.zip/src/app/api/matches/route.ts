import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  matches as matchesTable, groups as groupsTable, catalogActivities, groupingRuns, sources,
} from "@/db/schema";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const projectId = url.searchParams.get("projectId");
  if (!projectId) return NextResponse.json({ error: "projectId requerido" }, { status: 400 });
  const status = url.searchParams.get("status");

  const rows = await db
    .select()
    .from(matchesTable)
    .where(eq(matchesTable.projectId, projectId))
    .orderBy(desc(matchesTable.createdAt));

  const runIds = [...new Set(rows.map((r) => r.runId))];
  const runs = runIds.length
    ? await db.select().from(groupingRuns).where(eq(groupingRuns.projectId, projectId))
    : [];
  const latestRunId = runs.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt))[0]?.id;

  const filtered = rows.filter((r) => {
    if (status && status !== "TODAS" && r.status !== status) return false;
    return true;
  });

  const groupIds = [...new Set(filtered.map((r) => r.groupId))];
  const grp = groupIds.length ? await db.select().from(groupsTable).where(eq(groupsTable.projectId, projectId)) : [];
  const grpMap = new Map(grp.map((g) => [g.id, g]));

  const acts = await db.select().from(catalogActivities);
  const actMap = new Map(acts.map((a) => [a.id, a]));

  const src = await db.select({ id: sources.id, name: sources.name, discipline: sources.discipline, kind: sources.kind }).from(sources).where(eq(sources.projectId, projectId));
  const srcMap = new Map(src.map((s) => [s.id, s]));

  const out = filtered.map((r) => {
    const g = grpMap.get(r.groupId) ?? null;
    return {
      ...r,
      esCorridaActual: r.runId === latestRunId,
      grupo: g
        ? {
            id: g.id, groupKey: g.groupKey, criteriaValues: g.criteriaValues,
            elementCount: g.elementCount, ifcClasses: g.ifcClasses,
            fuentes: (g.sourceIds ?? []).map((sid) => srcMap.get(sid)?.name ?? "?"),
          }
        : null,
      actividad: r.activityId ? actMap.get(r.activityId) ?? null : null,
    };
  });

  return NextResponse.json({ matches: out, latestRunId, total: out.length });
}
