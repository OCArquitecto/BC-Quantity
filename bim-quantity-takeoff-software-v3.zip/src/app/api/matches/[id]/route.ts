import { NextResponse } from "next/server";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import {
  matches as matchesTable, groups as groupsTable, catalogActivities,
  elements as elementsTable, quantities, sources, type MeasureConfig,
} from "@/db/schema";
import { measureElements, defaultConfigFor, familyLabel } from "@/lib/engine";
import {
  toWorkElement, addDecision, ensureStructureNodes, findDuplicateMeasurements,
} from "@/lib/server";

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await req.json();
  const { action, activityId, actor, note, measureConfig, allowDuplicate } = body ?? {};

  const [match] = await db.select().from(matchesTable).where(eq(matchesTable.id, id)).limit(1);
  if (!match) return NextResponse.json({ error: "Correspondencia no encontrada" }, { status: 404 });

  const [group] = await db.select().from(groupsTable).where(eq(groupsTable.id, match.groupId)).limit(1);
  if (!group) return NextResponse.json({ error: "Grupo no encontrado" }, { status: 404 });

  /* ------------------------------------------------ RECHAZAR ------ */
  if (action === "reject") {
    await db
      .update(matchesTable)
      .set({ status: "RECHAZADA", decidedBy: actor ?? null, decidedAt: new Date(), decisionNote: note ?? null })
      .where(eq(matchesTable.id, id));
    await addDecision(match.projectId, "CORRESPONDENCIA", id, "RECHAZO_PROPUESTA", {
      grupo: group.groupKey, actividadPropuesta: match.activityId, puntaje: match.score, nota: note ?? null,
    }, actor);
    return NextResponse.json({ ok: true, status: "RECHAZADA" });
  }

  /* ------------------------------------------------ REABRIR ------- */
  if (action === "reopen") {
    await db
      .update(matchesTable)
      .set({ status: match.activityId ? "PROPUESTA" : "PENDIENTE", decidedBy: null, decidedAt: null })
      .where(eq(matchesTable.id, id));
    await addDecision(match.projectId, "CORRESPONDENCIA", id, "REABRIO_CORRESPONDENCIA", {
      grupo: group.groupKey, nota: note ?? null,
    }, actor);
    return NextResponse.json({ ok: true });
  }

  /* --------------------------------------------- VALIDAR/CAMBIAR --- */
  if (action === "validate") {
    const finalActivityId = activityId ?? match.activityId;
    if (!finalActivityId) {
      return NextResponse.json({ error: "Debe elegir una actividad del catálogo para validar." }, { status: 400 });
    }
    const [act] = await db.select().from(catalogActivities).where(eq(catalogActivities.id, finalActivityId)).limit(1);
    if (!act) return NextResponse.json({ error: "Actividad no encontrada en el catálogo." }, { status: 404 });

    const changed = match.activityId && match.activityId !== finalActivityId;

    const els = group.elementIds.length
      ? await db.select().from(elementsTable).where(inArray(elementsTable.id, group.elementIds as string[]))
      : [];
    const work = els.map(toWorkElement).filter((w) => !w.excluded);
    const globalIds = work.map((w) => w.globalId).filter((g): g is string => !!g);

    /* --- control de duplicados por GlobalId IFC --- */
    const dup = await findDuplicateMeasurements(match.projectId, act.id, globalIds);
    if (dup.total > 0 && !allowDuplicate) {
      return NextResponse.json({
        error: "DUPLICADO",
        duplicado: {
          mensaje: `${dup.total} elemento(s) de este grupo ya fueron medidos para la actividad ${act.code}. Confirme si desea duplicar la medición.`,
          elementos: dup.total,
          actividad: `${act.code} ${act.name}`,
          sugerencia: "Si se trata de un acabado sobre elementos ya medidos, use «Derivar actividad» desde Cantidades para conservar el vínculo con el origen.",
        },
      }, { status: 409 });
    }

    const srcRows = work.length
      ? await db.select({ id: sources.id, name: sources.name }).from(sources).where(inArray(sources.id, [...new Set(work.map((w) => w.sourceId))]))
      : [];
    const srcById = new Map(srcRows.map((s) => [s.id, s.name]));

    const cfg: MeasureConfig =
      (measureConfig as MeasureConfig | undefined) ??
      (act.measureConfig as MeasureConfig | null) ??
      defaultConfigFor(act.method, group.ifcClasses as string[]);

    const measured = measureElements(work, act.method, cfg);
    const isManual = act.method === "MANUAL";

    const [qty] = await db
      .insert(quantities)
      .values({
        projectId: match.projectId,
        matchId: match.id,
        groupId: group.id,
        activityId: act.id,
        sourceId: null,
        sourceKind: "IFC",
        value: isManual ? null : measured.value,
        unit: act.unit,
        method: act.method,
        measureConfig: cfg,
        rule: measured.rule,
        evidence: {
          computadaEn: new Date().toISOString(),
          criteriosAgrupacion: group.criteriaValues,
          grupo: group.groupKey,
          clases: group.ifcClasses,
          familiaBIM: (group.ifcClasses as string[]).map(familyLabel),
          fuentes: [...new Set(work.map((w) => srcById.get(w.sourceId) ?? "?"))],
          camposUtilizados: measured.fields,
          elementosMedidos: measured.measuredCount,
          elementosSinDato: measured.missing,
          elementosSinDatoEjemplos: measured.missingElements,
          configuracionMedicion: cfg,
          advertencias: [
            ...(measured.missing > 0 ? [`${measured.missing} elemento(s) sin dato geométrico ni cantidad IFC: no aportan a la suma.`] : []),
            ...(changed ? ["El profesional cambió la actividad propuesta por otra del catálogo."] : []),
            ...(dup.total > 0 ? [`Duplicación autorizada por el profesional: ${dup.total} elemento(s) ya medidos en esta actividad.`] : []),
          ],
          porQueEstaActividad: {
            puntaje: match.score,
            coincidencias: (match.evidence as Record<string, unknown> | null)?.coincidencias ?? [],
            reglaBIM: (match.evidence as Record<string, unknown> | null)?.reglaBIM ?? null,
            decision: "VALIDADA por decisión profesional",
          },
        },
        elementIds: work.map((w) => w.id),
        elementGlobalIds: globalIds,
        elementCount: work.length,
        status: isManual ? "PENDIENTE" : "PROPUESTA",
        note: note ?? null,
      })
      .returning();

    await db
      .update(matchesTable)
      .set({
        status: "VALIDADA", activityId: finalActivityId,
        decidedBy: actor ?? null, decidedAt: new Date(), decisionNote: note ?? null,
      })
      .where(eq(matchesTable.id, id));

    await ensureStructureNodes(match.projectId, act.id);

    await addDecision(match.projectId, "CORRESPONDENCIA", id, changed ? "CAMBIO_Y_VALIDO_ACTIVIDAD" : "VALIDO_CORRESPONDENCIA", {
      grupo: group.groupKey,
      actividad: `${act.code} ${act.name}`,
      cantidadCalculada: measured.value, unidad: act.unit, metodo: act.method,
      configuracion: cfg, elementos: work.length,
      elementosSinDato: measured.missing,
      duplicacionAutorizada: dup.total > 0 ? dup.total : undefined,
      nota: note ?? null,
    }, actor);

    return NextResponse.json({ ok: true, status: "VALIDADA", quantity: qty, aviso: measured.missing > 0 ? `${measured.missing} elemento(s) sin datos de medición` : null });
  }

  return NextResponse.json({ error: `Acción no soportada: ${action}` }, { status: 400 });
}
