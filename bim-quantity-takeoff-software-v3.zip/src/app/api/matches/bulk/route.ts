import { NextResponse } from "next/server";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import {
  matches as matchesTable, groups as groupsTable, catalogActivities,
  elements as elementsTable, quantities, sources, type MeasureConfig,
} from "@/db/schema";
import { measureElements, defaultConfigFor, familyLabel } from "@/lib/engine";
import { toWorkElement, addDecision, ensureStructureNodes, findDuplicateMeasurements } from "@/lib/server";

/**
 * Acciones masivas sobre correspondencias.
 * Cada elemento del lote queda registrado individualmente como decisión.
 */
export async function POST(req: Request) {
  const body = await req.json();
  const { ids, action, actor, note, allowDuplicate, activityId } = body ?? {};
  if (!Array.isArray(ids) || !ids.length) {
    return NextResponse.json({ error: "Seleccione al menos una correspondencia." }, { status: 400 });
  }
  if (!["validate", "reject", "reopen"].includes(action)) {
    return NextResponse.json({ error: `Acción no soportada: ${action}` }, { status: 400 });
  }

  const rows = await db.select().from(matchesTable).where(inArray(matchesTable.id, ids as string[]));
  if (!rows.length) return NextResponse.json({ error: "No se encontraron correspondencias." }, { status: 404 });

  const projectId = rows[0].projectId;
  const result = {
    procesadas: 0, validadas: 0, rechazadas: 0, reabiertas: 0,
    omitidasSinActividad: 0, omitidasPorDuplicado: 0,
    totalElementosSinDato: 0,
    detalle: [] as { id: string; estado: string; actividad?: string; cantidad?: number | null; unidad?: string; motivo?: string }[],
  };

  /* ---------------- RECHAZO / REAPERTURA MASIVA ------------------- */
  if (action === "reject" || action === "reopen") {
    for (const m of rows) {
      if (action === "reject") {
        await db.update(matchesTable).set({
          status: "RECHAZADA", decidedBy: actor ?? null, decidedAt: new Date(), decisionNote: note ?? null,
        }).where(eq(matchesTable.id, m.id));
        result.rechazadas++;
        result.detalle.push({ id: m.id, estado: "RECHAZADA" });
      } else {
        await db.update(matchesTable).set({
          status: m.activityId ? "PROPUESTA" : "PENDIENTE", decidedBy: null, decidedAt: null,
        }).where(eq(matchesTable.id, m.id));
        result.reabiertas++;
        result.detalle.push({ id: m.id, estado: "REABIERTA" });
      }
      result.procesadas++;
    }
    await addDecision(projectId, "CORRESPONDENCIA", null,
      action === "reject" ? "RECHAZO_MASIVO" : "REAPERTURA_MASIVA",
      { correspondencias: rows.length, nota: note ?? null }, actor);
    return NextResponse.json(result);
  }

  /* ---------------- VALIDACIÓN MASIVA ----------------------------- */
  const groupIds = [...new Set(rows.map((m) => m.groupId))];
  const grps = await db.select().from(groupsTable).where(inArray(groupsTable.id, groupIds));
  const grpMap = new Map(grps.map((g) => [g.id, g]));
  const acts = await db.select().from(catalogActivities);
  const actMap = new Map(acts.map((a) => [a.id, a]));
  const srcRows = await db.select({ id: sources.id, name: sources.name }).from(sources).where(eq(sources.projectId, projectId));
  const srcById = new Map(srcRows.map((s) => [s.id, s.name]));

  for (const m of rows) {
    const group = grpMap.get(m.groupId);
    const finalActivityId = (activityId as string | undefined) ?? m.activityId;
    if (!group || !finalActivityId) {
      result.omitidasSinActividad++;
      result.detalle.push({ id: m.id, estado: "OMITIDA", motivo: "Sin actividad asignada: requiere decisión individual." });
      continue;
    }
    const act = actMap.get(finalActivityId);
    if (!act) {
      result.omitidasSinActividad++;
      result.detalle.push({ id: m.id, estado: "OMITIDA", motivo: "Actividad inexistente." });
      continue;
    }

    const els = group.elementIds.length
      ? await db.select().from(elementsTable).where(inArray(elementsTable.id, group.elementIds as string[]))
      : [];
    const work = els.map(toWorkElement).filter((w) => !w.excluded);
    const globalIds = work.map((w) => w.globalId).filter((g): g is string => !!g);

    const dup = await findDuplicateMeasurements(projectId, act.id, globalIds);
    if (dup.total > 0 && !allowDuplicate) {
      result.omitidasPorDuplicado++;
      result.detalle.push({
        id: m.id, estado: "OMITIDA", actividad: act.code,
        motivo: `${dup.total} elemento(s) ya medidos en esta actividad. Valide individualmente para autorizar la duplicación.`,
      });
      continue;
    }

    const cfg: MeasureConfig =
      (act.measureConfig as MeasureConfig | null) ?? defaultConfigFor(act.method, group.ifcClasses as string[]);
    const measured = measureElements(work, act.method, cfg);
    const isManual = act.method === "MANUAL";
    result.totalElementosSinDato += measured.missing;

    await db.insert(quantities).values({
      projectId, matchId: m.id, groupId: group.id, activityId: act.id,
      sourceId: null, sourceKind: "IFC",
      value: isManual ? null : measured.value,
      unit: act.unit, method: act.method, measureConfig: cfg, rule: measured.rule,
      evidence: {
        computadaEn: new Date().toISOString(),
        criteriosAgrupacion: group.criteriaValues,
        grupo: group.groupKey,
        clases: group.ifcClasses,
        familiaBIM: (group.ifcClasses as string[]).map(familyLabel),
        fuentes: [...new Set(work.map((w) => srcById.get(w.sourceId) ?? "?"))],
        camposUtilizados: measured.fields,
        elementosMedidos: measured.measuredCount,
        elementosSinDato: measured.missing,
        elementosSinDatoEjemplos: measured.missingElements,
        configuracionMedicion: cfg,
        validacionMasiva: true,
        advertencias: [
          ...(measured.missing > 0 ? [`${measured.missing} elemento(s) sin dato geométrico ni cantidad IFC.`] : []),
          ...(dup.total > 0 ? [`Duplicación autorizada en lote: ${dup.total} elemento(s).`] : []),
        ],
        porQueEstaActividad: {
          puntaje: m.score,
          coincidencias: (m.evidence as Record<string, unknown> | null)?.coincidencias ?? [],
          decision: "VALIDADA en lote por decisión profesional",
        },
      },
      elementIds: work.map((w) => w.id),
      elementGlobalIds: globalIds,
      elementCount: work.length,
      status: isManual ? "PENDIENTE" : "PROPUESTA",
      note: note ?? null,
    });

    await db.update(matchesTable).set({
      status: "VALIDADA", activityId: act.id,
      decidedBy: actor ?? null, decidedAt: new Date(), decisionNote: note ?? null,
    }).where(eq(matchesTable.id, m.id));

    await ensureStructureNodes(projectId, act.id);
    await addDecision(projectId, "CORRESPONDENCIA", m.id, "VALIDO_CORRESPONDENCIA", {
      grupo: group.groupKey, actividad: `${act.code} ${act.name}`,
      cantidadCalculada: measured.value, unidad: act.unit, metodo: act.method,
      elementos: work.length, enLote: true, nota: note ?? null,
    }, actor);

    result.validadas++;
    result.procesadas++;
    result.detalle.push({ id: m.id, estado: "VALIDADA", actividad: act.code, cantidad: measured.value, unidad: act.unit });
  }

  await addDecision(projectId, "CORRESPONDENCIA", null, "VALIDACION_MASIVA", {
    seleccionadas: rows.length, validadas: result.validadas,
    omitidasSinActividad: result.omitidasSinActividad,
    omitidasPorDuplicado: result.omitidasPorDuplicado,
    nota: note ?? null,
  }, actor);

  return NextResponse.json(result);
}
