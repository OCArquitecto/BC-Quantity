import { db } from "@/db";
import { sql } from "drizzle-orm";
import { BIMCOST_VERSION, BIMCOST_BUILD } from "@/lib/version";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    return Response.json({ ok: true, version: BIMCOST_VERSION, build: BIMCOST_BUILD });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
