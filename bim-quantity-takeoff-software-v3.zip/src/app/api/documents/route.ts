import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { sortByCode } from "@/lib/codes";
import {
  projects, quantities, catalogActivities, sources, structureNodes, decisions, elements,
} from "@/db/schema";

/**
 * Datos consolidados para los documentos profesionales:
 *  · Presupuesto preliminar (estructura + precios + AIU)
 *  · Informe de trazabilidad (decisiones con observaciones, agrupadas)
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const projectId = url.searchParams.get("projectId");
  if (!projectId) return NextResponse.json({ error: "projectId requerido" }, { status: 400 });

  const [project] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!project) return NextResponse.json({ error: "Proyecto no encontrado" }, { status: 404 });

  const qtys = await db.select().from(quantities).where(eq(quantities.projectId, projectId));
  const acts = await db.select().from(catalogActivities);
  const actMap = new Map(acts.map((a) => [a.id, a]));
  const src = await db.select().from(sources).where(eq(sources.projectId, projectId));
  const srcMap = new Map(src.map((s) => [s.id, s]));
  const nodes = await db.select().from(structureNodes).where(eq(structureNodes.projectId, projectId));
  const decs = await db.select().from(decisions).where(eq(decisions.projectId, projectId)).orderBy(desc(decisions.createdAt));
  const els = await db.select({ id: elements.id, excluded: elements.excluded, ifcClass: elements.ifcClass }).from(elements).where(eq(elements.projectId, projectId));

  /* ---------------- PRESUPUESTO ---------------- */
  const chapters = sortByCode(nodes.filter((n) => n.kind === "CAPITULO"), (n) => n.code);
  const sections = sortByCode(nodes.filter((n) => n.kind === "SECCION"), (n) => n.code);
  const actNodes = sortByCode(nodes.filter((n) => n.kind === "ACTIVIDAD"), (n) => n.code);

  const qtyByActivity = new Map<string, { validada: number; unidad: string; lineas: number }>();
  for (const q of qtys) {
    if (!q.activityId || q.status !== "VALIDADA") continue;
    const cur = qtyByActivity.get(q.activityId) ?? { validada: 0, unidad: q.unit, lineas: 0 };
    cur.validada += q.value ?? 0;
    cur.lineas++;
    qtyByActivity.set(q.activityId, cur);
  }

  let directo = 0;
  const presupuesto = chapters
    .map((ch) => {
      let chTotal = 0;
      const secs = sections
        .filter((s) => s.parentId === ch.id)
        .map((s) => {
          let sTotal = 0;
          const items = actNodes
            .filter((a) => a.parentId === s.id)
            .map((a) => {
              const info = a.activityId ? actMap.get(a.activityId) : null;
              const roll = a.activityId ? qtyByActivity.get(a.activityId) : undefined;
              const cantidad = roll?.validada ?? 0;
              const precio = info?.unitPrice ?? 0;
              const total = Math.round(cantidad * precio * 100) / 100;
              sTotal += total;
              return {
                codigo: a.code,
                nombre: a.name,
                unidad: info?.unit ?? roll?.unidad ?? "",
                cantidad: Math.round(cantidad * 1000) / 1000,
                precioUnitario: precio,
                total,
                sinPrecio: precio === 0,
                sinCantidad: cantidad === 0,
              };
            })
            .filter((i) => i.cantidad > 0 || i.total > 0);
          chTotal += sTotal;
          return { codigo: s.code, nombre: s.name, total: Math.round(sTotal * 100) / 100, items };
        })
        .filter((s) => s.items.length > 0);
      directo += chTotal;
      return { codigo: ch.code, nombre: ch.name, total: Math.round(chTotal * 100) / 100, sections: secs };
    })
    .filter((c) => c.sections.length > 0);

  const st = project.settings ?? {};
  const pct = (v?: number) => (v ?? 0) / 100;
  const vAdmin = Math.round(directo * pct(st.administracion) * 100) / 100;
  const vImp = Math.round(directo * pct(st.imprevistos) * 100) / 100;
  const vUtil = Math.round(directo * pct(st.utilidad) * 100) / 100;
  const ivaBases = st.ivaBases ?? (st.ivaSobreUtilidad === false
    ? ["DIRECTO", "ADMINISTRACION", "IMPREVISTOS", "UTILIDAD"]
    : ["UTILIDAD"]);
  let baseIva = 0;
  if (ivaBases.includes("DIRECTO")) baseIva += directo;
  if (ivaBases.includes("ADMINISTRACION")) baseIva += vAdmin;
  if (ivaBases.includes("IMPREVISTOS")) baseIva += vImp;
  if (ivaBases.includes("UTILIDAD")) baseIva += vUtil;
  const vIva = Math.round(baseIva * pct(st.iva) * 100) / 100;
  const IVA_LABEL: Record<string, string> = {
    DIRECTO: "costo directo", ADMINISTRACION: "administración",
    IMPREVISTOS: "imprevistos", UTILIDAD: "utilidad",
  };

  /* ---------------- INFORME (agrupado) ---------------- */
  const grupo = <T,>(arr: T[]) => arr;
  const byAction = (actions: string[]) => decs.filter((d) => actions.includes(d.action));

  const correcciones = byAction(["CORRIGIO_CANTIDAD"]).map((d) => ({
    fecha: d.createdAt, actor: d.actor, detalle: d.detail,
  }));
  const cambiosRegla = byAction(["CAMBIO_REGLA_MEDICION"]).map((d) => ({
    fecha: d.createdAt, actor: d.actor, detalle: d.detail,
  }));
  const cambiosActividad = byAction(["CAMBIO_Y_VALIDO_ACTIVIDAD", "ASIGNO_ACTIVIDAD"]).map((d) => ({
    fecha: d.createdAt, actor: d.actor, accion: d.action, detalle: d.detail,
  }));
  const rechazos = byAction(["RECHAZO_PROPUESTA", "RECHAZO_CANTIDAD", "RECHAZO_MASIVO", "RECHAZO_MASIVO_CANTIDADES"]).map((d) => ({
    fecha: d.createdAt, actor: d.actor, accion: d.action, detalle: d.detail,
  }));
  const exclusiones = byAction(["EXCLUYO_ELEMENTO", "REINCORPORO_ELEMENTO"]).map((d) => ({
    fecha: d.createdAt, actor: d.actor, accion: d.action, detalle: d.detail,
  }));
  const derivaciones = byAction(["DERIVO_ACTIVIDAD"]).map((d) => ({
    fecha: d.createdAt, actor: d.actor, detalle: d.detail,
  }));
  const manuales = byAction(["INGRESO_CANTIDAD_MANUAL"]).map((d) => ({
    fecha: d.createdAt, actor: d.actor, detalle: d.detail,
  }));
  const agrupaciones = byAction(["EJECUTO_AGRUPACION"]).map((d) => ({
    fecha: d.createdAt, actor: d.actor, detalle: d.detail,
  }));

  // Cantidades con observaciones relevantes
  const observadas = qtys
    .map((q) => {
      const ev = (q.evidence ?? {}) as Record<string, unknown>;
      const advertencias = (ev.advertencias as string[] | undefined) ?? [];
      const sinDato = (ev.elementosSinDato as number | undefined) ?? 0;
      const correccion = ev.correccionProfesional as Record<string, unknown> | undefined;
      const derivada = ev.derivadaDe as Record<string, unknown> | undefined;
      if (!advertencias.length && !sinDato && !correccion && !derivada && !q.note) return null;
      const act = q.activityId ? actMap.get(q.activityId) : null;
      return {
        actividad: act ? `${act.code} — ${act.name}` : q.label ?? "Sin actividad",
        cantidad: q.value, unidad: q.unit, estado: q.status,
        metodo: q.method, regla: q.rule,
        elementos: q.elementCount,
        origen: q.sourceId ? srcMap.get(q.sourceId)?.name ?? null : (ev.fuentes as string[] | undefined)?.join(" + ") ?? null,
        nota: q.note,
        advertencias, elementosSinDato: sinDato,
        correccion: correccion ?? null,
        derivada: derivada ?? null,
        validadaPor: q.validatedBy, validadaEn: q.validatedAt,
      };
    })
    .filter(Boolean);

  const resumenMetodos = new Map<string, { lineas: number; cantidad: number }>();
  for (const q of qtys) {
    if (q.status !== "VALIDADA") continue;
    const cur = resumenMetodos.get(q.method) ?? { lineas: 0, cantidad: 0 };
    cur.lineas++;
    cur.cantidad += q.value ?? 0;
    resumenMetodos.set(q.method, cur);
  }

  return NextResponse.json({
    proyecto: {
      codigo: project.code, nombre: project.name, cliente: project.client,
      ubicacion: project.location, descripcion: project.description,
    },
    empresa: project.company ?? {},
    ajustes: st,
    plantilla: {
      budgetTitle: "Presupuesto preliminar",
      budgetSubtitle: "Estructura de cantidades y valores de referencia — sin APU",
      budgetIntroduction: "El presente documento consolida las cantidades de obra validadas profesionalmente a partir de modelos BIM, hojas de cálculo y mediciones manuales.",
      budgetScope: "Los valores unitarios son referencias del catálogo maestro. Este documento no constituye un análisis de precios unitarios: no desagrega materiales, mano de obra, equipos ni desperdicios.",
      reportTitle: "Informe de trazabilidad de cantidades",
      reportSubtitle: "Evidencia BIM, reglas de medición y decisiones profesionales",
      reportIntroduction: "Este informe documenta cómo se obtuvieron las cantidades del proyecto y resume las decisiones profesionales que modificaron, rechazaron o complementaron la evidencia original.",
      reportScope: "BIMCost Quantity determina qué actividades participan, cuánto se mide y de dónde proviene cada cantidad. No realiza APU, programación ni modelado BIM.",
      sourcesTitle: "Fuentes utilizadas",
      decisionsTitle: "Decisiones con observaciones",
      observationsTitle: "Cantidades que requieren atención",
      footerText: "Documento generado con BIMCost Quantity.",
      preparedByLabel: "Elaboró",
      reviewedByLabel: "Revisó / Aprobó",
      showCompany: true,
      showPrices: true,
      showAIU: true,
      ...((st as { documents?: Record<string, unknown> }).documents ?? {}),
    },
    presupuesto: {
      capitulos: presupuesto,
      costoDirecto: Math.round(directo * 100) / 100,
      administracion: vAdmin, imprevistos: vImp, utilidad: vUtil, iva: vIva,
      total: Math.round((directo + vAdmin + vImp + vUtil + vIva) * 100) / 100,
      moneda: st.currency ?? "COP",
      porcentajes: {
        administracion: st.administracion ?? 0, imprevistos: st.imprevistos ?? 0,
        utilidad: st.utilidad ?? 0, iva: st.iva ?? 0,
      },
      ivaBaseTexto: ivaBases.map((b) => IVA_LABEL[b]).join(" + ") || "—",
      baseIva: Math.round(baseIva * 100) / 100,
    },
    informe: {
      resumen: {
        fuentes: src.length,
        fuentesIfc: src.filter((s) => s.kind === "IFC").length,
        elementos: els.length,
        elementosExcluidos: els.filter((e) => e.excluded).length,
        cantidadesTotales: qtys.length,
        cantidadesValidadas: qtys.filter((q) => q.status === "VALIDADA").length,
        cantidadesPropuestas: qtys.filter((q) => q.status === "PROPUESTA").length,
        cantidadesPendientes: qtys.filter((q) => q.status === "PENDIENTE").length,
        cantidadesRechazadas: qtys.filter((q) => q.status === "RECHAZADA").length,
        decisiones: decs.length,
        metodos: [...resumenMetodos.entries()].map(([metodo, v]) => ({ metodo, ...v })),
      },
      fuentes: src.map((s) => ({
        nombre: s.name, tipo: s.kind, disciplina: s.discipline,
        archivo: s.fileName, esquema: s.ifcSchema,
        elementos: (s.stats as { elementos?: number } | null)?.elementos ?? null,
        advertencias: (s.stats as { advertencias?: string[] } | null)?.advertencias ?? [],
      })),
      agrupaciones: grupo(agrupaciones),
      cambiosActividad, cambiosRegla, correcciones, derivaciones,
      rechazos, exclusiones, manuales,
      cantidadesObservadas: observadas,
    },
  });
}
