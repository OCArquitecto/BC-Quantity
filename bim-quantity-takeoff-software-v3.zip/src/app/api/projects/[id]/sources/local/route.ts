import { NextResponse } from "next/server";
import { promises as fs } from "node:fs";
import path from "node:path";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { sources, projects } from "@/db/schema";
import { parseIfc } from "@/lib/ifc/parser";
import { ensureCatalogSeeded } from "@/lib/catalog";
import { importParsedElements, addDecision, sha256, modelFingerprint, findDuplicateSource } from "@/lib/server";

/**
 * Importación de un IFC leyéndolo DIRECTAMENTE del disco.
 *
 * La usa BIMCost Desktop: el archivo no se sube por el navegador, así que
 * no queda limitado por la memoria de la pestaña y admite modelos grandes.
 * Solo se acepta cuando la aplicación corre en modo escritorio o local.
 */
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const isDesktop = process.env.BIMCOST_DESKTOP === "1";
  const isLocal = (process.env.DATABASE_URL ?? "").includes("127.0.0.1") || (process.env.DATABASE_URL ?? "").includes("localhost");
  if (!isDesktop && !isLocal) {
    return NextResponse.json({ error: "La lectura desde disco solo está disponible en BIMCost Desktop." }, { status: 403 });
  }

  const { id } = await ctx.params;
  const [project] = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
  if (!project) return NextResponse.json({ error: "Proyecto no encontrado" }, { status: 404 });
  await ensureCatalogSeeded();

  const body = await req.json();
  const filePath = String(body?.path ?? "").trim();
  const name = String(body?.name ?? "").trim();
  const discipline = String(body?.discipline ?? "").trim() || null;
  const actor = body?.actor ? String(body.actor) : null;
  const unitRaw = String(body?.unitScale ?? "auto").trim();

  if (!filePath) return NextResponse.json({ error: "Debe indicar la ruta del archivo." }, { status: 400 });
  if (!/\.(ifc|ifcxml|step)$/i.test(filePath)) {
    return NextResponse.json({ error: "El archivo debe tener extensión .ifc" }, { status: 400 });
  }

  let stat;
  try {
    stat = await fs.stat(filePath);
  } catch {
    return NextResponse.json({ error: `No se pudo abrir el archivo: ${filePath}` }, { status: 404 });
  }
  if (!stat.isFile()) return NextResponse.json({ error: "La ruta no corresponde a un archivo." }, { status: 400 });

  const UNITS: Record<string, { scale: number; label: string }> = {
    m: { scale: 1, label: "METROS" }, cm: { scale: 0.01, label: "CENTÍMETROS" },
    mm: { scale: 0.001, label: "MILÍMETROS" }, ft: { scale: 0.3048, label: "PIES" },
    in: { scale: 0.0254, label: "PULGADAS" },
  };
  const forced = UNITS[unitRaw];

  const text = await fs.readFile(filePath, "utf8");
  const fileName = path.basename(filePath);
  const model = parseIfc(text, fileName, forced ? { unitScale: forced.scale, unitLabel: forced.label } : undefined);

  if (model.elementCount === 0) {
    return NextResponse.json(
      { error: "El archivo no contiene elementos de construcción reconocibles.", warnings: model.warnings },
      { status: 422 }
    );
  }

  const contentHash = sha256(text);
  const modelHash = modelFingerprint(model.elements.map((e) => e.globalId));
  const dup = body?.allowDuplicate ? null : await findDuplicateSource(id, { contentHash, modelHash, fileName });
  if (dup) {
    return NextResponse.json({
      error: "FUENTE_DUPLICADA",
      duplicado: {
        mensaje: `Este proyecto ya incluye «${dup.name}» con el mismo contenido.`,
        consecuencia: "Importarlo otra vez duplicaría todas sus cantidades.",
        sugerencia: "Elimine la fuente anterior si se trata de una versión actualizada.",
        fuenteExistente: { id: dup.id, nombre: dup.name, archivo: dup.fileName, elementos: dup.elementos, importadaEl: dup.createdAt, motivo: dup.motivo },
      },
    }, { status: 409 });
  }

  const [source] = await db
    .insert(sources)
    .values({
      projectId: id, kind: "IFC", contentHash, modelHash,
      name: name || fileName.replace(/\.(ifc|ifcxml|step)$/i, ""),
      discipline, fileName, fileSize: stat.size,
      ifcSchema: model.schema, status: "ACTIVA",
      stats: {
        elementos: model.elementCount, entidades: model.entityCount,
        clases: model.classes, niveles: model.levels, materiales: model.materials,
        proyectoIfc: model.projectName, advertencias: model.warnings,
        unidad: model.lengthUnit, factorEscala: model.lengthScale,
        escalaOrigen: model.scaleSource, escalaCorregida: model.autoCorrected,
        extensionModelo: model.modelExtent, conGeometria: model.withGeometry,
        conCantidadesIfc: model.withIfcQuantities,
        rutaOrigen: filePath, lecturaDirecta: true,
      },
    })
    .returning();

  const inserted = await importParsedElements(id, source.id, model);
  await addDecision(id, "FUENTE", source.id, "IMPORTO_IFC", {
    archivo: fileName, ruta: filePath, esquema: model.schema,
    elementos: inserted, tamanoMB: Math.round((stat.size / 1048576) * 10) / 10,
    lecturaDirectaDeDisco: true,
  }, actor);

  return NextResponse.json({ source, elementos: inserted, advertencias: model.warnings });
}
