import { NextResponse } from "next/server";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { elements, groups, quantities, type MeasureConfig } from "@/db/schema";
import { measureElements, AREA_BASIS_LABEL, DIMENSION_LABEL } from "@/lib/engine";
import { toWorkElement } from "@/lib/server";

/**
 * Simula TODAS las reglas de medición posibles sobre el mismo conjunto de
 * elementos para que el profesional compruebe qué valor toma cada opción
 * antes de decidir. Verificar un elemento sirve para todo el grupo porque
 * se muestra la misma regla aplicada a cada uno.
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const quantityId = url.searchParams.get("quantityId");
  const groupId = url.searchParams.get("groupId");
  const method = url.searchParams.get("method") ?? "SUPERFICIE_GEOMETRICA";

  let ids: string[] = [];
  let unit = "";
  let current: MeasureConfig | null = null;

  if (quantityId) {
    const [q] = await db.select().from(quantities).where(eq(quantities.id, quantityId)).limit(1);
    if (!q) return NextResponse.json({ error: "Cantidad no encontrada" }, { status: 404 });
    ids = (q.elementIds as string[]) ?? [];
    unit = q.unit;
    current = (q.measureConfig as MeasureConfig | null) ?? null;
  } else if (groupId) {
    const [g] = await db.select().from(groups).where(eq(groups.id, groupId)).limit(1);
    if (!g) return NextResponse.json({ error: "Grupo no encontrado" }, { status: 404 });
    ids = (g.elementIds as string[]) ?? [];
  } else {
    return NextResponse.json({ error: "quantityId o groupId requerido" }, { status: 400 });
  }

  const rows = ids.length ? await db.select().from(elements).where(inArray(elements.id, ids)) : [];
  const work = rows.map(toWorkElement).filter((w) => !w.excluded);

  const variants: { key: string; label: string; config: MeasureConfig; value: number | null; medidos: number; sinDato: number; campos: string[] }[] = [];
  const push = (key: string, label: string, config: MeasureConfig, m: string) => {
    const r = measureElements(work, m, config);
    variants.push({
      key, label, config, value: r.value,
      medidos: r.measuredCount, sinDato: r.missing, campos: Object.keys(r.fields),
    });
  };

  if (method === "SUPERFICIE_GEOMETRICA") {
    for (const b of ["NETA", "UNA_CARA", "DOS_CARAS", "BRUTA", "PLANTA", "LATERAL", "SUPERFICIE_TOTAL"]) {
      push(b, AREA_BASIS_LABEL[b], { areaBasis: b as MeasureConfig["areaBasis"], factor: 1 }, method);
    }
  } else if (method === "DIMENSION") {
    for (const d of ["LARGO", "ALTO", "ANCHO", "ESPESOR", "PERIMETRO"]) {
      push(d, DIMENSION_LABEL[d], { dimension: d as MeasureConfig["dimension"], factor: 1 }, method);
    }
  } else if (method === "VOLUMEN_GEOMETRICO") {
    push("NETO", "Volumen neto", { volumeBasis: "NETO", factor: 1 }, method);
    push("BRUTO", "Volumen bruto", { volumeBasis: "BRUTO", factor: 1 }, method);
  } else {
    push("DEFAULT", "Conteo de elementos", { factor: 1 }, method);
  }

  /* --- desglose por elemento: qué dimensión tiene cada uno --- */
  const detalle = work.slice(0, 200).map((w) => {
    const d = w.dimensions ?? {};
    const src = (rows.find((r) => r.id === w.id)?.dimensionSources ?? {}) as Record<string, string>;
    return {
      id: w.id,
      nombre: w.name,
      clase: w.ifcClass,
      nivel: w.level,
      largo: d.length ?? null,
      ancho: d.width ?? null,
      alto: d.height ?? null,
      espesor: d.thickness ?? null,
      areaNeta: d.netArea ?? null,
      areaBruta: d.grossArea ?? null,
      superficie: d.surfaceArea ?? null,
      perimetro: d.perimeter ?? null,
      volumen: d.netVolume ?? d.volume ?? null,
      seccion: d.crossSectionArea ?? null,
      origenes: src,
    };
  });

  /* --- señales de alerta de escala --- */
  const alertas: string[] = [];
  const maxLen = Math.max(0, ...work.map((w) => Math.max(w.dimensions?.length ?? 0, w.dimensions?.height ?? 0)));
  const maxArea = Math.max(0, ...work.map((w) => w.dimensions?.netArea ?? w.dimensions?.area ?? 0));
  if (maxLen > 200) alertas.push(`Hay elementos de ${maxLen.toFixed(0)} m de longitud/altura: revise la unidad del modelo (¿milímetros interpretados como metros?).`);
  if (maxArea > 20000) alertas.push(`Hay áreas de ${maxArea.toFixed(0)} m² por elemento: la escala del modelo parece incorrecta.`);

  return NextResponse.json({
    unidad: unit,
    elementos: work.length,
    configuracionActual: current,
    variantes: variants,
    detalle,
    alertas,
  });
}
