import { Documentos } from "@/components/workspace/Documentos";

export default async function DocumentosPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <Documentos projectId={id} />;
}
