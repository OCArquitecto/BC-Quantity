import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Inter, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const plex = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-plex",
});

export const metadata: Metadata = {
  title: "BIMCost Quantity — Cómputo de cantidades con trazabilidad",
  description:
    "Sistema profesional de cómputo de cantidades de construcción a partir de IFC, Excel y medición manual. Evidencia → Propuesta → Decisión profesional → Cantidad validada.",
};

// Aplica el tema guardado antes del primer pintado (evita parpadeo).
const themeScript = `try{if(localStorage.getItem("bc-theme")==="lectura"){document.documentElement.setAttribute("data-theme","lectura")}}catch(e){}`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es" className={`${inter.variable} ${plex.variable}`}>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="bg-ink-900 font-sans text-slate-100 antialiased">{children}</body>
    </html>
  );
}
