/* ================================================================== */
/*  Parser IFC (ISO-10303-21 / STEP) — lectura de evidencia BIM        */
/*  · Entidades, tipos, materiales, niveles, capas, psets              */
/*  · Cantidades IFC (IfcElementQuantity)                              */
/*  · GEOMETRÍA REAL cuando el modelo no trae BaseQuantities           */
/*  · Conversión de unidades del proyecto (mm, cm, pulgadas…) a metros */
/* ================================================================== */

import {
  Box, IDENTITY, applyPoint, axisPlacement, compose, emptyGeometry, orientedBox,
  fanTriangles, meshVolume, polygonArea2D, polygonArea3D, polylineLength2D,
  polylineLength3D, clipPolygonByPlane, polygonAreaUV, toFaceUV, norm, cross, sub, dot,
  solidToolFromFaces, subtractToolFromPolygon,
  type GeometryResult, type Transform, type Vec3, type Plane, type FaceFrame, type SolidTool,
} from "./geometry";

export type StepArg =
  | string
  | number
  | null
  | StepArg[]
  | { ref: number }
  | { call: string; args: StepArg[] };

interface StepEntity {
  id: number;
  type: string;
  args: StepArg[];
}

export interface ParsedGeometry {
  kind: string;
  size: [number, number, number];
  center: [number, number, number];
  yaw: number;
  /** Cara principal real (ya recortada) para dibujar y medir con exactitud. */
  face?: {
    /** Contorno en coordenadas (u, v) de la cara, en metros. */
    outline: [number, number][];
    /** Huecos (vanos) en las mismas coordenadas. */
    holes: [number, number][][];
    /** Espesor del elemento perpendicular a la cara. */
    thickness: number;
    /** Origen y ejes de la cara en el mundo (para ubicarla en el visor). */
    origin: [number, number, number];
    uAxis: [number, number, number];
    vAxis: [number, number, number];
    nAxis: [number, number, number];
    /** ¿La cara fue recortada por un plano (p. ej. cubierta inclinada)? */
    clipped: boolean;
    /** Área real tras restar los sólidos de corte (manda en la medición). */
    exactArea?: number;
    /** Rango vertical (Z, mundo, m) de la cara YA recortada. */
    zRange?: [number, number];
  };
  /** Vanos detectados (IfcOpeningElement) con su tamaño real. */
  openings?: { width: number; height: number; area: number; name: string | null }[];
  /** Caja orientada a la pieza: longitud, canto y ancho reales. */
  oriented?: {
    size: [number, number, number];
    center: [number, number, number];
    axes: [[number, number, number], [number, number, number], [number, number, number]];
  };
}

export interface ParsedElement {
  globalId: string | null;
  ifcClass: string;
  name: string | null;
  objectType: string | null;
  description: string | null;
  tag: string | null;
  typeName: string | null;
  /** Interpretación constructiva sustentada (p. ej. RoofMaker → miembro lineal). */
  semanticType: string | null;
  material: string | null;
  level: string | null;
  layer: string | null;
  properties: Record<string, Record<string, string | number | boolean | null>>;
  quantities: Record<string, number>;
  dimensions: Record<string, number | null>;
  /** De dónde salió cada dimensión: "cantidad IFC" | "geometría" | "propiedad" */
  dimensionSources: Record<string, string>;
  geometry: ParsedGeometry | null;
}

export interface ParsedModel {
  schema: string;
  projectName: string | null;
  fileName: string | null;
  entityCount: number;
  elementCount: number;
  classes: Record<string, number>;
  levels: string[];
  materials: string[];
  warnings: string[];
  lengthUnit: string;
  lengthScale: number;
  scaleSource: string;
  autoCorrected: boolean;
  modelExtent: number;
  withGeometry: number;
  withIfcQuantities: number;
  elements: ParsedElement[];
}

/* ------------------------- STEP scanner --------------------------- */
function scanStatements(text: string): { id: number; type: string; body: string }[] {
  const out: { id: number; type: string; body: string }[] = [];
  const n = text.length;
  let i = 0;
  while (i < n) {
    if (text[i] === "#") {
      let j = i + 1;
      let idStr = "";
      while (j < n && /[0-9]/.test(text[j])) idStr += text[j++];
      if (!idStr) { i++; continue; }
      while (j < n && /\s/.test(text[j])) j++;
      if (text[j] !== "=") { i = j; continue; }
      j++;
      while (j < n && /\s/.test(text[j])) j++;
      let type = "";
      while (j < n && /[A-Za-z0-9_]/.test(text[j])) type += text[j++];
      while (j < n && /\s/.test(text[j])) j++;
      if (text[j] !== "(") { i = j; continue; }
      let depth = 0;
      let inStr = false;
      const start = j + 1;
      let k = j;
      for (; k < n; k++) {
        const c = text[k];
        if (inStr) {
          if (c === "'") { if (text[k + 1] === "'") k++; else inStr = false; }
          continue;
        }
        if (c === "'") inStr = true;
        else if (c === "(") depth++;
        else if (c === ")") { depth--; if (depth === 0) break; }
      }
      out.push({ id: parseInt(idStr, 10), type: type.toUpperCase(), body: text.slice(start, k) });
      i = k + 1;
    } else i++;
  }
  return out;
}

/* ---------------------- args recursive parser --------------------- */
function parseArgs(s: string): StepArg[] {
  const args: StepArg[] = [];
  const n = s.length;
  let i = 0;
  const skipWs = () => { while (i < n && (/\s/.test(s[i]) || s[i] === ",")) i++; };
  const skipWsInline = () => { while (i < n && /\s/.test(s[i])) i++; };

  function parseString(): string {
    let out = "";
    i++;
    while (i < n) {
      const c = s[i];
      if (c === "'") {
        if (s[i + 1] === "'") { out += "'"; i += 2; } else { i++; break; }
      } else { out += c; i++; }
    }
    return out;
  }

  function parseValue(): StepArg {
    skipWs();
    if (i >= n) return null;
    const c = s[i];
    if (c === "$" || c === "*") { i++; return null; }
    if (c === "'") return parseString();
    if (c === "#") {
      i++;
      let num = "";
      while (i < n && /[0-9]/.test(s[i])) num += s[i++];
      return { ref: parseInt(num, 10) };
    }
    if (c === "(") {
      i++;
      const list: StepArg[] = [];
      while (i < n && s[i] !== ")") { list.push(parseValue()); skipWs(); }
      i++;
      return list;
    }
    if (c === ".") {
      let e = "";
      while (i < n && /[A-Za-z0-9_.]/.test(s[i])) e += s[i++];
      return e;
    }
    let tok = "";
    while (i < n && /[A-Za-z0-9_+\-.]/.test(s[i]) && s[i] !== ",") tok += s[i++];
    skipWsInline();
    if (s[i] === "(" && /^[A-Za-z]/.test(tok)) {
      i++;
      const inner: StepArg[] = [];
      while (i < n && s[i] !== ")") { inner.push(parseValue()); skipWs(); }
      i++;
      return { call: tok.toUpperCase(), args: inner };
    }
    const num = Number(tok);
    if (tok !== "" && !isNaN(num)) return num;
    return tok === "" ? null : tok;
  }

  while (i < n) {
    args.push(parseValue());
    skipWs();
    if (s[i] === ",") i++;
  }
  return args;
}

/* --------------------------- helpers ------------------------------ */
function isRef(a: StepArg | undefined): a is { ref: number } {
  return !!a && typeof a === "object" && !Array.isArray(a) && "ref" in a;
}
function isCall(a: StepArg | undefined): a is { call: string; args: StepArg[] } {
  return !!a && typeof a === "object" && !Array.isArray(a) && "call" in a;
}
function asList(a: StepArg | undefined): StepArg[] { return Array.isArray(a) ? a : []; }
function asStr(a: StepArg | undefined): string | null { return typeof a === "string" ? a : null; }
function asNum(a: StepArg | undefined): number | null {
  return typeof a === "number" && isFinite(a) ? a : null;
}
function typedValue(a: StepArg | undefined): string | number | boolean | null {
  if (isCall(a)) {
    const v = a.args[0];
    if (typeof v === "number" || typeof v === "string") return v;
    return v === null ? null : String(v);
  }
  if (typeof a === "string") {
    if (a === ".T.") return true;
    if (a === ".F.") return false;
    return a.replace(/^\./, "").replace(/\.$/, "");
  }
  if (typeof a === "number") return a;
  return null;
}

const ELEMENT_CLASSES = new Set([
  "IFCWALL", "IFCWALLSTANDARDCASE", "IFCWALLELEMENTEDCASE", "IFCSLAB", "IFCSLABSTANDARDCASE",
  "IFCBEAM", "IFCBEAMSTANDARDCASE", "IFCCOLUMN", "IFCCOLUMNSTANDARDCASE",
  "IFCDOOR", "IFCDOORSTANDARDCASE", "IFCWINDOW", "IFCWINDOWSTANDARDCASE",
  "IFCSPACE", "IFCSTAIR", "IFCSTAIRFLIGHT", "IFCRAILING", "IFCROOF", "IFCRAMP", "IFCRAMPFLIGHT",
  "IFCCURTAINWALL", "IFCPLATE", "IFCMEMBER", "IFCFOOTING", "IFCPILE", "IFCCOVERING",
  "IFCPIPESEGMENT", "IFCPIPEFITTING", "IFCCABLESEGMENT", "IFCCABLECARRIERSEGMENT",
  "IFCDUCTSEGMENT", "IFCDUCTFITTING", "IFCFLOWSEGMENT", "IFCFLOWTERMINAL", "IFCFLOWFITTING",
  "IFCSANITARYTERMINAL", "IFCOUTLET", "IFCSWITCHINGDEVICE", "IFCLAMP", "IFCLIGHTFIXTURE",
  "IFCJUNCTIONBOX", "IFCELECTRICDISTRIBUTIONBOARD", "IFCELECTRICAPPLIANCE", "IFCVALVE",
  "IFCBUILDINGELEMENTPROXY", "IFCFURNISHINGELEMENT", "IFCFURNITURE", "IFCSYSTEMFURNITUREELEMENT",
  "IFCOPENINGELEMENT", "IFCREINFORCINGBAR", "IFCREINFORCINGMESH", "IFCCHIMNEY", "IFCSHADINGDEVICE",
]);

/* ------------------- normalización de nombres --------------------- */
function normKey(k: string): string {
  return k.toLowerCase().replace(/[\s_\-.]/g, "");
}

/** clave normalizada → { campo, dimensión física (1=long, 2=área, 3=vol) } */
const DIMENSION_MAP: Record<string, { field: string; pow: number }> = {
  length: { field: "length", pow: 1 },
  nominallength: { field: "length", pow: 1 },
  totallength: { field: "length", pow: 1 },
  width: { field: "width", pow: 1 },
  nominalwidth: { field: "width", pow: 1 },
  overallwidth: { field: "width", pow: 1 },
  height: { field: "height", pow: 1 },
  nominalheight: { field: "height", pow: 1 },
  overallheight: { field: "height", pow: 1 },
  depth: { field: "thickness", pow: 1 },
  thickness: { field: "thickness", pow: 1 },
  nominalthickness: { field: "thickness", pow: 1 },
  area: { field: "area", pow: 2 },
  netarea: { field: "netArea", pow: 2 },
  netsidearea: { field: "netArea", pow: 2 },
  grossarea: { field: "grossArea", pow: 2 },
  grosssidearea: { field: "grossArea", pow: 2 },
  netfloorarea: { field: "netArea", pow: 2 },
  grossfloorarea: { field: "grossArea", pow: 2 },
  netceilingarea: { field: "netArea", pow: 2 },
  grossceilingarea: { field: "grossArea", pow: 2 },
  outersurfacearea: { field: "surfaceArea", pow: 2 },
  grosssurfacearea: { field: "surfaceArea", pow: 2 },
  netsurfacearea: { field: "surfaceArea", pow: 2 },
  totalsurfacearea: { field: "surfaceArea", pow: 2 },
  crosssectionarea: { field: "crossSectionArea", pow: 2 },
  outerperimeter: { field: "perimeter", pow: 1 },
  perimeter: { field: "perimeter", pow: 1 },
  grossperimeter: { field: "perimeter", pow: 1 },
  volume: { field: "volume", pow: 3 },
  netvolume: { field: "netVolume", pow: 3 },
  grossvolume: { field: "volume", pow: 3 },
  count: { field: "count", pow: 0 },
};

const DIM_FIELDS = [
  "length", "width", "height", "thickness", "area", "grossArea", "netArea",
  "surfaceArea", "crossSectionArea", "perimeter", "volume", "netVolume", "count",
];

/* ================================================================== */
export interface ParseOptions {
  /** Factor manual a metros (1 = m, 0.001 = mm, 0.01 = cm, 0.3048 = pies). */
  unitScale?: number;
  unitLabel?: string;
}

export function parseIfc(text: string, fileName?: string, options?: ParseOptions): ParsedModel {
  const warnings: string[] = [];
  const schemaMatch = text.match(/FILE_SCHEMA\s*\(\s*\(\s*'([^']+)'/i);
  const schema = schemaMatch ? schemaMatch[1] : "DESCONOCIDO";
  const fileNameMatch = text.match(/FILE_NAME\s*\(\s*'([^']+)'/i);

  const stmts = scanStatements(text);
  const ents = new Map<number, StepEntity>();
  for (const st of stmts) ents.set(st.id, { id: st.id, type: st.type, args: parseArgs(st.body) });

  const E = (r: StepArg | undefined): StepEntity | null => (isRef(r) ? ents.get(r.ref) ?? null : null);

  /* ---------------- 1. UNIDADES DEL PROYECTO --------------------- */
  let lengthScale = 1;
  let lengthUnit = "METRE";
  const SI_PREFIX: Record<string, number> = {
    MILLI: 1e-3, CENTI: 1e-2, DECI: 1e-1, DECA: 10, HECTO: 100, KILO: 1000, MICRO: 1e-6,
  };
  for (const e of ents.values()) {
    if (e.type !== "IFCSIUNIT") continue;
    const unitType = asStr(e.args[1]) ?? "";
    if (!/LENGTHUNIT/i.test(unitType)) continue;
    const prefix = (asStr(e.args[2]) ?? "").replace(/\./g, "").toUpperCase();
    const name = (asStr(e.args[3]) ?? "").replace(/\./g, "").toUpperCase();
    lengthUnit = (prefix ? prefix + "_" : "") + (name || "METRE");
    lengthScale = SI_PREFIX[prefix] ?? 1;
  }
  for (const e of ents.values()) {
    if (e.type !== "IFCCONVERSIONBASEDUNIT") continue;
    const unitType = asStr(e.args[0]) ?? "";
    const dims = E(e.args[0]);
    void dims;
    const nm = (asStr(e.args[1]) ?? "").toUpperCase();
    if (!/LENGTH/i.test(unitType) && !/INCH|FOOT|FEET|YARD/i.test(nm)) continue;
    const factorEnt = E(e.args[2]);
    const f = factorEnt ? asNum(factorEnt.args[0]) : null;
    if (f && isFinite(f)) { lengthScale = f; lengthUnit = nm || "CONVERSION"; }
  }
  /* --- VERIFICACIÓN DE PLAUSIBILIDAD DE LA ESCALA -------------------
     Muchos exportadores declaran METRE pero escriben coordenadas en
     milímetros (o el archivo llega sin IFCUNITASSIGNMENT). Sin esta
     comprobación, un muro de 3 m se mediría como 3.000 m y las áreas
     saldrían multiplicadas por un millón.                              */
  let rawMax = 0;
  for (const e of ents.values()) {
    if (e.type === "IFCCARTESIANPOINT") {
      for (const v of asList(e.args[0])) {
        if (typeof v === "number") { const a = Math.abs(v); if (a > rawMax && a < 1e9) rawMax = a; }
      }
    } else if (e.type === "IFCRECTANGLEPROFILEDEF") {
      for (const i of [3, 4]) { const v = asNum(e.args[i]); if (v && Math.abs(v) > rawMax) rawMax = Math.abs(v); }
    } else if (e.type === "IFCEXTRUDEDAREASOLID") {
      const v = asNum(e.args[3]); if (v && Math.abs(v) > rawMax) rawMax = Math.abs(v);
    }
  }

  let scaleSource = lengthScale === 1 ? "declarada en el archivo (metros)" : `declarada en el archivo (${lengthUnit})`;
  let autoCorrected = false;

  if (rawMax > 0) {
    const extent = rawMax * lengthScale; // extensión del modelo en "metros" según la unidad declarada
    // Una edificación razonable mide entre 1 m y 2.000 m.
    const CANDIDATES: { factor: number; label: string }[] = [
      { factor: 1, label: "metros" },
      { factor: 0.001, label: "milímetros" },
      { factor: 0.01, label: "centímetros" },
      { factor: 0.3048, label: "pies" },
      { factor: 0.0254, label: "pulgadas" },
    ];
    if (extent > 2000 || extent < 0.4) {
      // Elegir el factor que sitúe el modelo en un rango constructivo creíble
      let best: { factor: number; label: string } | null = null;
      let bestScore = Infinity;
      for (const c of CANDIDATES) {
        const m = rawMax * c.factor;
        if (m < 1 || m > 2000) continue;
        const score = Math.abs(Math.log(m / 30)); // referencia: ~30 m de extensión típica
        if (score < bestScore) { bestScore = score; best = c; }
      }
      if (best && Math.abs(best.factor - lengthScale) > 1e-9) {
        warnings.push(
          `La unidad declarada en el archivo produce dimensiones inverosímiles (extensión del modelo ≈ ${extent.toExponential(2)} m). ` +
          `BIMCost interpretó el modelo en ${best.label} (factor ${best.factor}). Verifique un elemento en «Evidencia IFC»; ` +
          `si no coincide, reimporte el archivo indicando la unidad correcta.`
        );
        lengthScale = best.factor;
        lengthUnit = best.label.toUpperCase();
        scaleSource = `corregida automáticamente por verificación de plausibilidad (${best.label})`;
        autoCorrected = true;
      }
    }
  }

  // Override manual del profesional (tiene prioridad sobre todo lo anterior)
  if (options?.unitScale && isFinite(options.unitScale) && options.unitScale > 0) {
    lengthScale = options.unitScale;
    lengthUnit = options.unitLabel ?? `FACTOR ${options.unitScale}`;
    scaleSource = "indicada manualmente por el profesional al importar";
    autoCorrected = false;
  }

  const S1 = lengthScale;
  const S2 = lengthScale * lengthScale;
  const S3 = lengthScale * lengthScale * lengthScale;
  const modelExtent = rawMax * S1;

  /* ---------------- 2. ÍNDICES BÁSICOS --------------------------- */
  const storeys = new Map<number, string>();
  const typeNames = new Map<number, string>();
  for (const e of ents.values()) {
    if (e.type === "IFCBUILDINGSTOREY") storeys.set(e.id, asStr(e.args[2]) ?? `Nivel #${e.id}`);
    if (/TYPE$/.test(e.type) || e.type === "IFCTYPEPRODUCT" || e.type === "IFCTYPEOBJECT") {
      const nm = asStr(e.args[2]);
      if (nm) typeNames.set(e.id, nm);
    }
  }

  const propValues = new Map<number, { name: string; value: string | number | boolean | null }>();
  for (const e of ents.values()) {
    if (e.type === "IFCPROPERTYSINGLEVALUE") {
      propValues.set(e.id, { name: asStr(e.args[0]) ?? "Propiedad", value: typedValue(e.args[2]) });
    } else if (["IFCPROPERTYBOUNDEDVALUE", "IFCPROPERTYENUMERATEDVALUE", "IFCPROPERTYLISTVALUE"].includes(e.type)) {
      const vals = asList(e.args[2]).map(typedValue).filter((v) => v !== null);
      propValues.set(e.id, { name: asStr(e.args[0]) ?? "Propiedad", value: vals.join(", ") });
    }
  }

  const psets = new Map<number, { name: string; props: Record<string, string | number | boolean | null> }>();
  for (const e of ents.values()) {
    if (e.type !== "IFCPROPERTYSET") continue;
    const props: Record<string, string | number | boolean | null> = {};
    for (const r of asList(e.args[4])) {
      const pv = isRef(r) ? propValues.get(r.ref) : undefined;
      if (pv) props[pv.name] = pv.value;
    }
    psets.set(e.id, { name: asStr(e.args[2]) ?? "Pset", props });
  }

  const qAtoms = new Map<number, { name: string; value: number; pow: number }>();
  const QPOW: Record<string, number> = {
    IFCQUANTITYLENGTH: 1, IFCQUANTITYAREA: 2, IFCQUANTITYVOLUME: 3,
    IFCQUANTITYCOUNT: 0, IFCQUANTITYWEIGHT: 0, IFCQUANTITYTIME: 0,
  };
  for (const e of ents.values()) {
    const pow = QPOW[e.type];
    if (pow === undefined) continue;
    const value = asNum(e.args[3]);
    if (value !== null) qAtoms.set(e.id, { name: asStr(e.args[0]) ?? "Quantity", value, pow });
  }
  const qtos = new Map<number, Record<string, { value: number; pow: number }>>();
  for (const e of ents.values()) {
    if (e.type !== "IFCELEMENTQUANTITY") continue;
    const q: Record<string, { value: number; pow: number }> = {};
    for (const r of asList(e.args[5])) {
      const a = isRef(r) ? qAtoms.get(r.ref) : undefined;
      if (a) q[a.name] = { value: a.value, pow: a.pow };
    }
    qtos.set(e.id, q);
  }

  /* ---------------- 3. RELACIONES -------------------------------- */
  const typeOf = new Map<number, number>();
  const psetOf = new Map<number, number[]>();
  const materialOf = new Map<number, number>();
  const storeyOf = new Map<number, number>();
  /** elemento → vanos que lo perforan (IfcRelVoidsElement). */
  const voidsOf = new Map<number, number[]>();
  /** vano → elemento que lo rellena (puerta/ventana), si existe. */
  const fillsOf = new Map<number, number>();
  for (const e of ents.values()) {
    if (e.type === "IFCRELDEFINESBYTYPE" && isRef(e.args[5])) {
      for (const r of asList(e.args[4])) if (isRef(r)) typeOf.set(r.ref, e.args[5].ref);
    } else if (e.type === "IFCRELDEFINESBYPROPERTIES" && isRef(e.args[5])) {
      for (const r of asList(e.args[4])) {
        if (!isRef(r)) continue;
        const arr = psetOf.get(r.ref) ?? [];
        arr.push(e.args[5].ref);
        psetOf.set(r.ref, arr);
      }
    } else if (e.type === "IFCRELASSOCIATESMATERIAL" && isRef(e.args[5])) {
      for (const r of asList(e.args[4])) if (isRef(r)) materialOf.set(r.ref, e.args[5].ref);
    } else if (e.type === "IFCRELCONTAINEDINSPATIALSTRUCTURE" && isRef(e.args[5])) {
      for (const r of asList(e.args[4])) if (isRef(r)) storeyOf.set(r.ref, e.args[5].ref);
    } else if (e.type === "IFCRELVOIDSELEMENT" && isRef(e.args[4]) && isRef(e.args[5])) {
      const host = e.args[4].ref;
      const arr = voidsOf.get(host) ?? [];
      arr.push(e.args[5].ref);
      voidsOf.set(host, arr);
    } else if (e.type === "IFCRELFILLSELEMENT" && isRef(e.args[4]) && isRef(e.args[5])) {
      fillsOf.set(e.args[4].ref, e.args[5].ref);
    }
  }

  function materialName(id: number, depth = 0): string | null {
    if (depth > 5) return null;
    const e = ents.get(id);
    if (!e) return null;
    switch (e.type) {
      case "IFCMATERIAL": return asStr(e.args[0]);
      case "IFCMATERIALLAYER": {
        const m = isRef(e.args[0]) ? materialName(e.args[0].ref, depth + 1) : null;
        const t = asNum(e.args[1]);
        return m ? (t ? `${m} (${(t * S1).toFixed(3)} m)` : m) : null;
      }
      case "IFCMATERIALLAYERSET": {
        const parts = asList(e.args[0]).map((r) => (isRef(r) ? materialName(r.ref, depth + 1) : null)).filter(Boolean);
        return parts.length ? parts.join(" / ") : asStr(e.args[1]);
      }
      case "IFCMATERIALLAYERSETUSAGE":
        return isRef(e.args[0]) ? materialName(e.args[0].ref, depth + 1) : null;
      case "IFCMATERIALCONSTITUENTSET": {
        const parts = asList(e.args[2]).map((r) => (isRef(r) ? materialName(r.ref, depth + 1) : null)).filter(Boolean);
        return parts.length ? parts.join(" / ") : null;
      }
      case "IFCMATERIALCONSTITUENT":
        return isRef(e.args[2]) ? materialName(e.args[2].ref, depth + 1) : asStr(e.args[0]);
      case "IFCMATERIALPROFILESET": {
        const parts = asList(e.args[2]).map((r) => (isRef(r) ? materialName(r.ref, depth + 1) : null)).filter(Boolean);
        return parts.length ? parts.join(" / ") : asStr(e.args[0]);
      }
      case "IFCMATERIALPROFILE":
        return isRef(e.args[2]) ? materialName(e.args[2].ref, depth + 1) : asStr(e.args[0]);
      case "IFCMATERIALPROFILESETUSAGE":
        return isRef(e.args[0]) ? materialName(e.args[0].ref, depth + 1) : null;
      case "IFCMATERIALLIST": {
        const parts = asList(e.args[0]).map((r) => (isRef(r) ? materialName(r.ref, depth + 1) : null)).filter(Boolean);
        return parts.length ? parts.join(" / ") : null;
      }
      default: return asStr(e.args[0]);
    }
  }

  const repToLayer = new Map<number, string>();
  for (const e of ents.values()) {
    if (e.type !== "IFCPRESENTATIONLAYERASSIGNMENT") continue;
    const name = asStr(e.args[0]);
    if (!name) continue;
    for (const r of asList(e.args[2])) if (isRef(r)) repToLayer.set(r.ref, name);
  }

  /* ---------------- 4. PLACEMENTS -------------------------------- */
  const placeCache = new Map<number, Transform>();

  function point3(r: StepArg | undefined): Vec3 | null {
    const e = E(r);
    if (!e || e.type !== "IFCCARTESIANPOINT") return null;
    const c = asList(e.args[0]).map((v) => (typeof v === "number" ? v : 0));
    return { x: c[0] ?? 0, y: c[1] ?? 0, z: c[2] ?? 0 };
  }
  function dir3(r: StepArg | undefined): Vec3 | null {
    const e = E(r);
    if (!e || e.type !== "IFCDIRECTION") return null;
    const c = asList(e.args[0]).map((v) => (typeof v === "number" ? v : 0));
    return { x: c[0] ?? 0, y: c[1] ?? 0, z: c[2] ?? 0 };
  }

  function axis2placement(r: StepArg | undefined): Transform {
    const e = E(r);
    if (!e) return IDENTITY;
    if (e.type === "IFCAXIS2PLACEMENT3D") {
      return axisPlacement(point3(e.args[0]) ?? { x: 0, y: 0, z: 0 }, dir3(e.args[1]), dir3(e.args[2]));
    }
    if (e.type === "IFCAXIS2PLACEMENT2D") {
      const p = point3(e.args[0]) ?? { x: 0, y: 0, z: 0 };
      const d = dir3(e.args[1]);
      return axisPlacement(p, { x: 0, y: 0, z: 1 }, d ? { x: d.x, y: d.y, z: 0 } : null);
    }
    return IDENTITY;
  }

  function localPlacement(id: number, depth = 0): Transform {
    if (depth > 30) return IDENTITY;
    const cached = placeCache.get(id);
    if (cached) return cached;
    const e = ents.get(id);
    if (!e || e.type !== "IFCLOCALPLACEMENT") return IDENTITY;
    const rel = axis2placement(e.args[1]);
    const parent = isRef(e.args[0]) ? localPlacement(e.args[0].ref, depth + 1) : IDENTITY;
    const t = compose(parent, rel);
    placeCache.set(id, t);
    return t;
  }

  /* ---------------- 5. GEOMETRÍA --------------------------------- */
  interface FaceCandidate {
    /** Polígono de la cara en coordenadas del mundo. */
    poly: Vec3[];
    /** Espesor perpendicular a la cara. */
    thickness: number;
    /** Dirección normal (hacia el espesor). */
    normal: Vec3;
  }

  interface GeoAcc {
    box: Box;
    profileArea: number | null;
    profilePerimeter: number | null;
    sweepLength: number | null;
    volume: number;
    meshArea: number;
    axisLength: number | null;
    kinds: Set<string>;
    /** Caras candidatas (la mayor se usa como cara principal del elemento). */
    faces: FaceCandidate[];
    /** Planos de recorte procedentes de operaciones booleanas. */
    clips: Plane[];
    /** Sólidos restados (Archicad corta los muros con un B-Rep). */
    tools: SolidTool[];
    /** Vértices reales del sólido para calcular su caja orientada (OBB). */
    points: Vec3[];
  }

  function addGeoPoint(acc: GeoAcc, p: Vec3) {
    acc.box.add(p);
    acc.points.push(p);
  }

  /** Caras (en coordenadas de mundo) de un sólido usado como herramienta. */
  function solidFaces(ref: StepArg | undefined, t: Transform, depth = 0): Vec3[][] {
    const e = E(ref);
    if (!e || depth > 6) return [];
    const out: Vec3[][] = [];
    const pushShell = (shellRef: StepArg | undefined) => {
      const shell = E(shellRef);
      if (!shell) return;
      for (const f of asList(shell.args[0])) {
        const face = E(f);
        if (!face) continue;
        for (const b of asList(face.args[0])) {
          const bound = E(b);
          const loop = bound ? E(bound.args[0]) : null;
          if (!loop || loop.type !== "IFCPOLYLOOP") continue;
          const pts = asList(loop.args[0]).map((p) => applyPoint(t, point3(p) ?? { x: 0, y: 0, z: 0 }));
          if (pts.length >= 3) out.push(pts);
        }
      }
    };
    switch (e.type) {
      case "IFCFACETEDBREP":
      case "IFCFACETEDBREPWITHVOIDS":
      case "IFCADVANCEDBREP":
        pushShell(e.args[0]);
        break;
      case "IFCSHELLBASEDSURFACEMODEL":
      case "IFCFACEBASEDSURFACEMODEL":
        for (const sh of asList(e.args[0])) pushShell(sh);
        break;
      case "IFCEXTRUDEDAREASOLID": {
        const prof = profileOf(e.args[0]);
        const pos = axis2placement(e.args[1]);
        const dirV = dir3(e.args[2]) ?? { x: 0, y: 0, z: 1 };
        const dep = asNum(e.args[3]) ?? 0;
        if (prof && !prof.box.empty) {
          const local = compose(t, pos);
          // Usar el CONTORNO REAL del perfil (no la caja envolvente): las
          // herramientas de corte de cubierta (a un agua, a dos aguas, con
          // aleros) casi nunca son rectangulares en planta. Aproximar con
          // la caja envolvente pierde el borde inclinado y el recorte
          // resultante no reproduce el corte real del muro.
          const corners = prof.points.length >= 3 ? prof.points : [
            { x: prof.box.min.x, y: prof.box.min.y },
            { x: prof.box.max.x, y: prof.box.min.y },
            { x: prof.box.max.x, y: prof.box.max.y },
            { x: prof.box.min.x, y: prof.box.max.y },
          ];
          const n = corners.length;
          const bottom = corners.map((c) => applyPoint(local, { x: c.x, y: c.y, z: 0 }));
          const top = corners.map((c) => applyPoint(local, {
            x: c.x + dirV.x * dep, y: c.y + dirV.y * dep, z: dirV.z * dep,
          }));
          out.push(bottom, [...top].reverse());
          for (let i = 0; i < n; i++) {
            const j = (i + 1) % n;
            out.push([bottom[i], bottom[j], top[j], top[i]]);
          }
        }
        break;
      }
      case "IFCBOOLEANRESULT":
      case "IFCBOOLEANCLIPPINGRESULT":
        return solidFaces(e.args[1], t, depth + 1);
      default:
        break;
    }
    return out;
  }

  /**
   * Devuelve, además del área/perímetro, el CONTORNO REAL del perfil en 2D
   * (`points`), en el orden en que definen el polígono. Es indispensable
   * para no perder la forma real (losas irregulares, cubiertas, herramientas
   * de corte no rectangulares): usar solo la caja envolvente (`box`) convierte
   * cualquier forma en un rectángulo.
   */
  function profileOf(
    r: StepArg | undefined
  ): { area: number | null; perimeter: number | null; box: Box; points: { x: number; y: number }[] } | null {
    const e = E(r);
    if (!e) return null;
    const box = new Box();
    const add2 = (x: number, y: number) => box.add({ x, y, z: 0 });

    switch (e.type) {
      case "IFCRECTANGLEPROFILEDEF":
      case "IFCROUNDEDRECTANGLEPROFILEDEF": {
        const xd = asNum(e.args[3]) ?? 0;
        const yd = asNum(e.args[4]) ?? 0;
        add2(-xd / 2, -yd / 2); add2(xd / 2, yd / 2);
        const points = [
          { x: -xd / 2, y: -yd / 2 }, { x: xd / 2, y: -yd / 2 },
          { x: xd / 2, y: yd / 2 }, { x: -xd / 2, y: yd / 2 },
        ];
        return { area: xd * yd, perimeter: 2 * (xd + yd), box, points };
      }
      case "IFCRECTANGLEHOLLOWPROFILEDEF": {
        const xd = asNum(e.args[3]) ?? 0;
        const yd = asNum(e.args[4]) ?? 0;
        const t = asNum(e.args[5]) ?? 0;
        add2(-xd / 2, -yd / 2); add2(xd / 2, yd / 2);
        const inner = Math.max(0, (xd - 2 * t) * (yd - 2 * t));
        const points = [
          { x: -xd / 2, y: -yd / 2 }, { x: xd / 2, y: -yd / 2 },
          { x: xd / 2, y: yd / 2 }, { x: -xd / 2, y: yd / 2 },
        ];
        return { area: xd * yd - inner, perimeter: 2 * (xd + yd), box, points };
      }
      case "IFCCIRCLEPROFILEDEF": {
        const rr = asNum(e.args[3]) ?? 0;
        add2(-rr, -rr); add2(rr, rr);
        const points = circlePoints(rr);
        return { area: Math.PI * rr * rr, perimeter: 2 * Math.PI * rr, box, points };
      }
      case "IFCCIRCLEHOLLOWPROFILEDEF": {
        const rr = asNum(e.args[3]) ?? 0;
        const t = asNum(e.args[4]) ?? 0;
        add2(-rr, -rr); add2(rr, rr);
        const ri = Math.max(0, rr - t);
        const points = circlePoints(rr);
        return { area: Math.PI * (rr * rr - ri * ri), perimeter: 2 * Math.PI * rr, box, points };
      }
      case "IFCISHAPEPROFILEDEF": {
        const w = asNum(e.args[3]) ?? 0;
        const h = asNum(e.args[4]) ?? 0;
        const tw = asNum(e.args[5]) ?? 0;
        const tf = asNum(e.args[6]) ?? 0;
        add2(-w / 2, -h / 2); add2(w / 2, h / 2);
        const area = 2 * w * tf + Math.max(0, h - 2 * tf) * tw;
        const points = [
          { x: -w / 2, y: -h / 2 }, { x: w / 2, y: -h / 2 },
          { x: w / 2, y: h / 2 }, { x: -w / 2, y: h / 2 },
        ];
        return { area: area || null, perimeter: 2 * (w + h), box, points };
      }
      case "IFCARBITRARYCLOSEDPROFILEDEF":
      case "IFCARBITRARYPROFILEDEFWITHVOIDS": {
        const outer = curvePoints2D(e.args[2]);
        if (!outer.length) return null;
        for (const p of outer) add2(p.x, p.y);
        let area = polygonArea2D(outer);
        if (e.type === "IFCARBITRARYPROFILEDEFWITHVOIDS") {
          for (const v of asList(e.args[3])) {
            const hole = curvePoints2D(v);
            if (hole.length > 2) area -= polygonArea2D(hole);
          }
        }
        return { area: Math.max(0, area), perimeter: polylineLength2D(outer, true), box, points: outer };
      }
      case "IFCDERIVEDPROFILEDEF":
        return profileOf(e.args[2]);
      case "IFCCOMPOSITEPROFILEDEF": {
        let area = 0;
        let per = 0;
        for (const p of asList(e.args[2])) {
          const sub = profileOf(p);
          if (sub) {
            area += sub.area ?? 0;
            per += sub.perimeter ?? 0;
            if (!sub.box.empty) { box.add(sub.box.min); box.add(sub.box.max); }
          }
        }
        // Varios perfiles a la vez no forman un único contorno simple:
        // se conserva el área/perímetro exactos, pero sin polígono de dibujo.
        return { area: area || null, perimeter: per || null, box, points: [] };
      }
      default: {
        // Perfiles no soportados: intentar curva exterior genérica
        const pts = curvePoints2D(e.args[2]);
        if (pts.length > 2) {
          for (const p of pts) add2(p.x, p.y);
          return { area: polygonArea2D(pts), perimeter: polylineLength2D(pts, true), box, points: pts };
        }
        return null;
      }
    }
  }

  /** Aproxima un círculo por un polígono regular (suficiente para recortes y dibujo). */
  function circlePoints(radius: number, segments = 32): { x: number; y: number }[] {
    const pts: { x: number; y: number }[] = [];
    for (let i = 0; i < segments; i++) {
      const a = (i / segments) * Math.PI * 2;
      pts.push({ x: radius * Math.cos(a), y: radius * Math.sin(a) });
    }
    return pts;
  }

  function curvePoints2D(r: StepArg | undefined): { x: number; y: number }[] {
    const e = E(r);
    if (!e) return [];
    if (e.type === "IFCPOLYLINE") {
      return asList(e.args[0]).map((p) => {
        const pe = E(p);
        const c = pe ? asList(pe.args[0]).map((v) => (typeof v === "number" ? v : 0)) : [];
        return { x: c[0] ?? 0, y: c[1] ?? 0 };
      });
    }
    if (e.type === "IFCINDEXEDPOLYCURVE") {
      const pl = E(e.args[0]);
      if (pl && (pl.type === "IFCCARTESIANPOINTLIST2D" || pl.type === "IFCCARTESIANPOINTLIST3D")) {
        return asList(pl.args[0]).map((row) => {
          const c = asList(row).map((v) => (typeof v === "number" ? v : 0));
          return { x: c[0] ?? 0, y: c[1] ?? 0 };
        });
      }
    }
    if (e.type === "IFCCOMPOSITECURVE") {
      const out: { x: number; y: number }[] = [];
      for (const seg of asList(e.args[0])) {
        const se = E(seg);
        if (se) out.push(...curvePoints2D(se.args[2]));
      }
      return out;
    }
    if (e.type === "IFCTRIMMEDCURVE") return curvePoints2D(e.args[0]);
    return [];
  }

  function curvePoints3D(r: StepArg | undefined): Vec3[] {
    const e = E(r);
    if (!e) return [];
    if (e.type === "IFCPOLYLINE") {
      return asList(e.args[0]).map((p) => point3(p) ?? { x: 0, y: 0, z: 0 });
    }
    if (e.type === "IFCINDEXEDPOLYCURVE") {
      const pl = E(e.args[0]);
      if (pl) {
        return asList(pl.args[0]).map((row) => {
          const c = asList(row).map((v) => (typeof v === "number" ? v : 0));
          return { x: c[0] ?? 0, y: c[1] ?? 0, z: c[2] ?? 0 };
        });
      }
    }
    if (e.type === "IFCCOMPOSITECURVE") {
      const out: Vec3[] = [];
      for (const seg of asList(e.args[0])) {
        const se = E(seg);
        if (se) out.push(...curvePoints3D(se.args[2]));
      }
      return out;
    }
    if (e.type === "IFCTRIMMEDCURVE") return curvePoints3D(e.args[0]);
    return [];
  }

  function processItem(r: StepArg | undefined, t: Transform, acc: GeoAcc, depth = 0) {
    if (depth > 12) return;
    const e = E(r);
    if (!e) return;

    switch (e.type) {
      case "IFCEXTRUDEDAREASOLID":
      case "IFCEXTRUDEDAREASOLIDTAPERED": {
        const prof = profileOf(e.args[0]);
        const pos = axis2placement(e.args[1]);
        const dirV = dir3(e.args[2]) ?? { x: 0, y: 0, z: 1 };
        const depthV = asNum(e.args[3]) ?? 0;
        const local = compose(t, pos);
        if (prof && !prof.box.empty) {
          const z0 = 0;
          const z1 = depthV;
          for (const zz of [z0, z1]) {
            for (const cx of [prof.box.min.x, prof.box.max.x]) {
              for (const cy of [prof.box.min.y, prof.box.max.y]) {
                const p = applyPoint(local, {
                  x: cx + dirV.x * zz,
                  y: cy + dirV.y * zz,
                  z: dirV.z * zz,
                });
                addGeoPoint(acc, p);
              }
            }
          }
          if (prof.area !== null) {
            acc.profileArea = Math.max(acc.profileArea ?? 0, prof.area);
            acc.volume += prof.area * Math.abs(depthV);
          }
          if (prof.perimeter !== null) acc.profilePerimeter = Math.max(acc.profilePerimeter ?? 0, prof.perimeter);
        }
        acc.sweepLength = Math.max(acc.sweepLength ?? 0, Math.abs(depthV));
        acc.kinds.add("extrusión");

        /* --- cara principal real del sólido extruido ---------------
           Para un muro (perfil largo × espesor, extruido en altura) la
           cara relevante es el paño: largo × altura. Para una losa o
           cubierta, la cara relevante es la propia planta del perfil.
           Se registran como polígonos en coordenadas del mundo para
           poder recortarlos con los planos/sólidos de corte.
           IMPORTANTE: la planta (Cara C) usa el CONTORNO REAL del perfil
           (prof.points), no su caja envolvente — de lo contrario una losa
           en forma de L o con un borde curvo se mide como un rectángulo. */
        if (prof && !prof.box.empty && Math.abs(depthV) > 1e-6) {
          const pw = prof.box.max.x - prof.box.min.x;
          const ph = prof.box.max.y - prof.box.min.y;
          const cxm = (prof.box.min.x + prof.box.max.x) / 2;
          const cym = (prof.box.min.y + prof.box.max.y) / 2;
          const ext = { x: dirV.x * depthV, y: dirV.y * depthV, z: dirV.z * depthV };

          // Cara A: perfil ancho (x) × extrusión, a media profundidad (y)
          const faceA: Vec3[] = [
            applyPoint(local, { x: prof.box.min.x, y: cym, z: 0 }),
            applyPoint(local, { x: prof.box.max.x, y: cym, z: 0 }),
            applyPoint(local, { x: prof.box.max.x + ext.x, y: cym + ext.y, z: ext.z }),
            applyPoint(local, { x: prof.box.min.x + ext.x, y: cym + ext.y, z: ext.z }),
          ];
          // Cara B: perfil profundo (y) × extrusión, a media anchura (x)
          const faceB: Vec3[] = [
            applyPoint(local, { x: cxm, y: prof.box.min.y, z: 0 }),
            applyPoint(local, { x: cxm, y: prof.box.max.y, z: 0 }),
            applyPoint(local, { x: cxm + ext.x, y: prof.box.max.y + ext.y, z: ext.z }),
            applyPoint(local, { x: cxm + ext.x, y: prof.box.min.y + ext.y, z: ext.z }),
          ];
          // Cara C: el propio perfil, con su contorno real (planta de
          // losas, forjados, cubiertas y cimentaciones).
          const profilePts = prof.points.length >= 3 ? prof.points : [
            { x: prof.box.min.x, y: prof.box.min.y }, { x: prof.box.max.x, y: prof.box.min.y },
            { x: prof.box.max.x, y: prof.box.max.y }, { x: prof.box.min.x, y: prof.box.max.y },
          ];
          const faceC: Vec3[] = profilePts.map((p) => applyPoint(local, { x: p.x, y: p.y, z: 0 }));
          const d = Math.abs(depthV);
          acc.faces.push({ poly: faceA, thickness: ph, normal: norm(sub(faceB[1], faceB[0])) });
          acc.faces.push({ poly: faceB, thickness: pw, normal: norm(sub(faceA[1], faceA[0])) });
          acc.faces.push({ poly: faceC, thickness: d, normal: norm(ext) });
        }
        break;
      }
      case "IFCBOUNDINGBOX": {
        const c = point3(e.args[0]) ?? { x: 0, y: 0, z: 0 };
        const xd = asNum(e.args[1]) ?? 0;
        const yd = asNum(e.args[2]) ?? 0;
        const zd = asNum(e.args[3]) ?? 0;
        for (const dx of [0, xd]) for (const dy of [0, yd]) for (const dz of [0, zd]) {
          addGeoPoint(acc, applyPoint(t, { x: c.x + dx, y: c.y + dy, z: c.z + dz }));
        }
        acc.kinds.add("caja envolvente");
        break;
      }
      case "IFCFACETEDBREP":
      case "IFCADVANCEDBREP":
      case "IFCFACETEDBREPWITHVOIDS": {
        const shell = E(e.args[0]);
        if (!shell) break;
        const tris: [Vec3, Vec3, Vec3][] = [];
        for (const f of asList(shell.args[0])) {
          const face = E(f);
          if (!face) continue;
          for (const b of asList(face.args[0])) {
            const bound = E(b);
            if (!bound) continue;
            const loop = E(bound.args[0]);
            if (!loop || loop.type !== "IFCPOLYLOOP") continue;
            const pts = asList(loop.args[0]).map((p) => applyPoint(t, point3(p) ?? { x: 0, y: 0, z: 0 }));
            if (pts.length < 3) continue;
            for (const p of pts) addGeoPoint(acc, p);
            acc.meshArea += polygonArea3D(pts);
            if (pts.length >= 3) {
              acc.faces.push({
                poly: pts,
                thickness: 0,
                normal: norm(cross(sub(pts[1], pts[0]), sub(pts[2], pts[0]))),
              });
            }
            tris.push(...fanTriangles(pts));
          }
        }
        if (tris.length) acc.volume += meshVolume(tris);
        acc.kinds.add("malla B-Rep");
        break;
      }
      case "IFCTRIANGULATEDFACESET": {
        const cl = E(e.args[0]);
        if (!cl) break;
        const coords = asList(cl.args[0]).map((row) => {
          const c = asList(row).map((v) => (typeof v === "number" ? v : 0));
          return applyPoint(t, { x: c[0] ?? 0, y: c[1] ?? 0, z: c[2] ?? 0 });
        });
        for (const p of coords) addGeoPoint(acc, p);
        const idx = asList(e.args[3]);
        const tris: [Vec3, Vec3, Vec3][] = [];
        for (const row of idx) {
          const ix = asList(row).map((v) => (typeof v === "number" ? v : 0));
          const a = coords[ix[0] - 1], b = coords[ix[1] - 1], c = coords[ix[2] - 1];
          if (a && b && c) { tris.push([a, b, c]); acc.meshArea += polygonArea3D([a, b, c]); }
        }
        if (tris.length) acc.volume += meshVolume(tris);
        acc.kinds.add("malla triangulada");
        break;
      }
      case "IFCPOLYGONALFACESET": {
        const cl = E(e.args[0]);
        if (!cl) break;
        const coords = asList(cl.args[0]).map((row) => {
          const c = asList(row).map((v) => (typeof v === "number" ? v : 0));
          return applyPoint(t, { x: c[0] ?? 0, y: c[1] ?? 0, z: c[2] ?? 0 });
        });
        for (const p of coords) addGeoPoint(acc, p);
        const tris: [Vec3, Vec3, Vec3][] = [];
        for (const f of asList(e.args[2])) {
          const face = E(f);
          if (!face) continue;
          const ix = asList(face.args[0]).map((v) => (typeof v === "number" ? v : 0));
          const pts = ix.map((i2) => coords[i2 - 1]).filter(Boolean);
          if (pts.length >= 3) { acc.meshArea += polygonArea3D(pts); tris.push(...fanTriangles(pts)); }
        }
        if (tris.length) acc.volume += meshVolume(tris);
        acc.kinds.add("malla poligonal");
        break;
      }
      case "IFCSWEPTDISKSOLID": {
        const pts = curvePoints3D(e.args[0]).map((p) => applyPoint(t, p));
        const rr = asNum(e.args[1]) ?? 0;
        const len = polylineLength3D(pts);
        for (const p of pts) addGeoPoint(acc, p);
        acc.sweepLength = Math.max(acc.sweepLength ?? 0, len);
        acc.axisLength = Math.max(acc.axisLength ?? 0, len);
        acc.profileArea = Math.max(acc.profileArea ?? 0, Math.PI * rr * rr);
        acc.volume += Math.PI * rr * rr * len;
        acc.kinds.add("barrido de disco");
        break;
      }
      case "IFCSURFACECURVESWEPTAREASOLID":
      case "IFCFIXEDREFERENCESWEPTAREASOLID": {
        const prof = profileOf(e.args[0]);
        const pts = curvePoints3D(e.args[2]).map((p) => applyPoint(t, p));
        const len = polylineLength3D(pts);
        for (const p of pts) addGeoPoint(acc, p);
        if (prof?.area) { acc.profileArea = Math.max(acc.profileArea ?? 0, prof.area); acc.volume += prof.area * len; }
        acc.sweepLength = Math.max(acc.sweepLength ?? 0, len);
        acc.kinds.add("barrido de perfil");
        break;
      }
      case "IFCBOOLEANCLIPPINGRESULT":
      case "IFCBOOLEANRESULT": {
        const op = (asStr(e.args[0]) ?? "").replace(/\./g, "").toUpperCase();
        // Primer operando: el sólido base
        processItem(e.args[1], t, acc, depth + 1);
        // Segundo operando: la herramienta de corte (plano de cubierta, etc.)
        const tool = E(e.args[2]);
        if (tool && op === "DIFFERENCE") {
          if (tool.type === "IFCHALFSPACESOLID" || tool.type === "IFCPOLYGONALBOUNDEDHALFSPACE") {
            const surf = E(tool.args[0]);
            const flagStr = (asStr(tool.args[1]) ?? "").replace(/\./g, "").toUpperCase();
            const agreement = flagStr === "T" || flagStr === "TRUE";
            if (surf && surf.type === "IFCPLANE") {
              const pl = axis2placement(surf.args[0]);
              let base = compose(t, pl);
              if (tool.type === "IFCPOLYGONALBOUNDEDHALFSPACE") {
                const pos = axis2placement(tool.args[2]);
                base = compose(compose(t, pos), pl);
              }
              // El material eliminado está del lado +Z del plano cuando AgreementFlag=TRUE
              acc.clips.push({
                p: base.o,
                n: agreement ? base.z : { x: -base.z.x, y: -base.z.y, z: -base.z.z },
              });
              acc.kinds.add("recorte por plano");
            }
          } else {
            /* Herramienta SÓLIDA: Archicad recorta los muros bajo cubierta
               restando un B-Rep. Se extraen sus caras para poder calcular
               el área realmente construida, sin dibujar el sólido. */
            const toolFaces = solidFaces(e.args[2], t);
            const tool = solidToolFromFaces(toolFaces);
            if (tool) {
              acc.tools.push(tool);
              acc.kinds.add("recorte por sólido");
            } else {
              acc.kinds.add("diferencia booleana");
            }
          }
        }
        break;
      }
      case "IFCMAPPEDITEM": {
        const src = E(e.args[0]);
        if (!src) break;
        const origin = axis2placement(src.args[0]);
        const target = E(e.args[1]);
        let tt = compose(t, origin);
        if (target && target.type === "IFCCARTESIANTRANSFORMATIONOPERATOR3D") {
          const loc = point3(target.args[2]) ?? { x: 0, y: 0, z: 0 };
          tt = compose(tt, axisPlacement(loc, dir3(target.args[4]), dir3(target.args[0])));
        }
        const mapped = E(src.args[1]);
        if (mapped) for (const it of asList(mapped.args[3])) processItem(it, tt, acc, depth + 1);
        break;
      }
      case "IFCSHELLBASEDSURFACEMODEL":
      case "IFCFACEBASEDSURFACEMODEL": {
        for (const s of asList(e.args[0])) {
          const shell = E(s);
          if (!shell) continue;
          for (const f of asList(shell.args[0])) {
            const face = E(f);
            if (!face) continue;
            for (const b of asList(face.args[0])) {
              const bound = E(b);
              const loop = bound ? E(bound.args[0]) : null;
              if (!loop || loop.type !== "IFCPOLYLOOP") continue;
              const pts = asList(loop.args[0]).map((p) => applyPoint(t, point3(p) ?? { x: 0, y: 0, z: 0 }));
              for (const p of pts) addGeoPoint(acc, p);
              acc.meshArea += polygonArea3D(pts);
            }
          }
        }
        acc.kinds.add("superficies");
        break;
      }
      case "IFCPOLYLINE":
      case "IFCINDEXEDPOLYCURVE":
      case "IFCCOMPOSITECURVE":
      case "IFCTRIMMEDCURVE": {
        const pts = curvePoints3D(r).map((p) => applyPoint(t, p));
        for (const p of pts) addGeoPoint(acc, p);
        const len = polylineLength3D(pts);
        if (len > 0) acc.axisLength = Math.max(acc.axisLength ?? 0, len);
        acc.kinds.add("curva");
        break;
      }
      case "IFCGEOMETRICSET":
      case "IFCGEOMETRICCURVESET": {
        for (const it of asList(e.args[0])) processItem(it, t, acc, depth + 1);
        break;
      }
      default: {
        // Intento genérico: si la entidad referencia un perfil o puntos, usarlos
        break;
      }
    }
  }

  function geometryOf(productRef: StepArg | undefined, placement: Transform): GeometryResult | null {
    const shape = E(productRef);
    if (!shape) return null;
    const acc: GeoAcc = {
      box: new Box(), profileArea: null, profilePerimeter: null, sweepLength: null,
      volume: 0, meshArea: 0, axisLength: null, kinds: new Set(),
      faces: [], clips: [], tools: [], points: [],
    };
    const reps = asList(shape.args[2]);
    for (const rr of reps) {
      const rep = E(rr);
      if (!rep) continue;
      const repId = asStr(rep.args[1]) ?? "";
      const items = asList(rep.args[3]);
      if (/^Axis$/i.test(repId)) {
        for (const it of items) {
          const pts = curvePoints3D(it).map((p) => applyPoint(placement, p));
          const len = polylineLength3D(pts);
          if (len > 0) acc.axisLength = Math.max(acc.axisLength ?? 0, len);
        }
        continue;
      }
      if (/^(FootPrint|Annotation|Profile)$/i.test(repId)) continue;
      for (const it of items) processItem(it, placement, acc);
    }
    if (acc.box.empty && acc.axisLength === null) return null;

    /* ---------- CARA PRINCIPAL REAL (recortada) ------------------- */
    let face: GeometryResult["face"] = undefined;
    let clippedAway = false;

    if (acc.faces.length) {
      // Preferir la cara con mayor área tras aplicar los recortes
      let best: { poly: Vec3[]; thickness: number; areaRaw: number; areaClipped: number } | null = null;
      for (const f of acc.faces) {
        const areaRaw = polygonArea3D(f.poly);
        if (areaRaw < 1e-9) continue;
        let poly = f.poly;
        for (const c of acc.clips) {
          poly = clipPolygonByPlane(poly, c);
          if (!poly.length) break;
        }
        let areaClipped = poly.length >= 3 ? polygonArea3D(poly) : 0;
        // Restar los sólidos de corte (cubiertas inclinadas en Archicad)
        if (poly.length >= 3) {
          for (const tool of acc.tools) {
            const res = subtractToolFromPolygon(poly, tool);
            poly = res.polygon;
            areaClipped = res.area;
            if (areaClipped <= 1e-9) break;
          }
        }
        if (!best || areaClipped > best.areaClipped) {
          best = { poly, thickness: f.thickness, areaRaw, areaClipped };
        }
      }
      if (best && best.poly.length >= 3 && best.areaClipped > 1e-9) {
        clippedAway = best.areaClipped < best.areaRaw - 1e-6;
        // El contorno puede no reflejar el recorte si la forma resultante no
        // es simple; el ÁREA sí es exacta y manda en la medición.
        const exactClippedArea = best.areaClipped;
        const o = best.poly[0];
        const uDir = norm(sub(best.poly[1], best.poly[0]));
        const nrm = norm(cross(uDir, sub(best.poly[2], best.poly[0])));
        const vDir = norm(cross(nrm, uDir));
        const frame: FaceFrame = { origin: o, u: uDir, v: vDir, n: nrm };
        const uv = best.poly.map((p) => toFaceUV(frame, p));
        // Normalizar para que el contorno empiece en (0,0)
        const minU = Math.min(...uv.map((p) => p.u));
        const minV = Math.min(...uv.map((p) => p.v));
        const outline = uv.map((p) => [(p.u - minU) * S1, (p.v - minV) * S1] as [number, number]);
        const originWorld = {
          x: o.x + uDir.x * minU + vDir.x * minV,
          y: o.y + uDir.y * minU + vDir.y * minV,
          z: o.z + uDir.z * minU + vDir.z * minV,
        };
        face = {
          outline,
          holes: [],
          thickness: best.thickness * S1,
          origin: [originWorld.x * S1, originWorld.y * S1, originWorld.z * S1],
          uAxis: [uDir.x, uDir.y, uDir.z],
          vAxis: [vDir.x, vDir.y, vDir.z],
          nAxis: [nrm.x, nrm.y, nrm.z],
          clipped: clippedAway,
        };
        if (clippedAway) {
          // El volumen prismático debe seguir la cara realmente construida
          acc.volume = exactClippedArea * best.thickness;
          face.exactArea = exactClippedArea * S2;
          // Rango vertical REAL (ya recortado) de la cara: es lo que debe
          // usarse como altura de muros/columnas cortados por una cubierta,
          // en vez de la caja envolvente (que sigue midiendo el sólido base
          // sin recortar, porque acumula también sus puntos originales).
          const zs = best.poly.map((p) => p.z);
          const zMin = Math.min(...zs);
          const zMax = Math.max(...zs);
          if (zMax > zMin) face.zRange = [zMin * S1, zMax * S1];
        }
      }
    }

    const size = acc.box.size();
    const yaw = Math.atan2(placement.x.y, placement.x.x);
    const obbRaw = orientedBox(acc.points);
    const oriented = obbRaw
      ? {
          center: { x: obbRaw.center.x * S1, y: obbRaw.center.y * S1, z: obbRaw.center.z * S1 },
          size: [obbRaw.size[0] * S1, obbRaw.size[1] * S1, obbRaw.size[2] * S1] as [number, number, number],
          axes: obbRaw.axes,
        }
      : undefined;
    if (face && face.thickness <= 1e-7 && oriented) {
      face.thickness = oriented.size[2];
    }
    return {
      kind: [...acc.kinds].join(" + ") || "curva",
      size: { x: size.x * S1, y: size.y * S1, z: size.z * S1 },
      center: {
        x: acc.box.center().x * S1,
        y: acc.box.center().y * S1,
        z: acc.box.center().z * S1,
      },
      yaw,
      profileArea: acc.profileArea !== null ? acc.profileArea * S2 : null,
      profilePerimeter: acc.profilePerimeter !== null ? acc.profilePerimeter * S1 : null,
      sweepLength: acc.sweepLength !== null ? acc.sweepLength * S1 : null,
      volume: acc.volume > 0 ? acc.volume * S3 : null,
      meshArea: acc.meshArea > 0 ? acc.meshArea * S2 : null,
      axisLength: acc.axisLength !== null ? acc.axisLength * S1 : null,
      face,
      clipped: clippedAway,
      oriented,
    };
  }

  /* ---------------- 6. ELEMENTOS --------------------------------- */
  const elements: ParsedElement[] = [];
  const classes: Record<string, number> = {};
  const materialsFound = new Set<string>();
  const levelsFound = new Set<string>();
  let projectName: string | null = null;
  let withGeometry = 0;
  let withIfcQuantities = 0;

  for (const e of ents.values()) {
    if (e.type === "IFCPROJECT") projectName = asStr(e.args[2]) ?? asStr(e.args[3]);
  }

  for (const e of ents.values()) {
    if (!ELEMENT_CLASSES.has(e.type) || /TYPE$/.test(e.type)) continue;

    const globalId = asStr(e.args[0]);
    const name = asStr(e.args[2]);
    const description = asStr(e.args[3]);
    const objectType = asStr(e.args[4]);
    const tag = asStr(e.args[7]);

    const typeId = typeOf.get(e.id);
    const typeName = typeId ? typeNames.get(typeId) ?? null : null;

    let material: string | null = null;
    const matId = materialOf.get(e.id) ?? (typeId ? materialOf.get(typeId) : undefined);
    if (matId !== undefined) material = materialName(matId);

    const storeyId = storeyOf.get(e.id);
    const level = storeyId !== undefined ? storeys.get(storeyId) ?? null : null;

    let layer: string | null = null;
    const repRef = e.args[6];
    if (isRef(repRef)) {
      const rep = ents.get(repRef.ref);
      if (rep) {
        for (const item of asList(rep.args[2])) {
          if (isRef(item) && repToLayer.has(item.ref)) { layer = repToLayer.get(item.ref)!; break; }
          const sub = E(item);
          if (sub) {
            for (const it2 of asList(sub.args[3])) {
              if (isRef(it2) && repToLayer.has(it2.ref)) { layer = repToLayer.get(it2.ref)!; break; }
            }
          }
          if (layer) break;
        }
      }
    }

    /* --- propiedades y cantidades IFC --- */
    const properties: Record<string, Record<string, string | number | boolean | null>> = {};
    const quantities: Record<string, number> = {};
    const dims: Record<string, number | null> = {};
    const dimSrc: Record<string, string> = {};
    const defIds = [...(psetOf.get(e.id) ?? []), ...(typeId ? psetOf.get(typeId) ?? [] : [])];

    for (const defId of defIds) {
      const ps = psets.get(defId);
      if (ps) properties[ps.name] = { ...(properties[ps.name] ?? {}), ...ps.props };
      const qto = qtos.get(defId);
      if (qto) {
        for (const [qn, q] of Object.entries(qto)) {
          const scale = q.pow === 1 ? S1 : q.pow === 2 ? S2 : q.pow === 3 ? S3 : 1;
          quantities[qn] = q.value * scale;
          const map = DIMENSION_MAP[normKey(qn)];
          if (map && (dims[map.field] === undefined || dims[map.field] === null)) {
            dims[map.field] = q.value * scale;
            dimSrc[map.field] = `cantidad IFC (${qn})`;
          }
        }
      }
    }
    if (Object.keys(quantities).length) withIfcQuantities++;

    /* --- dimensiones desde propiedades (si faltan) --- */
    for (const [psetName, props] of Object.entries(properties)) {
      for (const [k, v] of Object.entries(props)) {
        if (typeof v !== "number" || !isFinite(v)) continue;
        const map = DIMENSION_MAP[normKey(k)];
        if (!map) continue;
        if (dims[map.field] !== undefined && dims[map.field] !== null) continue;
        const scale = map.pow === 1 ? S1 : map.pow === 2 ? S2 : map.pow === 3 ? S3 : 1;
        dims[map.field] = v * scale;
        dimSrc[map.field] = `propiedad ${psetName}.${k}`;
      }
    }

    /* --- geometría --- */
    const placement = isRef(e.args[5]) ? localPlacement(e.args[5].ref) : IDENTITY;
    const geo = isRef(e.args[6]) ? geometryOf(e.args[6], placement) : null;
    if (geo) withGeometry++;

    /* --- vanos (IfcRelVoidsElement): puertas, ventanas y pasos ------ */
    const openingList: { width: number; height: number; area: number; name: string | null }[] = [];
    let openingsArea = 0;
    if (geo?.face) {
      const f = geo.face;
      const originV: Vec3 = { x: f.origin[0] / S1, y: f.origin[1] / S1, z: f.origin[2] / S1 };
      const frame: FaceFrame = {
        origin: originV,
        u: { x: f.uAxis[0], y: f.uAxis[1], z: f.uAxis[2] },
        v: { x: f.vAxis[0], y: f.vAxis[1], z: f.vAxis[2] },
        n: { x: f.nAxis[0], y: f.nAxis[1], z: f.nAxis[2] },
      };
      const outlineU = f.outline.map((p) => p[0] / S1);
      const outlineV = f.outline.map((p) => p[1] / S1);
      const maxU = Math.max(...outlineU), maxV = Math.max(...outlineV);

      for (const vid of voidsOf.get(e.id) ?? []) {
        const op = ents.get(vid);
        if (!op) continue;
        const opPlace = isRef(op.args[5]) ? localPlacement(op.args[5].ref) : IDENTITY;
        const opGeo = isRef(op.args[6]) ? geometryOf(op.args[6], opPlace) : null;
        if (!opGeo) continue;

        // Proyectar la caja del vano sobre la cara del elemento anfitrión
        const half = { x: opGeo.size.x / (2 * S1), y: opGeo.size.y / (2 * S1), z: opGeo.size.z / (2 * S1) };
        const c = { x: opGeo.center.x / S1, y: opGeo.center.y / S1, z: opGeo.center.z / S1 };
        let uMin = Infinity, uMax = -Infinity, vMin = Infinity, vMax = -Infinity;
        for (const sx of [-1, 1]) for (const sy of [-1, 1]) for (const sz of [-1, 1]) {
          const p = { x: c.x + sx * half.x, y: c.y + sy * half.y, z: c.z + sz * half.z };
          const q = toFaceUV(frame, p);
          if (q.u < uMin) uMin = q.u;
          if (q.u > uMax) uMax = q.u;
          if (q.v < vMin) vMin = q.v;
          if (q.v > vMax) vMax = q.v;
        }
        // Recortar el hueco al contorno de la cara
        uMin = Math.max(uMin, 0); vMin = Math.max(vMin, 0);
        uMax = Math.min(uMax, maxU); vMax = Math.min(vMax, maxV);
        const du = uMax - uMin, dv = vMax - vMin;
        if (du <= 1e-6 || dv <= 1e-6) continue;

        const fillId = fillsOf.get(vid);
        const fillName = fillId ? asStr(ents.get(fillId)?.args[2] ?? null) : null;
        const w = du * S1, h = dv * S1;
        openingList.push({
          width: Math.round(w * 1e4) / 1e4,
          height: Math.round(h * 1e4) / 1e4,
          area: Math.round(w * h * 1e4) / 1e4,
          name: fillName ?? asStr(op.args[2]),
        });
        openingsArea += w * h;
        f.holes.push([
          [uMin * S1, vMin * S1], [uMax * S1, vMin * S1],
          [uMax * S1, vMax * S1], [uMin * S1, vMax * S1],
        ]);
      }
    }

    const semanticText = `${typeName ?? ""} ${name ?? ""} ${material ?? ""}`
      .toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    /*
     * Archicad exporta la estructura del Asistente de cubiertas (RoofMaker)
     * como proxies y, en algunos casos, como elementos de mobiliario. Son
     * miembros lineales de madera: se miden por longitud, nunca por área.
     */
    const roofLinear =
      ["IFCBUILDINGELEMENTPROXY", "IFCFURNISHINGELEMENT", "IFCMEMBER"].includes(e.type) &&
      /\b(par|cabio|correa|vigueta|cercha|tijeral|liston|listón|viga|durmiente|solera)\b/.test(semanticText);
    const semanticType = roofLinear ? "MIEMBRO_LINEAL_CUBIERTA" : null;

    if (geo) {
      const sx = geo.size.x, sy = geo.size.y, sz = geo.size.z;
      const horiz = [sx, sy].sort((a, b) => b - a); // [mayor, menor]
      const all = [sx, sy, sz].sort((a, b) => b - a);
      const cls = e.type;
      const put = (field: string, value: number | null, src: string) => {
        if (value === null || !isFinite(value) || value <= 0) return;
        if (dims[field] !== undefined && dims[field] !== null) return;
        dims[field] = Math.round(value * 1e6) / 1e6;
        dimSrc[field] = src;
      };
      const g = emptyGeometry();
      void g;

      // Altura/longitud vertical REAL cuando el elemento fue recortado por un
      // sólido o un plano (cubierta, forjado). Nunca se usa para alargar el
      // elemento, solo para acortarlo — y solo si el resultado es creíble
      // (más de 5 cm); de lo contrario se conserva la caja envolvente.
      const clippedVerticalExtent = (rawHeight: number): number | null => {
        const zr = geo.face?.zRange;
        if (!geo.face?.clipped || !zr) return null;
        const h = zr[1] - zr[0];
        if (!isFinite(h) || h <= 0.05) return null;
        if (h > rawHeight + 1e-4) return null;
        return h;
      };

      // Área real de la cara principal (ya recortada por planos de cubierta)
      const faceArea = geo.face
        ? (geo.face.exactArea ?? polygonAreaUV(geo.face.outline.map(([u, v]) => ({ u, v }))))
        : null;
      const faceClipped = !!geo.face?.clipped;

      if (/WALL/.test(cls)) {
        const length = geo.axisLength ?? horiz[0];
        const thickness = geo.face?.thickness ?? horiz[1];
        const clippedHeight = clippedVerticalExtent(sz);
        const height = clippedHeight ?? sz;
        put("length", length, geo.axisLength ? "geometría (eje del muro)" : "geometría (caja envolvente)");
        put("thickness", thickness, geo.face ? "geometría (espesor de la cara)" : "geometría (menor dimensión horizontal)");
        put("height", height, clippedHeight ? "geometría (altura recortada por sólido/plano)" : "geometría (altura de caja)");

        const bruta = faceArea ?? length * height;
        const neta = Math.max(0, bruta - openingsArea);
        put("grossArea", bruta,
          faceClipped ? "geometría (cara real recortada por plano)" :
            faceArea ? "geometría (cara del paño)" : "geometría (largo × alto)");
        put("netArea", neta,
          openingsArea > 0 ? `geometría (cara real − ${openingList.length} vano(s) = ${openingsArea.toFixed(2)} m²)`
            : faceClipped ? "geometría (cara real recortada, sin vanos)" : "geometría (cara del paño)");
        const vol = geo.volume ?? neta * thickness;
        put("volume", vol, geo.volume ? "geometría (sólido)" : "geometría (área × espesor)");
        put("netVolume", Math.max(0, (faceArea ?? bruta) * thickness - openingsArea * thickness),
          openingsArea > 0 ? "geometría (sólido − vanos)" : "geometría (sólido)");
      } else if (/SLAB|ROOF|COVERING|PLATE/.test(cls)) {
        const thickness = geo.face?.thickness ?? all[2];
        const area = faceArea ?? geo.profileArea ?? sx * sy;
        const neta = Math.max(0, area - openingsArea);
        put("thickness", thickness, "geometría (espesor)");
        put("area", area, faceClipped ? "geometría (cara real recortada)" : geo.profileArea ? "geometría (perfil extruido)" : "geometría (planta de la caja)");
        put("grossArea", area, "geometría (cara real)");
        put("netArea", neta, openingsArea > 0 ? `geometría (cara real − ${openingList.length} vano(s))` : "geometría (cara real)");
        put("volume", geo.volume ?? neta * thickness, geo.volume ? "geometría (sólido)" : "geometría (área × espesor)");
        put("netVolume", dims.volume ?? null, "geometría (sólido)");
        put("perimeter", geo.profilePerimeter, "geometría (perímetro del perfil)");
      } else if (roofLinear || /BEAM|COLUMN|MEMBER|PILE|REINFORCINGBAR/.test(cls)) {
        const os = geo.oriented?.size ?? [all[0], all[1], all[2]];
        // En los B-Rep de RoofMaker los extremos pueden estar biselados; la
        // caja PCA crece unas centésimas. El borde longitudinal de la cara
        // lateral representa el eje fabricado con exactitud.
        const faceEdges = geo.face?.outline.map((p, i, arr) => {
          const q = arr[(i + 1) % arr.length];
          return Math.hypot(q[0] - p[0], q[1] - p[1]);
        }) ?? [];
        const roofAxisLength = roofLinear && faceEdges.length ? Math.max(...faceEdges) : null;
        let length = geo.sweepLength ?? geo.axisLength ?? roofAxisLength ?? os[0];
        // Columna cortada por una cubierta o forjado: el recorte reduce la
        // altura real por debajo de la caja/eje sin recortar.
        let lengthClippedSrc = false;
        if (/COLUMN/.test(cls) && !roofLinear) {
          const clippedHeight = clippedVerticalExtent(length);
          if (clippedHeight) { length = clippedHeight; lengthClippedSrc = true; }
        }
        // En miembros lineales inclinados, os[1]/os[2] son las dimensiones
        // REALES de la sección; nunca se usa el desnivel global como canto.
        const sectionMajor = os[1];
        const sectionMinor = os[2];
        const csa = geo.profileArea ??
          (geo.volume && length > 0 ? geo.volume / length : sectionMajor * sectionMinor);
        put("length", length,
          lengthClippedSrc ? "geometría (altura recortada por sólido/plano)" :
            geo.sweepLength ? "geometría (extrusión)" : geo.oriented ? "geometría (eje mayor de caja orientada)" : "geometría (mayor dimensión)");
        put("crossSectionArea", csa, geo.profileArea ? "geometría (perfil)" : "geometría (volumen ÷ longitud orientada)");
        put("width", sectionMinor, "geometría (ancho menor de sección orientada)");
        put("height", /COLUMN/.test(cls) && !roofLinear ? length : sectionMajor,
          lengthClippedSrc ? "geometría (altura recortada por sólido/plano)" :
            roofLinear || geo.oriented ? "geometría (canto de sección orientada)" : "geometría (caja)");
        put("thickness", sectionMinor, "geometría (espesor menor de sección orientada)");
        put("volume", geo.volume ?? csa * length, geo.volume ? "geometría (sólido)" : "geometría (sección × longitud)");
        put("netVolume", dims.volume ?? null, "geometría (sólido)");
        const per = geo.profilePerimeter ?? 2 * (all[1] + all[2]);
        put("perimeter", per, "geometría (perímetro de sección)");
        put("surfaceArea", geo.meshArea ?? per * length, geo.meshArea ? "geometría (malla)" : "geometría (perímetro × longitud)");
        if (roofLinear) {
          // Los valores semánticos de un miembro RoofMaker prevalecen sobre
          // propiedades genéricas o la caja global de Archicad.
          dims.length = Math.round(length * 1e6) / 1e6;
          dims.height = Math.round(sectionMajor * 1e6) / 1e6;
          dims.width = Math.round(sectionMinor * 1e6) / 1e6;
          dims.thickness = dims.width;
          dims.crossSectionArea = Math.round(csa * 1e8) / 1e8;
          dims.perimeter = Math.round(2 * (sectionMajor + sectionMinor) * 1e6) / 1e6;
          dims.area = null;
          dims.grossArea = null;
          dims.netArea = null;
          dimSrc.length = "geometría B-Rep (eje longitudinal inclinado)";
          dimSrc.height = "geometría B-Rep (canto de sección orientada)";
          dimSrc.width = "geometría B-Rep (ancho de sección orientada)";
          dimSrc.thickness = dimSrc.width;
          dimSrc.crossSectionArea = "geometría B-Rep (volumen ÷ longitud)";
          dimSrc.perimeter = "geometría B-Rep (perímetro de sección)";
        }
      } else if (/PIPE|DUCT|CABLE|FLOWSEGMENT/.test(cls)) {
        const length = geo.axisLength ?? geo.sweepLength ?? all[0];
        put("length", length, "geometría (directriz / extrusión)");
        put("volume", geo.volume, "geometría (sólido)");
        put("surfaceArea", geo.meshArea, "geometría (malla)");
      } else if (/DOOR|WINDOW/.test(cls)) {
        put("width", horiz[0], "geometría (caja)");
        put("height", sz, "geometría (caja)");
        put("thickness", horiz[1], "geometría (caja)");
        put("area", horiz[0] * sz, "geometría (ancho × alto)");
        put("count", 1, "conteo de elemento");
      } else if (/SPACE/.test(cls)) {
        const area = geo.profileArea ?? sx * sy;
        put("area", area, "geometría (planta)");
        put("netArea", area, "geometría (planta)");
        put("height", sz, "geometría (altura)");
        put("volume", geo.volume ?? area * sz, "geometría");
        put("perimeter", geo.profilePerimeter, "geometría (perímetro)");
      } else if (/FOOTING/.test(cls)) {
        put("length", all[0], "geometría (caja)");
        put("width", all[1], "geometría (caja)");
        put("height", all[2], "geometría (caja)");
        put("volume", geo.volume ?? all[0] * all[1] * all[2], geo.volume ? "geometría (sólido)" : "geometría (caja)");
        put("netVolume", dims.volume ?? null, "geometría (sólido)");
        put("area", all[0] * all[1], "geometría (planta)");
      } else {
        put("length", all[0], "geometría (caja)");
        put("width", all[1], "geometría (caja)");
        put("height", sz, "geometría (caja)");
        put("area", geo.profileArea ?? sx * sy, "geometría");
        put("volume", geo.volume, "geometría (sólido)");
        put("surfaceArea", geo.meshArea, "geometría (malla)");
        put("count", 1, "conteo de elemento");
      }
      // Comunes
      put("count", 1, "conteo de elemento");
      put("surfaceArea", geo.meshArea, "geometría (malla)");
    } else {
      dims.count = dims.count ?? 1;
      dimSrc.count = dimSrc.count ?? "conteo de elemento";
    }

    for (const f of DIM_FIELDS) dims[f] = dims[f] ?? null;

    elements.push({
      globalId, ifcClass: e.type, name, objectType, description, tag,
      typeName, semanticType, material, level, layer, properties, quantities,
      dimensions: dims, dimensionSources: dimSrc,
      geometry: geo
        ? {
            kind: geo.kind,
            size: [
              Math.round(geo.size.x * 1e4) / 1e4,
              Math.round(geo.size.y * 1e4) / 1e4,
              Math.round(geo.size.z * 1e4) / 1e4,
            ],
            center: [
              Math.round(geo.center.x * 1e4) / 1e4,
              Math.round(geo.center.y * 1e4) / 1e4,
              Math.round(geo.center.z * 1e4) / 1e4,
            ],
            yaw: Math.round(geo.yaw * 1e4) / 1e4,
            face: geo.face
              ? {
                  outline: geo.face.outline.map(([u, v]) => [Math.round(u * 1e4) / 1e4, Math.round(v * 1e4) / 1e4] as [number, number]),
                  holes: geo.face.holes.map((h) => h.map(([u, v]) => [Math.round(u * 1e4) / 1e4, Math.round(v * 1e4) / 1e4] as [number, number])),
                  thickness: Math.round(geo.face.thickness * 1e4) / 1e4,
                  origin: geo.face.origin.map((n) => Math.round(n * 1e4) / 1e4) as [number, number, number],
                  uAxis: geo.face.uAxis.map((n) => Math.round(n * 1e6) / 1e6) as [number, number, number],
                  vAxis: geo.face.vAxis.map((n) => Math.round(n * 1e6) / 1e6) as [number, number, number],
                  nAxis: geo.face.nAxis.map((n) => Math.round(n * 1e6) / 1e6) as [number, number, number],
                  clipped: geo.face.clipped,
                  exactArea: geo.face.exactArea !== undefined
                    ? Math.round(geo.face.exactArea * 1e4) / 1e4 : undefined,
                }
              : undefined,
            openings: openingList.length ? openingList : undefined,
            oriented: geo.oriented
              ? {
                  size: geo.oriented.size.map((n) => Math.round(n * 1e5) / 1e5) as [number, number, number],
                  center: [geo.oriented.center.x, geo.oriented.center.y, geo.oriented.center.z]
                    .map((n) => Math.round(n * 1e5) / 1e5) as [number, number, number],
                  axes: geo.oriented.axes.map((a) => [a.x, a.y, a.z]
                    .map((n) => Math.round(n * 1e6) / 1e6) as [number, number, number]) as
                    [[number, number, number], [number, number, number], [number, number, number]],
                }
              : undefined,
          }
        : null,
    });

    classes[e.type] = (classes[e.type] ?? 0) + 1;
    if (material) materialsFound.add(material);
    if (level) levelsFound.add(level);
  }

  if (elements.length === 0) warnings.push("No se encontraron elementos de construcción reconocibles en el archivo.");
  if (withGeometry === 0 && elements.length > 0) {
    warnings.push("El modelo no contiene geometría interpretable: las cantidades deberán medirse manualmente.");
  }
  if (withIfcQuantities === 0 && elements.length > 0) {
    warnings.push("El modelo no trae cantidades IFC (BaseQuantities). Las dimensiones se calcularon desde la geometría.");
  }
  if (lengthScale !== 1 && !autoCorrected) {
    warnings.push(`Unidad de longitud del modelo: ${lengthUnit} (factor ${lengthScale} → metros). Todas las cantidades se convirtieron a metros.`);
  }
  if (modelExtent > 0) {
    warnings.push(`Extensión del modelo tras la conversión: ≈ ${modelExtent.toFixed(1)} m. Escala ${scaleSource}.`);
  }

  elements.sort((a, b) => a.ifcClass.localeCompare(b.ifcClass) || (a.name ?? "").localeCompare(b.name ?? ""));

  return {
    schema,
    projectName,
    fileName: fileNameMatch ? fileNameMatch[1] : fileName ?? null,
    entityCount: ents.size,
    elementCount: elements.length,
    classes,
    levels: [...levelsFound].sort(),
    materials: [...materialsFound].sort(),
    warnings,
    lengthUnit,
    lengthScale,
    scaleSource,
    autoCorrected,
    modelExtent: Math.round(modelExtent * 100) / 100,
    withGeometry,
    withIfcQuantities,
    elements,
  };
}
