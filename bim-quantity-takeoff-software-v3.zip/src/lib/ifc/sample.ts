/* ================================================================== */
/*  Modelos IFC de demostración (STEP real, IFC4) CON GEOMETRÍA        */
/*  Cada elemento lleva placement y sólido extruido, de modo que el    */
/*  visor 3D y el motor geométrico funcionen como con un IFC real.     */
/*  La disciplina ESTRUCTURA se genera SIN cantidades IFC para probar  */
/*  la medición obtenida únicamente de la geometría.                   */
/* ================================================================== */

let guidCounter = 0;
const GUID_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$";
function gid(): string {
  guidCounter = (guidCounter + 1) % Number.MAX_SAFE_INTEGER;
  let n = guidCounter + 1;
  let s = "1";
  while (s.length < 22) { s += GUID_CHARS[n % 64]; n = Math.floor(n / 64) + 1; }
  return s;
}

const esc = (s: string) => s.replace(/'/g, "''");
const S = (s: string | null | undefined) => (s == null ? "$" : `'${esc(s)}'`);
const N = (v: number) => (Number.isInteger(v) ? `${v}.` : `${v}`);

interface Spec {
  cls: string;
  name: string;
  typeName: string;
  level: string;
  material?: string;
  tag?: string;
  /** Recorte por plano inclinado (muro bajo cubierta a dos aguas). */
  clip?: { point: [number, number, number]; normal: [number, number, number] };
  /** Vanos que perforan el elemento: [ancho, alto, desplazamiento u, altura v]. */
  openings?: { w: number; h: number; u: number; v: number; name: string }[];
  /** Tamaño local [x, y, z] en metros: perfil (x,y) extruido en z. */
  size: [number, number, number];
  /** Posición del centro de la base en coordenadas del nivel. */
  pos: [number, number, number];
  /** Giro alrededor de Z en grados. */
  rot?: number;
  quantities?: [string, number][];
  psets?: { name: string; props: Record<string, string | number | boolean> }[];
  predefined?: string;
}

function buildIfc(
  title: string,
  projectName: string,
  storeys: { name: string; elev: number }[],
  specs: Spec[]
): string {
  let c = 0;
  const lines: string[] = [];
  const add = (type: string, args: string): number => {
    const id = ++c;
    lines.push(`#${id}=${type}(${args});`);
    return id;
  };

  const dirZ = add("IFCDIRECTION", "(0.,0.,1.)");
  const dirX = add("IFCDIRECTION", "(1.,0.,0.)");
  const origin = add("IFCCARTESIANPOINT", "(0.,0.,0.)");
  const worldPlacement = add("IFCAXIS2PLACEMENT3D", `#${origin},#${dirZ},#${dirX}`);
  const ctx = add("IFCGEOMETRICREPRESENTATIONCONTEXT", `$,'Model',3,1.E-05,#${worldPlacement},$`);

  const owner = add("IFCOWNERHISTORY", "$,$,$,.ADDED.,$,$,$,0");
  const lenUnit = add("IFCSIUNIT", "*,.LENGTHUNIT.,$,.METRE.");
  const areaUnit = add("IFCSIUNIT", "*,.AREAUNIT.,$,.SQUARE_METRE.");
  const volUnit = add("IFCSIUNIT", "*,.VOLUMEUNIT.,$,.CUBIC_METRE.");
  const units = add("IFCUNITASSIGNMENT", `(#${lenUnit},#${areaUnit},#${volUnit})`);

  const project = add("IFCPROJECT", `${S(gid())},#${owner},${S(projectName)},${S(title)},$,$,$,(#${ctx}),#${units}`);
  const sitePl = add("IFCLOCALPLACEMENT", `$,#${worldPlacement}`);
  const site = add("IFCSITE", `${S(gid())},#${owner},'Sitio',$,$,#${sitePl},$,$,.ELEMENT.,$,$,$,$,$`);
  const bldPl = add("IFCLOCALPLACEMENT", `#${sitePl},#${worldPlacement}`);
  const building = add("IFCBUILDING", `${S(gid())},#${owner},'Edificación principal',$,$,#${bldPl},$,$,.ELEMENT.,$,$,$`);

  const storeyIds = new Map<string, number>();
  const storeyPl = new Map<string, number>();
  for (const st of storeys) {
    const p = add("IFCCARTESIANPOINT", `(0.,0.,${N(st.elev)})`);
    const ax = add("IFCAXIS2PLACEMENT3D", `#${p},#${dirZ},#${dirX}`);
    const pl = add("IFCLOCALPLACEMENT", `#${bldPl},#${ax}`);
    const id = add("IFCBUILDINGSTOREY", `${S(gid())},#${owner},${S(st.name)},$,$,#${pl},$,$,.ELEMENT.,${N(st.elev)}`);
    storeyIds.set(st.name, id);
    storeyPl.set(st.name, pl);
  }

  add("IFCRELAGGREGATES", `${S(gid())},#${owner},$,$,#${project},(#${site})`);
  add("IFCRELAGGREGATES", `${S(gid())},#${owner},$,$,#${site},(#${building})`);
  add("IFCRELAGGREGATES", `${S(gid())},#${owner},$,$,#${building},(${[...storeyIds.values()].map((i) => `#${i}`).join(",")})`);

  const typeIds = new Map<string, number>();
  const matIds = new Map<string, number>();
  const byStorey = new Map<string, number[]>();
  const byType = new Map<string, number[]>();
  const byMat = new Map<string, number[]>();

  for (const sp of specs) {
    /* --- colocación --- */
    const pt = add("IFCCARTESIANPOINT", `(${N(sp.pos[0])},${N(sp.pos[1])},${N(sp.pos[2])})`);
    let refDir = dirX;
    if (sp.rot) {
      const rad = (sp.rot * Math.PI) / 180;
      refDir = add("IFCDIRECTION", `(${N(+Math.cos(rad).toFixed(6))},${N(+Math.sin(rad).toFixed(6))},0.)`);
    }
    const ax = add("IFCAXIS2PLACEMENT3D", `#${pt},#${dirZ},#${refDir}`);
    const placement = add("IFCLOCALPLACEMENT", `#${storeyPl.get(sp.level)!},#${ax}`);

    /* --- geometría: perfil rectangular extruido --- */
    const p2 = add("IFCCARTESIANPOINT", "(0.,0.)");
    const d2 = add("IFCDIRECTION", "(1.,0.)");
    const ax2 = add("IFCAXIS2PLACEMENT2D", `#${p2},#${d2}`);
    const profile = add("IFCRECTANGLEPROFILEDEF", `.AREA.,$,#${ax2},${N(sp.size[0])},${N(sp.size[1])}`);
    const solidPos = add("IFCAXIS2PLACEMENT3D", `#${origin},#${dirZ},#${dirX}`);
    const solid = add("IFCEXTRUDEDAREASOLID", `#${profile},#${solidPos},#${dirZ},${N(sp.size[2])}`);
    // Recorte por plano (cubierta inclinada): el muro deja de ser rectangular
    let bodyId = solid;
    let repType = "SweptSolid";
    if (sp.clip) {
      const cp = add("IFCCARTESIANPOINT", `(${N(sp.clip.point[0])},${N(sp.clip.point[1])},${N(sp.clip.point[2])})`);
      const cn = add("IFCDIRECTION", `(${N(sp.clip.normal[0])},${N(sp.clip.normal[1])},${N(sp.clip.normal[2])})`);
      const cax = add("IFCAXIS2PLACEMENT3D", `#${cp},#${cn},$`);
      const plane = add("IFCPLANE", `#${cax}`);
      const half = add("IFCHALFSPACESOLID", `#${plane},.T.`);
      bodyId = add("IFCBOOLEANCLIPPINGRESULT", `.DIFFERENCE.,#${solid},#${half}`);
      repType = "Clipping";
    }
    const rep = add("IFCSHAPEREPRESENTATION", `#${ctx},'Body','${repType}',(#${bodyId})`);
    const shape = add("IFCPRODUCTDEFINITIONSHAPE", `$,$,(#${rep})`);

    const extra = sp.predefined ? `,.${sp.predefined}.` : "";
    const elId = add(
      sp.cls,
      `${S(gid())},#${owner},${S(sp.name)},$,$,#${placement},#${shape},${S(sp.tag ?? null)}${extra}`
    );

    // Vanos reales (IfcOpeningElement + IfcRelVoidsElement)
    for (const op of sp.openings ?? []) {
      const op2 = add("IFCCARTESIANPOINT", `(${N(-sp.size[0] / 2 + op.u + op.w / 2)},${N(0)},${N(op.v)})`);
      const opax = add("IFCAXIS2PLACEMENT3D", `#${op2},#${dirZ},#${dirX}`);
      const oppl = add("IFCLOCALPLACEMENT", `#${placement},#${opax}`);
      const p2o = add("IFCCARTESIANPOINT", "(0.,0.)");
      const d2o = add("IFCDIRECTION", "(1.,0.)");
      const ax2o = add("IFCAXIS2PLACEMENT2D", `#${p2o},#${d2o}`);
      const profO = add("IFCRECTANGLEPROFILEDEF", `.AREA.,$,#${ax2o},${N(op.w)},${N(sp.size[1] + 0.1)}`);
      const posO = add("IFCAXIS2PLACEMENT3D", `#${origin},#${dirZ},#${dirX}`);
      const solO = add("IFCEXTRUDEDAREASOLID", `#${profO},#${posO},#${dirZ},${N(op.h)}`);
      const repO = add("IFCSHAPEREPRESENTATION", `#${ctx},'Body','SweptSolid',(#${solO})`);
      const shO = add("IFCPRODUCTDEFINITIONSHAPE", `$,$,(#${repO})`);
      const opId = add("IFCOPENINGELEMENT", `${S(gid())},#${owner},${S(op.name)},$,$,#${oppl},#${shO},$,.OPENING.`);
      add("IFCRELVOIDSELEMENT", `${S(gid())},#${owner},$,$,#${elId},#${opId}`);
    }

    let typeId = typeIds.get(sp.typeName);
    if (!typeId) {
      typeId = add(`${sp.cls}TYPE`, `${S(gid())},#${owner},${S(sp.typeName)},$,$,$,$,$,$,.NOTDEFINED.`);
      typeIds.set(sp.typeName, typeId);
      byType.set(`${sp.typeName}::type`, [typeId]);
    }
    byType.set(sp.typeName, [...(byType.get(sp.typeName) ?? []), elId]);
    byStorey.set(sp.level, [...(byStorey.get(sp.level) ?? []), elId]);

    if (sp.material) {
      byMat.set(sp.material, [...(byMat.get(sp.material) ?? []), elId]);
      if (!matIds.has(sp.material)) matIds.set(sp.material, add("IFCMATERIAL", S(sp.material)));
    }

    if (sp.quantities?.length) {
      const qIds = sp.quantities.map(([qn, qv]) => {
        const isCount = /count/i.test(qn);
        const isArea = /area/i.test(qn);
        const isVol = /volume/i.test(qn);
        const type = isCount ? "IFCQUANTITYCOUNT" : isArea ? "IFCQUANTITYAREA" : isVol ? "IFCQUANTITYVOLUME" : "IFCQUANTITYLENGTH";
        return add(type, `${S(qn)},$,$,${N(qv)}`);
      });
      const qtoId = add("IFCELEMENTQUANTITY", `${S(gid())},#${owner},'BaseQuantities',$,$,(${qIds.map((i) => `#${i}`).join(",")})`);
      add("IFCRELDEFINESBYPROPERTIES", `${S(gid())},#${owner},$,$,(#${elId}),#${qtoId}`);
    }

    for (const ps of sp.psets ?? []) {
      const pIds = Object.entries(ps.props).map(([k, v]) =>
        add("IFCPROPERTYSINGLEVALUE",
          `${S(k)},$,${typeof v === "number" ? `IFCREAL(${N(v)})` : typeof v === "boolean" ? `IFCBOOLEAN(.${v ? "T" : "F"}.)` : `IFCTEXT('${esc(String(v))}')`},$`)
      );
      const psId = add("IFCPROPERTYSET", `${S(gid())},#${owner},${S(ps.name)},$,(${pIds.map((i) => `#${i}`).join(",")})`);
      add("IFCRELDEFINESBYPROPERTIES", `${S(gid())},#${owner},$,$,(#${elId}),#${psId}`);
    }
  }

  for (const [typeName, ids] of byType) {
    if (typeName.endsWith("::type")) continue;
    const typeId = byType.get(`${typeName}::type`)![0];
    add("IFCRELDEFINESBYTYPE", `${S(gid())},#${owner},$,$,(${ids.map((i) => `#${i}`).join(",")}),#${typeId}`);
  }
  for (const [level, ids] of byStorey) {
    add("IFCRELCONTAINEDINSPATIALSTRUCTURE", `${S(gid())},#${owner},$,$,(${ids.map((i) => `#${i}`).join(",")}),#${storeyIds.get(level)!}`);
  }
  for (const [mat, ids] of byMat) {
    add("IFCRELASSOCIATESMATERIAL", `${S(gid())},#${owner},$,$,(${ids.map((i) => `#${i}`).join(",")}),#${matIds.get(mat)!}`);
  }

  return [
    "ISO-10303-21;", "HEADER;",
    "FILE_DESCRIPTION(('ViewDefinition [CoordinationView]'),'2;1');",
    `FILE_NAME('${esc(title)}.ifc','2026-01-15T09:00:00',('BIMCost'),('BIMCost'),'BIMCost Sample','BIMCost','');`,
    "FILE_SCHEMA(('IFC4');", "ENDSEC;", "DATA;", ...lines, "ENDSEC;", "END-ISO-10303-21;",
  ].join("\n").replace("FILE_SCHEMA(('IFC4');", "FILE_SCHEMA(('IFC4'));");
}

/* ------------------------------------------------------------------ */
const NIVELES = [{ name: "Nivel 1", elev: 0 }, { name: "Nivel 2", elev: 2.9 }];
const CONCRETO = "Concreto f'c=21 MPa";
const W = 12.0;   // ancho del edificio (X)
const D = 9.6;    // profundidad (Y)
const H = 2.7;    // altura libre

export function sampleArquitectura(): string {
  const specs: Spec[] = [];
  for (const { name: nivel } of NIVELES) {
    // Muros exteriores perimetrales (bloque 15 cm)
    const ext: { len: number; pos: [number, number, number]; rot: number }[] = [
      { len: W, pos: [-W / 2, -D / 2, 0], rot: 0 },
      { len: W, pos: [-W / 2, D / 2 - 0.15, 0], rot: 0 },
      { len: D, pos: [-W / 2, -D / 2, 0], rot: 90 },
      { len: D, pos: [W / 2 - 0.15, -D / 2, 0], rot: 90 },
    ];
    ext.forEach((e, i) => {
      // Sin cantidades IFC declaradas: el área debe salir de la geometría real,
      // descontando los vanos de ventanas y puertas.
      const openings = i === 0
        ? [
            { w: 1.5, h: 1.2, u: 2.0, v: 1.0, name: "Vano ventana V-1" },
            { w: 1.5, h: 1.2, u: 7.5, v: 1.0, name: "Vano ventana V-2" },
          ]
        : i === 1
          ? [{ w: 1.0, h: 2.1, u: 5.0, v: 0, name: "Vano puerta acceso" }]
          : [];
      specs.push({
        cls: "IFCWALL", name: `Muro exterior BLO-15 (${nivel}.${i + 1})`, typeName: "Muro ext bloque 15",
        level: nivel, material: "Bloque de concreto", tag: "ME-15",
        size: [e.len, 0.15, H], pos: e.pos, rot: e.rot,
        openings,
        psets: [{ name: "Pset_WallCommon", props: { Reference: "ME-15", IsExternal: true, LoadBearing: true } }],
      });
    });

    // Muros interiores (bloque 12 cm)
    const int: { len: number; pos: [number, number, number]; rot: number }[] = [
      { len: 5.4, pos: [-3.0, -1.2, 0], rot: 0 },
      { len: 4.2, pos: [1.2, -3.4, 0], rot: 90 },
      { len: 3.6, pos: [-4.8, 0.8, 0], rot: 90 },
      { len: 3.0, pos: [2.4, 1.6, 0], rot: 0 },
      { len: 2.8, pos: [-1.4, 2.2, 0], rot: 90 },
      { len: 2.4, pos: [3.6, -2.0, 0], rot: 0 },
    ];
    int.forEach((e, i) => {
      const area = +(e.len * H).toFixed(2);
      specs.push({
        cls: "IFCWALL", name: `Muro interior BLO-12 (${nivel}.${i + 1})`, typeName: "Muro int bloque 12",
        level: nivel, material: "Bloque de concreto", tag: "MI-12",
        size: [e.len, 0.12, H], pos: e.pos, rot: e.rot,
        quantities: [["Length", e.len], ["Height", H], ["Width", 0.12], ["NetArea", area], ["NetVolume", +(area * 0.12).toFixed(3)]],
        psets: [
          { name: "Pset_WallCommon", props: { Reference: "MI-12", IsExternal: false, LoadBearing: false } },
          { name: "Obra_Notas", props: { Etiqueta: "MURO INTERIOR", Observacion: "Texto descriptivo: no es una cantidad" } },
        ],
      });
    });
  }

  // Puertas de madera
  for (let i = 0; i < 7; i++) {
    const nivel = i < 4 ? "Nivel 1" : "Nivel 2";
    specs.push({
      cls: "IFCDOOR", name: `Puerta PM-${i + 1}`, typeName: "Puerta madera 0.90x2.10",
      level: nivel, material: "Madera sólida", tag: "PM-90", predefined: "DOOR",
      size: [0.9, 0.12, 2.1], pos: [-4.5 + i * 1.5, -1.2, 0],
      quantities: [["Height", 2.1], ["Width", 0.9], ["Count", 1]],
      psets: [{ name: "Pset_DoorCommon", props: { Reference: "PM-90", OperationType: "SWINGING" } }],
    });
  }
  // Puerta metálica (una sola: el grupo no debe duplicarse con las de madera)
  specs.push({
    cls: "IFCDOOR", name: "Puerta metálica acceso", typeName: "Puerta metálica 1.00x2.10",
    level: "Nivel 1", material: "Acero", tag: "PMT-1", predefined: "DOOR",
    size: [1.0, 0.15, 2.1], pos: [0, -D / 2, 0],
    quantities: [["Height", 2.1], ["Width", 1.0], ["Count", 1]],
  });
  // Ventanas
  for (let i = 0; i < 6; i++) {
    const nivel = i < 3 ? "Nivel 1" : "Nivel 2";
    specs.push({
      cls: "IFCWINDOW", name: `Ventana V-${i + 1}`, typeName: "Ventana aluminio 1.50x1.20",
      level: nivel, material: "Aluminio y vidrio", tag: "V-150", predefined: "WINDOW",
      size: [1.5, 0.15, 1.2], pos: [-4 + (i % 3) * 3.5, D / 2 - 0.15, 1.0],
      quantities: [["Height", 1.2], ["Width", 1.5], ["Count", 1]],
    });
  }
  // Muros hastiales: se modelan rectangulares y se recortan con el plano de
  // la cubierta inclinada. Su área NO es la del rectángulo.
  for (const [i, x] of [-W / 2, W / 2 - 0.15].entries()) {
    specs.push({
      cls: "IFCWALL", name: `Muro hastial cubierta ${i + 1}`, typeName: "Muro hastial bloque 15",
      level: "Nivel 2", material: "Bloque de concreto", tag: "MH-15",
      size: [D, 0.15, 2.4], pos: [x, -D / 2, H], rot: 90,
      // Plano de la cubierta inclinada, en coordenadas locales del muro:
      // el material por ENCIMA del plano se elimina (queda un muro a un agua).
      clip: { point: [0, 0, 1.7], normal: [0.15, 0, 0.988] },
      psets: [{ name: "Pset_WallCommon", props: { Reference: "MH-15", IsExternal: true } }],
    });
  }

  // Cubierta
  specs.push({
    cls: "IFCROOF", name: "Cubierta liviana", typeName: "Cubierta metálica liviana",
    level: "Nivel 2", material: "Estructura metálica y teja", tag: "CUB-1",
    size: [W, D, 0.12], pos: [-W / 2, -D / 2, H],
    quantities: [["NetArea", +(W * D).toFixed(2)], ["Width", 0.12]],
    psets: [{ name: "Pset_RoofCommon", props: { Reference: "CUB-LIV", IsExternal: true } }],
  });
  // Mobiliario (no presupuestable: debe poder apagarse)
  for (let i = 0; i < 4; i++) {
    specs.push({
      cls: "IFCFURNISHINGELEMENT", name: `Mueble closet ${i + 1}`, typeName: "Closet modular",
      level: i < 2 ? "Nivel 1" : "Nivel 2", material: "Madera aglomerada", tag: "MOB",
      size: [1.8, 0.6, 2.2], pos: [-5 + i * 3, 3.0, 0],
    });
  }

  return buildIfc("casa-x-arquitectura", "CASA X — Arquitectura", NIVELES, specs);
}

/** Estructura SIN cantidades IFC: obliga a medir desde la geometría. */
export function sampleEstructura(): string {
  const specs: Spec[] = [];
  const xs = [-W / 2 + 0.3, -2.0, 2.0, W / 2 - 0.6];
  const ys = [-D / 2 + 0.3, D / 2 - 0.6];

  for (const { name: nivel } of NIVELES) {
    xs.forEach((x, i) => ys.forEach((y, j) => {
      specs.push({
        cls: "IFCCOLUMN", name: `Columna C-1 (${nivel} ${i + 1}${j + 1})`, typeName: "Columna concreto 0.30x0.30",
        level: nivel, material: CONCRETO, tag: "C-30x30",
        size: [0.3, 0.3, H],
        pos: [x, y, 0],
        psets: [{ name: "Pset_ColumnCommon", props: { Reference: "C-30x30", LoadBearing: true } }],
      });
    }));
  }
  // Vigas: 5 por nivel
  for (const { name: nivel } of NIVELES) {
    for (let i = 0; i < 5; i++) {
      const len = i < 3 ? 4.2 : 3.6;
      specs.push({
        cls: "IFCBEAM", name: `Viga V-1 (${nivel} ${i + 1})`, typeName: "Viga concreto 0.30x0.40",
        level: nivel, material: CONCRETO, tag: "V-30x40",
        size: [len, 0.3, 0.4], pos: [-W / 2 + 0.3 + (i % 3) * 4.2, -D / 2 + 0.3 + Math.floor(i / 3) * 4.5, H],
      });
    }
  }
  specs.push({
    cls: "IFCSLAB", name: "Losa maciza entrepiso", typeName: "Losa maciza e=0.12 m",
    level: "Nivel 2", material: CONCRETO, tag: "LS-12",
    size: [W, D, 0.12], pos: [-W / 2, -D / 2, -0.12],
    psets: [{ name: "Pset_SlabCommon", props: { Reference: "LS-12", LoadBearing: true } }],
  });
  for (let i = 0; i < 8; i++) {
    specs.push({
      cls: "IFCFOOTING", name: `Zapata Z-1 (${i + 1})`, typeName: "Zapata 1.20x1.20x0.40",
      level: "Nivel 1", material: CONCRETO, tag: "Z-120",
      size: [1.2, 1.2, 0.4], pos: [xs[i % 4] - 0.45, ys[Math.floor(i / 4) % 2] - 0.45, -1.2],
    });
  }
  return buildIfc("casa-x-estructura", "CASA X — Estructura", NIVELES, specs);
}

export function sampleHidrosanitaria(): string {
  const specs: Spec[] = [];
  const sanL = [3.2, 2.8, 2.4, 1.8, 1.6, 1.2];
  sanL.forEach((L, i) => {
    specs.push({
      cls: "IFCPIPESEGMENT", name: `Tubería desagüe DS-${i + 1}`, typeName: 'PVC sanitario 2" (DN50)',
      level: i % 2 === 0 ? "Nivel 1" : "Nivel 2", material: "PVC", tag: "DS-50", predefined: "NOTDEFINED",
      size: [L, 0.06, 0.06], pos: [-5 + i * 1.6, -2.5, 0.1],
      quantities: [["Length", L]],
      psets: [{ name: "Pset_PipeSegmentCommon", props: { NominalDiameter: "DN50", SystemType: "Aguas negras" } }],
    });
  });
  const preL = [4.5, 3.8, 3.2, 2.6, 2.1, 1.8];
  preL.forEach((L, i) => {
    specs.push({
      cls: "IFCPIPESEGMENT", name: `Tubería agua potable AP-${i + 1}`, typeName: 'PVC presión 1/2" (DN15)',
      level: i % 2 === 0 ? "Nivel 1" : "Nivel 2", material: "PVC", tag: "AP-15", predefined: "NOTDEFINED",
      size: [L, 0.03, 0.03], pos: [-5 + i * 1.6, 2.0, 2.4],
      quantities: [["Length", L]],
      psets: [{ name: "Pset_PipeSegmentCommon", props: { NominalDiameter: "DN15", SystemType: "Agua potable" } }],
    });
  });
  const aparatos: [string, string][] = [
    ["Inodoro tanque bajo", "WATERCLOSET"], ["Inodoro tanque bajo", "WATERCLOSET"],
    ["Lavamanos pedestal", "WASHHANDBASIN"], ["Lavamanos pedestal", "WASHHANDBASIN"],
    ["Ducha", "SHOWER"], ["Lavaplatos", "SINK"],
  ];
  aparatos.forEach(([tipo, pre], i) => {
    specs.push({
      cls: "IFCSANITARYTERMINAL", name: `${tipo} (${i + 1})`, typeName: tipo,
      level: i % 2 === 0 ? "Nivel 1" : "Nivel 2", material: "Porcelana sanitaria", tag: "AS",
      predefined: pre, size: [0.6, 0.4, 0.8], pos: [-4 + i * 1.4, -3.6, 0],
      quantities: [["Count", 1]],
    });
  });
  return buildIfc("casa-x-hidrosanitaria", "CASA X — Hidrosanitaria", NIVELES, specs);
}

export function sampleElectrico(): string {
  const specs: Spec[] = [];
  const cabL = [12.5, 9.8, 8.4, 7.2, 6.5, 5.8];
  cabL.forEach((L, i) => {
    specs.push({
      cls: "IFCCABLESEGMENT", name: `Circuito CK-${i + 1}`, typeName: 'Canalización EMT 1/2" + cable THHN',
      level: i % 2 === 0 ? "Nivel 1" : "Nivel 2", material: "Cobre", tag: "CK", predefined: "NOTDEFINED",
      size: [L, 0.02, 0.02], pos: [-W / 2 + 0.5, -3 + i * 1.2, 2.6],
      quantities: [["Length", L]],
    });
  });
  for (let i = 0; i < 8; i++) {
    specs.push({
      cls: "IFCOUTLET", name: `Salida doble (${i + 1})`, typeName: "Salida doble 120V",
      level: i < 5 ? "Nivel 1" : "Nivel 2", tag: "SD", predefined: "OUTLET",
      size: [0.12, 0.05, 0.12], pos: [-5 + i * 1.3, -D / 2 + 0.2, 0.4],
      quantities: [["Count", 1]],
    });
  }
  for (let i = 0; i < 6; i++) {
    specs.push({
      cls: "IFCSWITCHINGDEVICE", name: `Interruptor (${i + 1})`, typeName: "Interruptor sencillo",
      level: i < 3 ? "Nivel 1" : "Nivel 2", tag: "INT", predefined: "SWITCH",
      size: [0.1, 0.04, 0.1], pos: [-4 + i * 1.6, 1.0, 1.2],
      quantities: [["Count", 1]],
    });
  }
  for (let i = 0; i < 4; i++) {
    specs.push({
      cls: "IFCLAMP", name: `Luminaria (${i + 1})`, typeName: "Luminaria empotrada LED",
      level: i < 2 ? "Nivel 1" : "Nivel 2", tag: "LUM", predefined: "POINTSOURCE",
      size: [0.3, 0.3, 0.08], pos: [-3 + i * 2.4, 0, H - 0.1],
      quantities: [["Count", 1]],
    });
  }
  return buildIfc("casa-x-electrico", "CASA X — Eléctrico", NIVELES, specs);
}

/* ------------------------------------------------------------------ */
export const DEMO_SOURCES: { name: string; discipline: string; file: string; build: () => string }[] = [
  { name: "IFC Arquitectura", discipline: "ARQUITECTURA", file: "casa-x-arquitectura.ifc", build: sampleArquitectura },
  { name: "IFC Estructura (sin cantidades IFC)", discipline: "ESTRUCTURA", file: "casa-x-estructura.ifc", build: sampleEstructura },
  { name: "IFC Hidrosanitaria", discipline: "HIDROSANITARIA", file: "casa-x-hidrosanitaria.ifc", build: sampleHidrosanitaria },
  { name: "IFC Eléctrico", discipline: "ELECTRICO", file: "casa-x-electrico.ifc", build: sampleElectrico },
];

export const DEMO_EXCEL_ROWS: { codigo: string; actividad: string; unidad: string; cantidad: number }[] = [
  { codigo: "01.01.001", actividad: "Limpieza, localización y trazado", unidad: "GLB", cantidad: 1 },
  { codigo: "01.01.002", actividad: "Cerramiento temporal de obra", unidad: "M", cantidad: 42.5 },
  { codigo: "01.01.003", actividad: "Excavación manual en material común", unidad: "M3", cantidad: 58.3 },
];
