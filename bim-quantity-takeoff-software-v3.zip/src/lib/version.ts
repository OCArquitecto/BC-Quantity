/* Versión visible de esta entrega. Incrementarla evita confundir imágenes
   antiguas de Docker con la interfaz recién descargada. */
export const BIMCOST_VERSION = "0.6.1";
export const BIMCOST_BUILD = "2026.09-exe-duplicados";
