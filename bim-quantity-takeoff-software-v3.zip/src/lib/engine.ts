/* ================================================================== */
/*  Motores de negocio de BIMCost Quantity                             */
/*  1. Agrupación BIM (criterios y clases elegidos por el profesional) */
/*  2. Correspondencias respetando la semántica BIM por clase IFC      */
/*  3. Medición por método + configuración profesional                 */
/* ================================================================== */

import type { ElementDimensions, MatchCandidate, MeasureConfig, MeasurementMethod } from "@/db/schema";

export interface WorkElement {
  id: string;
  sourceId: string;
  globalId: string | null;
  ifcClass: string;
  name: string | null;
  objectType: string | null;
  description: string | null;
  typeName: string | null;
  semanticType: string | null;
  material: string | null;
  level: string | null;
  layer: string | null;
  excluded: boolean;
  properties: Record<string, Record<string, string | number | boolean | null>> | null;
  quantities: Record<string, number> | null;
  dimensions: ElementDimensions | null;
}

/* ================================================================== */
/* SEMÁNTICA BIM: qué significa cada clase IFC                         */
/* Una familia agrupa clases equivalentes: un IfcWall SIEMPRE termina  */
/* en una actividad de muro, jamás en una de viga.                     */
/* ================================================================== */
export interface ClassFamily {
  family: string;
  label: string;
  /** Unidades habituales de medición para esa familia. */
  units: string[];
  /** Clases IFC equivalentes dentro de la familia. */
  classes: string[];
  /** ¿Suele entrar en un presupuesto de construcción? */
  presupuestable: boolean;
}

export const CLASS_FAMILIES: ClassFamily[] = [
  { family: "MURO", label: "Muros / mampostería / fachadas", units: ["M2", "M3", "M"], presupuestable: true,
    classes: ["IFCWALL", "IFCWALLSTANDARDCASE", "IFCWALLELEMENTEDCASE", "IFCCURTAINWALL"] },
  { family: "PLACA", label: "Losas / forjados / placas / cubiertas", units: ["M2", "M3"], presupuestable: true,
    classes: ["IFCSLAB", "IFCSLABSTANDARDCASE", "IFCROOF", "IFCPLATE"] },
  { family: "VIGA", label: "Vigas / dinteles", units: ["M3", "M", "M2", "KG"], presupuestable: true,
    classes: ["IFCBEAM", "IFCBEAMSTANDARDCASE"] },
  { family: "COLUMNA", label: "Columnas / pilares", units: ["M3", "M", "M2", "KG"], presupuestable: true,
    classes: ["IFCCOLUMN", "IFCCOLUMNSTANDARDCASE"] },
  { family: "CIMENTACION", label: "Cimentación / zapatas / pilotes", units: ["M3", "M2", "UND"], presupuestable: true,
    classes: ["IFCFOOTING", "IFCPILE"] },
  { family: "PUERTA", label: "Puertas", units: ["UND", "M2"], presupuestable: true,
    classes: ["IFCDOOR", "IFCDOORSTANDARDCASE"] },
  { family: "VENTANA", label: "Ventanas / vidriería", units: ["UND", "M2"], presupuestable: true,
    classes: ["IFCWINDOW", "IFCWINDOWSTANDARDCASE"] },
  { family: "ACABADO", label: "Recubrimientos / cielos / enchapes", units: ["M2"], presupuestable: true,
    classes: ["IFCCOVERING"] },
  { family: "ESCALERA", label: "Escaleras y rampas", units: ["UND", "M2", "M3"], presupuestable: true,
    classes: ["IFCSTAIR", "IFCSTAIRFLIGHT", "IFCRAMP", "IFCRAMPFLIGHT"] },
  { family: "BARANDA", label: "Barandas y pasamanos", units: ["M", "UND"], presupuestable: true,
    classes: ["IFCRAILING"] },
  { family: "TUBERIA", label: "Tuberías hidrosanitarias", units: ["M", "UND"], presupuestable: true,
    classes: ["IFCPIPESEGMENT", "IFCPIPEFITTING", "IFCFLOWSEGMENT", "IFCFLOWFITTING", "IFCVALVE"] },
  { family: "DUCTO", label: "Ductos mecánicos", units: ["M", "M2", "UND"], presupuestable: true,
    classes: ["IFCDUCTSEGMENT", "IFCDUCTFITTING"] },
  { family: "ELECTRICO", label: "Canalizaciones y cableado", units: ["M", "UND"], presupuestable: true,
    classes: ["IFCCABLESEGMENT", "IFCCABLECARRIERSEGMENT"] },
  { family: "APARATO_SANITARIO", label: "Aparatos sanitarios", units: ["UND"], presupuestable: true,
    classes: ["IFCSANITARYTERMINAL", "IFCFLOWTERMINAL"] },
  { family: "PUNTO_ELECTRICO", label: "Salidas, interruptores y luminarias", units: ["UND"], presupuestable: true,
    classes: ["IFCOUTLET", "IFCSWITCHINGDEVICE", "IFCLAMP", "IFCLIGHTFIXTURE", "IFCJUNCTIONBOX", "IFCELECTRICDISTRIBUTIONBOARD", "IFCELECTRICAPPLIANCE"] },
  { family: "REFUERZO", label: "Acero de refuerzo", units: ["KG", "M"], presupuestable: true,
    classes: ["IFCREINFORCINGBAR", "IFCREINFORCINGMESH"] },
  { family: "ESPACIO", label: "Espacios / ambientes (áreas de acabados)", units: ["M2", "M3"], presupuestable: true,
    classes: ["IFCSPACE"] },
  { family: "MOBILIARIO", label: "Mobiliario y dotación", units: ["UND"], presupuestable: false,
    classes: ["IFCFURNISHINGELEMENT", "IFCFURNITURE", "IFCSYSTEMFURNITUREELEMENT"] },
  { family: "VANO", label: "Vanos / aberturas (descuentos)", units: ["UND", "M2"], presupuestable: false,
    classes: ["IFCOPENINGELEMENT"] },
  { family: "GENERICO", label: "Elementos genéricos (proxy)", units: ["UND", "M2", "M3", "M"], presupuestable: true,
    classes: ["IFCBUILDINGELEMENTPROXY", "IFCMEMBER", "IFCCHIMNEY", "IFCSHADINGDEVICE"] },
];

const CLASS_TO_FAMILY = new Map<string, ClassFamily>();
for (const f of CLASS_FAMILIES) for (const c of f.classes) CLASS_TO_FAMILY.set(c, f);

export function familyOf(ifcClass: string): ClassFamily | null {
  return CLASS_TO_FAMILY.get(ifcClass.toUpperCase()) ?? null;
}

export function familyLabel(ifcClass: string): string {
  return familyOf(ifcClass)?.label ?? "Elemento sin familia definida";
}

/** Clases que normalmente NO entran en un presupuesto: se sugieren apagadas. */
export function defaultExcludedClasses(available: string[]): string[] {
  return available.filter((c) => {
    const f = familyOf(c);
    return f ? !f.presupuestable : false;
  });
}

/** ¿La actividad del catálogo es compatible con las clases del grupo? */
export function activityMatchesClasses(activityClasses: string[], groupClasses: string[]): boolean {
  if (!activityClasses.length) return false;
  const actFamilies = new Set(
    activityClasses.map((c) => familyOf(c)?.family ?? c.toUpperCase())
  );
  return groupClasses.every((gc) => actFamilies.has(familyOf(gc)?.family ?? gc.toUpperCase()));
}

/* ------------------------------------------------------------------ */
/* 1. AGRUPACIÓN                                                       */
/* ------------------------------------------------------------------ */
export const CRITERIA_DEFS: { key: string; label: string; hint: string }[] = [
  { key: "ifcClass", label: "Clase IFC", hint: "IfcWall, IfcSlab, IfcDoor…" },
  { key: "typeName", label: "Tipo de elemento", hint: "Tipo IFC del elemento" },
  { key: "material", label: "Material", hint: "Material asociado al elemento" },
  { key: "level", label: "Nivel", hint: "Nivel / planta del modelo" },
  { key: "layer", label: "Capa", hint: "Capa de presentación (si existe)" },
  { key: "thickness", label: "Espesor", hint: "Dimensiones / cantidades IFC" },
  { key: "height", label: "Altura", hint: "Dimensiones / cantidades IFC" },
  { key: "length", label: "Longitud", hint: "Dimensiones / cantidades IFC" },
  { key: "objectType", label: "ObjectType", hint: "Predefinido del elemento" },
];

function num(v: number | null | undefined): string | null {
  if (v === null || v === undefined || !isFinite(v)) return null;
  return String(Math.round(v * 1000) / 1000);
}

export function criterionValue(el: WorkElement, criterion: string): string {
  const d = el.dimensions ?? {};
  let raw: string | null = null;
  switch (criterion) {
    case "ifcClass": raw = el.ifcClass; break;
    case "typeName": raw = el.typeName; break;
    case "material": raw = el.material; break;
    case "level": raw = el.level; break;
    case "layer": raw = el.layer; break;
    case "objectType": raw = el.objectType; break;
    case "thickness": raw = num(d.thickness ?? d.width ?? null); break;
    case "height": raw = num(d.height ?? null); break;
    case "length": raw = num(d.length ?? null); break;
    default:
      if (criterion.startsWith("prop:")) {
        const key = criterion.slice(5);
        const short = key.split(".").pop();
        for (const [psetName, pset] of Object.entries(el.properties ?? {})) {
          const full = `${psetName}.${short}`;
          if (full === key && short && short in pset) {
            const v = pset[short];
            raw = v === null ? null : String(v);
            break;
          }
          if (short && short in pset) {
            const v = pset[short];
            raw = v === null ? null : String(v);
          }
        }
      }
  }
  return raw && raw.trim() !== "" ? raw.trim() : "(sin dato)";
}

export interface BuiltGroup {
  groupKey: string;
  criteriaValues: Record<string, string>;
  elementIds: string[];
  elementCount: number;
  ifcClasses: string[];
  semanticTypes: string[];
  sourceIds: string[];
  elements: WorkElement[];
}

export function buildGroups(
  elements: WorkElement[],
  criteria: string[],
  excludedClasses: string[] = []
): BuiltGroup[] {
  const excluded = new Set(excludedClasses.map((c) => c.toUpperCase()));
  const map = new Map<string, BuiltGroup>();
  for (const el of elements) {
    if (el.excluded) continue;
    if (excluded.has(el.ifcClass.toUpperCase())) continue;
    const values: Record<string, string> = {};
    for (const c of criteria) values[c] = criterionValue(el, c);
    const key = criteria.map((c) => values[c]).join(" ‖ ");
    let g = map.get(key);
    if (!g) {
      g = { groupKey: key, criteriaValues: values, elementIds: [], elementCount: 0, ifcClasses: [], semanticTypes: [], sourceIds: [], elements: [] };
      map.set(key, g);
    }
    g.elementIds.push(el.id);
    g.elementCount++;
    if (!g.ifcClasses.includes(el.ifcClass)) g.ifcClasses.push(el.ifcClass);
    if (el.semanticType && !g.semanticTypes.includes(el.semanticType)) g.semanticTypes.push(el.semanticType);
    if (!g.sourceIds.includes(el.sourceId)) g.sourceIds.push(el.sourceId);
    g.elements.push(el);
  }
  return [...map.values()].sort((a, b) => b.elementCount - a.elementCount);
}

/* ------------------------------------------------------------------ */
/* 2. CORRESPONDENCIAS                                                 */
/* ------------------------------------------------------------------ */
export function tokenize(text: string | null | undefined): string[] {
  if (!text) return [];
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/"([^"]*)"/g, " $1 ")
    .split(/[^a-z0-9]+/)
    .filter((t) => t.length >= 2);
}

function camelSplit(cls: string): string[] {
  return tokenize(cls.replace(/^IFC/i, "").replace(/([a-z])([A-Z])/g, "$1 $2"));
}

function tokensMatch(a: string, b: string): boolean {
  if (a === b) return true;
  if (a.length >= 4 && b.length >= 4) return a.startsWith(b) || b.startsWith(a);
  return false;
}

function overlap(tokens: string[], keywords: string[]): string[] {
  const found = new Set<string>();
  for (const t of tokens) for (const k of keywords) if (tokensMatch(t, k)) found.add(k);
  return [...found];
}

export interface CatalogLike {
  id: string;
  code: string;
  name: string;
  unit: string;
  method: string;
  keywords: string[];
  ifcClasses: string[];
  active: boolean;
  chapterCode?: string;
  sectionCode?: string;
}

export interface ProposalResult {
  activityId: string | null;
  score: number;
  status: "PENDIENTE" | "PROPUESTA";
  candidates: MatchCandidate[];
  evidence: Record<string, unknown>;
}

export const PROPOSAL_THRESHOLD = 55;

/**
 * Devuelve UNA sola propuesta por grupo (la mejor), con alternativas.
 * Así se evita duplicar cantidades: un grupo de puertas metálicas no puede
 * generar a la vez "puerta metálica" y "puerta de madera".
 */
export function proposeForGroup(group: BuiltGroup, catalog: CatalogLike[]): ProposalResult {
  const sample = group.elements.slice(0, 60);
  const classTokens = new Set<string>();
  const textTokens = new Set<string>();
  const materialTokens = new Set<string>();

  for (const cls of group.ifcClasses) for (const t of camelSplit(cls)) classTokens.add(t);
  for (const el of sample) {
    for (const t of tokenize(el.name)) textTokens.add(t);
    for (const t of tokenize(el.typeName)) textTokens.add(t);
    for (const t of tokenize(el.objectType)) textTokens.add(t);
    for (const t of tokenize(el.layer)) textTokens.add(t);
    for (const t of tokenize(el.description)) textTokens.add(t);
    for (const pset of Object.values(el.properties ?? {})) {
      for (const v of Object.values(pset)) {
        if (typeof v === "string") for (const t of tokenize(v)) textTokens.add(t);
      }
    }
    for (const t of tokenize(el.material)) materialTokens.add(t);
  }

  const families = group.semanticTypes.includes("MIEMBRO_LINEAL_CUBIERTA")
    ? ["Vigas / cabios / pares / correas de cubierta"]
    : [...new Set(group.ifcClasses.map((c) => familyOf(c)?.label ?? c))];

  const scored = catalog
    .filter((a) => a.active)
    .map((a) => {
      const semanticLinear = group.semanticTypes.includes("MIEMBRO_LINEAL_CUBIERTA");
      const activityFamilies = new Set(a.ifcClasses.map((c) => familyOf(c)?.family ?? c));
      const classOk = semanticLinear
        ? activityFamilies.has("VIGA") || a.keywords.some((k) => /viga|cabio|correa|par|madera/.test(k))
        : activityMatchesClasses(a.ifcClasses, group.ifcClasses);
      const matched: string[] = [];
      let score = 0;

      if (classOk) {
        score += 45;
        matched.push(group.semanticTypes.includes("MIEMBRO_LINEAL_CUBIERTA")
          ? "semántica Archicad/RoofMaker: miembro lineal de cubierta"
          : `clase IFC compatible (${group.ifcClasses.join(", ")})`);
      }

      const matHit = overlap([...materialTokens], a.keywords);
      if (matHit.length) { score += 18; matched.push(`material: ${matHit.join(", ")}`); }

      const tokHit = overlap([...textTokens], a.keywords);
      const tokPoints = Math.min(tokHit.length, 6) * 9;
      if (tokPoints) { score += tokPoints; matched.push(`texto del modelo: ${tokHit.join(", ")}`); }

      // Conflicto de diámetro/designación numérica (DN50 vs DN15, e=12 vs e=15…):
      // evita que una tubería de presión se proponga como sanitaria.
      const actSpecs = a.keywords.filter((k) => /^(dn|d)\d+$/.test(k));
      const elemSpecs = [...textTokens].filter((t) => /^(dn|d)\d+$/.test(t));
      if (actSpecs.length && elemSpecs.length && !actSpecs.some((s) => elemSpecs.includes(s))) {
        score -= 28;
        matched.push(`⚠ designación distinta (${actSpecs.join("/")} vs ${elemSpecs.join("/")})`);
      }

      const clsHit = overlap([...classTokens], a.keywords);
      if (clsHit.length && !tokHit.length) { score += 6; matched.push(`nombre de clase: ${clsHit.join(", ")}`); }

      // Coherencia de unidad con la familia BIM
      const fam = group.semanticTypes.includes("MIEMBRO_LINEAL_CUBIERTA")
        ? CLASS_FAMILIES.find((f) => f.family === "VIGA") ?? null
        : familyOf(group.ifcClasses[0] ?? "");
      if (fam && fam.units.includes(a.unit)) { score += 6; matched.push(`unidad habitual (${a.unit})`); }
      if (group.semanticTypes.includes("MIEMBRO_LINEAL_CUBIERTA") && a.unit === "M") {
        score += 18;
        matched.push("medición constructiva por longitud");
      }

      // Sin compatibilidad de clase: no puede ser propuesta automática
      if (!classOk) score = Math.min(score, 30);

      return { activity: a, score, matched, classOk };
    })
    .filter((r) => r.score > 0)
    .sort((x, y) => (Number(y.classOk) - Number(x.classOk)) || y.score - x.score)
    .slice(0, 6);

  const candidates: MatchCandidate[] = scored.map((s) => ({
    activityId: s.activity.id,
    code: s.activity.code,
    name: s.activity.name,
    unit: s.activity.unit,
    method: s.activity.method,
    score: s.score,
    matched: s.matched,
    classOk: s.classOk,
  }));

  const best = scored[0];
  const viable = best && best.classOk && best.score >= PROPOSAL_THRESHOLD;

  // ¿Hay empate cercano? Se advierte para que el profesional decida.
  const second = scored[1];
  const ambiguo = !!(viable && second && second.classOk && best.score - second.score <= 8);

  return {
    activityId: viable ? best.activity.id : null,
    score: best?.score ?? 0,
    status: viable ? "PROPUESTA" : "PENDIENTE",
    candidates,
    evidence: {
      clases: group.ifcClasses,
      familiaBIM: families,
      materiales: [...new Set(sample.map((e) => e.material).filter(Boolean))],
      niveles: [...new Set(sample.map((e) => e.level).filter(Boolean))],
      coincidencias: best?.matched ?? [],
      umbral_propuesta: PROPOSAL_THRESHOLD,
      ambiguo,
      semanticTypes: group.semanticTypes,
      reglaBIM: group.semanticTypes.includes("MIEMBRO_LINEAL_CUBIERTA")
        ? "Elemento RoofMaker/Archicad reconocido como miembro lineal de cubierta: se propone actividad de viga/cabio/correa y medición por longitud."
        : `Las clases ${group.ifcClasses.join(", ")} pertenecen a: ${families.join(" / ")}. Solo se proponen actividades de esa familia.`, 
      sinCandidatoCompatible: !best?.classOk,
    },
  };
}

/* ------------------------------------------------------------------ */
/* 3. MEDICIÓN                                                         */
/* ------------------------------------------------------------------ */
export interface MeasureResult {
  value: number | null;
  rule: string;
  fields: Record<string, number>;
  missing: number;
  measuredCount: number;
  missingElements: string[];
}

export const AREA_BASIS_LABEL: Record<string, string> = {
  NETA: "Área neta (descontando vanos si el modelo los reporta)",
  BRUTA: "Área bruta (sin descuentos)",
  UNA_CARA: "Una sola cara del elemento",
  DOS_CARAS: "Ambas caras del elemento (×2)",
  LATERAL: "Superficie lateral (perímetro × longitud)",
  PLANTA: "Área en planta (proyección horizontal)",
  SUPERFICIE_TOTAL: "Superficie total envolvente",
};

export const DIMENSION_LABEL: Record<string, string> = {
  LARGO: "Longitud del elemento",
  ALTO: "Altura del elemento",
  ANCHO: "Ancho del elemento",
  ESPESOR: "Espesor del elemento",
  PERIMETRO: "Perímetro del elemento",
};

function pick(...vals: (number | null | undefined)[]): number | null {
  for (const v of vals) if (v !== null && v !== undefined && isFinite(v) && v !== 0) return v;
  return null;
}

/** Mide un conjunto de elementos con el método y la configuración dados. */
export function measureElements(
  elements: WorkElement[],
  method: MeasurementMethod | string,
  config?: MeasureConfig | null
): MeasureResult {
  const fields: Record<string, number> = {};
  const missingElements: string[] = [];
  let total = 0;
  let missing = 0;
  let measured = 0;

  const cfg = config ?? {};
  const factor = cfg.factor && isFinite(cfg.factor) && cfg.factor > 0 ? cfg.factor : 1;
  const bump = (label: string) => { fields[label] = (fields[label] ?? 0) + 1; };

  if (method === "MANUAL") {
    return {
      value: null,
      rule: "Medición manual introducida por el profesional. El valor no proviene del modelo BIM.",
      fields: {}, missing: 0, measuredCount: 0, missingElements: [],
    };
  }

  for (const el of elements) {
    const d = (el.dimensions ?? {}) as ElementDimensions;
    let v: number | null = null;
    let label = "";

    switch (method) {
      case "COUNT":
      case "COMPONENTES":
        v = 1;
        label = method === "COUNT" ? "Conteo directo de elementos" : "Conteo de componentes";
        break;

      case "DIMENSION": {
        switch (cfg.dimension) {
          case "ALTO": v = pick(d.height); label = "Altura"; break;
          case "ANCHO": v = pick(d.width); label = "Ancho"; break;
          case "ESPESOR": v = pick(d.thickness, d.width); label = "Espesor"; break;
          case "PERIMETRO": v = pick(d.perimeter); label = "Perímetro"; break;
          default: v = pick(d.length); label = "Longitud"; break;
        }
        break;
      }

      case "SUPERFICIE_GEOMETRICA": {
        switch (cfg.areaBasis) {
          case "BRUTA":
            v = pick(d.grossArea, d.area, d.netArea);
            label = "Área bruta";
            break;
          case "DOS_CARAS":
            v = pick(d.netArea, d.area, d.grossArea);
            if (v !== null) v *= 2;
            label = "Área × 2 caras";
            break;
          case "LATERAL": {
            const per = pick(d.perimeter);
            const len = pick(d.length, d.height);
            v = per !== null && len !== null ? per * len : pick(d.surfaceArea);
            label = per !== null && len !== null ? "Perímetro × longitud" : "Superficie envolvente";
            break;
          }
          case "PLANTA":
            v = pick(d.area, d.netArea, d.grossArea);
            label = "Área en planta";
            break;
          case "SUPERFICIE_TOTAL":
            v = pick(d.surfaceArea, d.grossArea, d.area);
            label = "Superficie total";
            break;
          case "UNA_CARA":
          case "NETA":
          default:
            v = pick(d.netArea, d.area, d.grossArea);
            label = "Área neta";
            break;
        }
        if (v === null) {
          const l = pick(d.length), h = pick(d.height);
          if (l !== null && h !== null) { v = l * h; label = "Derivada: largo × alto"; }
        }
        break;
      }

      case "VOLUMEN_GEOMETRICO": {
        v = cfg.volumeBasis === "BRUTO" ? pick(d.volume, d.netVolume) : pick(d.netVolume, d.volume);
        label = cfg.volumeBasis === "BRUTO" ? "Volumen bruto" : "Volumen neto";
        if (v === null) {
          const a = pick(d.netArea, d.area, d.grossArea);
          const t = pick(d.thickness, d.width);
          if (a !== null && t !== null) { v = a * t; label = "Derivado: área × espesor"; }
        }
        if (v === null) {
          const csa = pick(d.crossSectionArea), len = pick(d.length);
          if (csa !== null && len !== null) { v = csa * len; label = "Derivado: sección × longitud"; }
        }
        break;
      }

      case "CANTIDAD_IFC":
      default: {
        v = pick(d.netArea, d.grossArea, d.netVolume, d.volume, d.length, d.count);
        label = "Primera cantidad IFC disponible";
        break;
      }
    }

    if (v === null || !isFinite(v)) {
      missing++;
      if (missingElements.length < 25) missingElements.push(el.name ?? el.globalId ?? el.id);
    } else {
      total += v * factor;
      measured++;
      bump(label);
    }
  }

  const parts: string[] = [];
  if (method === "SUPERFICIE_GEOMETRICA") parts.push(AREA_BASIS_LABEL[cfg.areaBasis ?? "NETA"]);
  if (method === "DIMENSION") parts.push(DIMENSION_LABEL[cfg.dimension ?? "LARGO"]);
  if (method === "VOLUMEN_GEOMETRICO") parts.push(cfg.volumeBasis === "BRUTO" ? "Volumen bruto" : "Volumen neto");
  if (method === "COUNT" || method === "COMPONENTES") parts.push("Una unidad por elemento seleccionado");
  if (method === "CANTIDAD_IFC") parts.push("Cantidad IFC declarada en el modelo");
  if (factor !== 1) parts.push(`factor aplicado ×${factor}`);
  parts.push("Preferencia: cantidad IFC declarada; si no existe, se deriva de la geometría del modelo");

  return {
    value: Math.round(total * 1000) / 1000,
    rule: parts.join(". ") + ".",
    fields,
    missing,
    measuredCount: measured,
    missingElements,
  };
}

/** Configuración de medición sugerida según el método y la familia BIM. */
export function defaultConfigFor(method: string, ifcClasses: string[]): MeasureConfig {
  const fam = familyOf(ifcClasses[0] ?? "")?.family;
  if (method === "SUPERFICIE_GEOMETRICA") {
    if (fam === "MURO") return { areaBasis: "UNA_CARA", factor: 1 };
    if (fam === "PLACA") return { areaBasis: "PLANTA", factor: 1 };
    if (fam === "VIGA" || fam === "COLUMNA") return { areaBasis: "LATERAL", factor: 1 };
    return { areaBasis: "NETA", factor: 1 };
  }
  if (method === "VOLUMEN_GEOMETRICO") return { volumeBasis: "NETO", factor: 1 };
  if (method === "DIMENSION") return { dimension: "LARGO", factor: 1 };
  return { factor: 1 };
}
