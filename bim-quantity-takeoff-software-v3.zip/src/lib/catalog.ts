/* ================================================================== */
/*  Catálogo maestro — infraestructura, NO contenido                   */
/*  BIMCost Quantity se instala sin actividades ni precios internos.  */
/*  Cada empresa importa su catálogo desde Excel o lo recibe de        */
/*  BC Budget. Este módulo solo mantiene capítulos y subcapítulos.     */
/* ================================================================== */
import { db } from "@/db";
import { catalogActivities, catalogGroups } from "@/db/schema";

/**
 * Conserva el nombre histórico para no alterar rutas ya estables.
 * NO siembra actividades: una instalación nueva comienza con catálogo vacío.
 */
export async function ensureCatalogSeeded(): Promise<void> {
  await syncCatalogGroups();
}

/**
 * Crea las filas de capítulos y secciones que falten para un catálogo ya
 * importado. Es idempotente y nunca reactiva lo que el profesional apagó.
 */
export async function syncCatalogGroups(): Promise<void> {
  const acts = await db.select().from(catalogActivities);
  if (!acts.length) return;
  const existing = await db.select().from(catalogGroups);
  const have = new Set(existing.map((g) => `${g.kind}:${g.code}`));

  const chapters = new Map<string, string>();
  const sections = new Map<string, { name: string; parent: string }>();
  for (const a of acts) {
    if (!chapters.has(a.chapterCode)) chapters.set(a.chapterCode, a.chapterName);
    if (!sections.has(a.sectionCode)) sections.set(a.sectionCode, { name: a.sectionName, parent: a.chapterCode });
  }

  const pending: (typeof catalogGroups.$inferInsert)[] = [];
  for (const [code, name] of chapters) {
    if (have.has(`CAPITULO:${code}`)) continue;
    pending.push({
      kind: "CAPITULO", code, name, parentCode: null, active: true,
      sortOrder: parseInt(code.replace(/\D/g, "").slice(0, 4) || "0", 10) || 0,
    });
  }
  for (const [code, info] of sections) {
    if (have.has(`SECCION:${code}`)) continue;
    pending.push({
      kind: "SECCION", code, name: info.name, parentCode: info.parent, active: true,
      sortOrder: parseInt((code.split(".")[1] ?? "0").replace(/\D/g, "") || "0", 10) || 0,
    });
  }
  const BATCH = 200;
  for (let i = 0; i < pending.length; i += BATCH) {
    const slice = pending.slice(i, i + BATCH);
    if (slice.length) await db.insert(catalogGroups).values(slice);
  }
}
