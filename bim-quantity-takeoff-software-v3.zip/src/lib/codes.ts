/* ================================================================== */
/*  Códigos jerárquicos del catálogo y del presupuesto                 */
/*  Estructura: 1 → capítulo · 1.1 → subcapítulo · 1.1.1 → actividad   */
/*  El orden debe ser NUMÉRICO por segmento: 1, 2, … 9, 10, 11         */
/*  (nunca alfabético: 1, 10, 11, 2…).                                 */
/* ================================================================== */

/** Divide un código en segmentos comparables. */
export function codeSegments(code: string): (number | string)[] {
  return String(code ?? "")
    .trim()
    .split(/[.\-_/]/)
    .filter((s) => s.length > 0)
    .map((s) => {
      const n = Number(s);
      return Number.isFinite(n) && /^\d+$/.test(s) ? n : s.toUpperCase();
    });
}

/**
 * Compara dos códigos jerárquicos segmento a segmento.
 * Los segmentos numéricos se comparan como números; los alfanuméricos,
 * como texto. Un código más corto precede a su descendiente (1 antes de 1.1).
 */
export function compareCodes(a: string, b: string): number {
  const sa = codeSegments(a);
  const sb = codeSegments(b);
  const n = Math.max(sa.length, sb.length);
  for (let i = 0; i < n; i++) {
    const x = sa[i];
    const y = sb[i];
    if (x === undefined) return -1;
    if (y === undefined) return 1;
    if (typeof x === "number" && typeof y === "number") {
      if (x !== y) return x - y;
    } else {
      const xs = String(x);
      const ys = String(y);
      // Comparación natural para segmentos mixtos (A1, A2, A10)
      const cmp = xs.localeCompare(ys, "es", { numeric: true, sensitivity: "base" });
      if (cmp !== 0) return cmp;
    }
  }
  return 0;
}

/** Ordena una lista por un código jerárquico. */
export function sortByCode<T>(items: T[], getCode: (item: T) => string): T[] {
  return [...items].sort((a, b) => compareCodes(getCode(a), getCode(b)));
}

/** Clave ordenable en SQL/JS: cada segmento numérico se rellena con ceros. */
export function codeSortKey(code: string, width = 6): string {
  return codeSegments(code)
    .map((s) => (typeof s === "number" ? String(s).padStart(width, "0") : `~${String(s)}`))
    .join(".");
}

/** Nivel jerárquico: 1 = capítulo, 2 = subcapítulo, 3+ = actividad. */
export function codeDepth(code: string): number {
  return codeSegments(code).length;
}

/** Código del padre (1.2.3 → 1.2). Devuelve null para los capítulos. */
export function parentCode(code: string): string | null {
  const parts = String(code ?? "").trim().split(/[.\-_/]/).filter(Boolean);
  if (parts.length <= 1) return null;
  return parts.slice(0, -1).join(".");
}

/** Capítulo y subcapítulo de un código de actividad. */
export function splitHierarchy(code: string): { chapter: string; section: string } {
  const parts = String(code ?? "").trim().split(/[.\-_/]/).filter(Boolean);
  if (parts.length >= 2) return { chapter: parts[0], section: `${parts[0]}.${parts[1]}` };
  const c = parts[0] ?? "00";
  return { chapter: c, section: `${c}.01` };
}

/**
 * Sugiere el siguiente código libre dentro de un padre.
 * Ej.: padre "1.2" con hijos 1.2.1 … 1.2.9 → "1.2.10".
 */
export function nextFreeCode(parent: string, existing: string[]): string {
  const prefix = parent ? `${parent}.` : "";
  const used = existing
    .filter((c) => c.startsWith(prefix) && codeDepth(c) === codeDepth(parent) + 1)
    .map((c) => {
      const last = codeSegments(c)[codeDepth(parent)];
      return typeof last === "number" ? last : 0;
    });
  const next = used.length ? Math.max(...used) + 1 : 1;
  return `${prefix}${next}`;
}
