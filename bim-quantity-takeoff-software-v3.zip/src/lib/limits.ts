/* ==================================================================== */
/*  Límites de tamaño de archivo, configurables por variable de entorno */
/*  sin tener que tocar código ni recompilar.                           */
/* ==================================================================== */

function envMB(name: string, fallbackMB: number): number {
  const raw = process.env[name];
  const n = raw ? Number(raw) : NaN;
  return Number.isFinite(n) && n > 0 ? n : fallbackMB;
}

/** Tamaño máximo aceptado para modelos IFC (por defecto 500 MB). */
export const MAX_IFC_MB = envMB("BIMCOST_MAX_IFC_MB", 500);

/** Tamaño máximo aceptado para hojas de cálculo (Excel de cantidades, por defecto 30 MB). */
export const MAX_EXCEL_MB = envMB("BIMCOST_MAX_EXCEL_MB", 30);

/** Tamaño máximo aceptado para el Excel del catálogo maestro (por defecto 30 MB). */
export const MAX_CATALOG_MB = envMB("BIMCOST_MAX_CATALOG_MB", 30);

export const toBytes = (mb: number) => mb * 1024 * 1024;

export function tooLargeMessage(maxMB: number): string {
  return `Archivo demasiado grande (máx. ${maxMB} MB). Puede ampliar este límite con la variable de entorno correspondiente (ver LEEME.md).`;
}
