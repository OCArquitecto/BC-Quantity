/* ================================================================== */
/*  Integración con BIMCost Desktop (Electron)                         */
/*  En el navegador estas funciones devuelven null y la aplicación     */
/*  sigue funcionando con la carga de archivos tradicional.            */
/* ================================================================== */

export interface DesktopPickedFile {
  path: string;
  name: string;
  sizeMB?: number;
}

interface DesktopBridge {
  isDesktop: boolean;
  pickIfc: () => Promise<DesktopPickedFile[]>;
  pickExcel: () => Promise<DesktopPickedFile | null>;
  importIfc: (args: {
    projectId: string; path: string; name: string; discipline: string;
    actor?: string; unitScale?: string;
  }) => Promise<{ elementos: number; source: unknown }>;
  info: () => Promise<{ version: string; desktop: boolean; platform: string }>;
  onOpenIfc: (cb: () => void) => void;
}

function bridge(): DesktopBridge | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as { bimcost?: DesktopBridge };
  return w.bimcost ?? null;
}

/** ¿La aplicación se está ejecutando dentro de BIMCost Desktop? */
export function isDesktop(): boolean {
  return !!bridge()?.isDesktop;
}

/** Abre el diálogo nativo para elegir modelos IFC (por ruta, sin subirlos). */
export async function pickIfcFiles(): Promise<DesktopPickedFile[]> {
  const b = bridge();
  if (!b) return [];
  try {
    return await b.pickIfc();
  } catch {
    return [];
  }
}

/** Abre el diálogo nativo para elegir una hoja de cálculo. */
export async function pickExcelFile(): Promise<DesktopPickedFile | null> {
  const b = bridge();
  if (!b) return null;
  try {
    return await b.pickExcel();
  } catch {
    return null;
  }
}

/** Transmite un IFC desde el disco al backend sin pasar por la memoria del renderer. */
export async function importIfcDesktop(args: {
  projectId: string; path: string; name: string; discipline: string;
  actor?: string; unitScale?: string;
}): Promise<{ elementos: number; source: unknown }> {
  const b = bridge();
  if (!b) throw new Error("Esta función requiere BIMCost Desktop.");
  return await b.importIfc(args);
}

/** Suscribe el menú Archivo → Abrir modelo IFC. */
export function onDesktopOpenIfc(cb: () => void): void {
  bridge()?.onOpenIfc(cb);
}
