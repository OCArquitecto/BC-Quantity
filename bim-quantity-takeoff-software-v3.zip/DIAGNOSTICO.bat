@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
title BIMCost Quantity - Diagnostico
color 0F

set "LOG_FILE=%~dp0BIMCost-DIAGNOSTICO.txt"

echo ================================================================
echo             BIMCost Quantity - Diagnostico
echo ================================================================
echo.
echo Este proceso no borra ni modifica tus datos.
echo Creara BIMCost-DIAGNOSTICO.txt en esta misma carpeta.
echo.

(
  echo ================================================================
  echo BIMCost Quantity - Reporte de diagnostico
  echo Fecha: %date% %time%
  echo Carpeta: %cd%
  echo ================================================================
  echo.
  echo --- Archivos requeridos ---
  if exist docker-compose.yml (echo OK docker-compose.yml) else (echo FALTA docker-compose.yml)
  if exist Dockerfile (echo OK Dockerfile) else (echo FALTA Dockerfile)
  if exist package.json (echo OK package.json) else (echo FALTA package.json)
  if exist src (echo OK carpeta src) else (echo FALTA carpeta src)
  echo.
  echo --- Windows y virtualizacion ---
  ver
  systeminfo
  echo.
  echo --- WSL ---
  wsl.exe --status
  wsl.exe --version
  wsl.exe --list --verbose
  echo.
  echo --- Docker disponible en PATH ---
  where docker
  echo.
  echo --- Version de Docker ---
  docker version
  echo.
  echo --- Informacion del motor Docker ---
  docker info
  echo.
  echo --- Docker Compose ---
  docker compose version
  echo.
  echo --- Validacion de docker-compose.yml ---
  docker compose config
  echo.
  echo --- Estado de contenedores BIMCost ---
  docker compose ps -a
  echo.
  echo --- Ultimos registros de BIMCost ---
  docker compose logs --no-color --tail 300
  echo.
  echo --- Programas escuchando en el puerto 3000 ---
  netstat -ano ^| findstr ":3000"
) > "%LOG_FILE%" 2>&1

echo Comprobaciones rapidas:
echo.

set "FILES_OK=1"
if not exist docker-compose.yml set "FILES_OK=0"
if not exist Dockerfile set "FILES_OK=0"
if not exist package.json set "FILES_OK=0"
if "!FILES_OK!"=="1" (echo [OK] Los archivos principales estan juntos.) else (echo [X] Faltan archivos: vuelve a descomprimir el ZIP completo.)

where docker >nul 2>nul
if errorlevel 1 (
  echo [X] Windows no encuentra Docker. Reinicia el PC despues de instalarlo.
) else (
  echo [OK] Windows encuentra el comando Docker.
)

docker info >nul 2>nul
if errorlevel 1 (
  echo [X] El motor de Docker no esta funcionando. Abre Docker Desktop.
  echo     Si Docker muestra un error de WSL, reinicia Windows o actualiza WSL.
) else (
  echo [OK] El motor de Docker esta funcionando.
)

docker compose config --quiet >nul 2>nul
if errorlevel 1 (
  echo [X] Docker Compose no puede leer los archivos del proyecto.
) else (
  echo [OK] La configuracion de BIMCost es valida.
)

curl.exe -fsS "http://localhost:3000/api/health" >nul 2>nul
if errorlevel 1 (
  echo [X] BIMCost no responde en http://localhost:3000.
) else (
  echo [OK] BIMCost esta respondiendo correctamente.
)

echo.
echo Reporte guardado en:
echo %LOG_FILE%
echo.
echo Si necesitas ayuda, comparte el archivo BIMCost-DIAGNOSTICO.txt.
echo No contiene tus proyectos ni tus cantidades.
echo.
pause
