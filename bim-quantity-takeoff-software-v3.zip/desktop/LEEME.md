# BIMCost Quantity — Aplicación de escritorio

Versión instalable del módulo **BC Quantity**, primer programa del ecosistema BIMCost.
No depende de la memoria del navegador: admite modelos IFC grandes leídos directamente del disco.

---

## Qué aporta frente al navegador

| Aspecto | Navegador | BIMCost Desktop |
|---|---|---|
| Modelos IFC grandes | Limitado por la memoria de la pestaña | Lee del disco por ruta, con 8 GB de memoria disponibles |
| Selección de archivos | Subida por formulario | Diálogo nativo (Archivo → Abrir modelo IFC, o Ctrl+O) |
| Arranque | Requiere iniciar el servidor a mano | Un icono en el escritorio |
| Ecosistema | — | Menú preparado para BC Budget y BC Planning |

---

## Requisitos

1. **Node.js 20 o superior** (solo para construir el instalador).
2. **PostgreSQL** accesible. La cadena de conexión se toma del archivo `.env`
   de la carpeta raíz del proyecto, que se empaqueta junto a la aplicación:

   ```
   DATABASE_URL=postgresql://usuario:clave@127.0.0.1:5432/app_db
   ```

---

## Construir el instalador

Desde la **carpeta raíz** del proyecto:

```bash
npm install
BIMCOST_DESKTOP_BUILD=1 npm run build
```

En Windows (PowerShell):

```powershell
$env:BIMCOST_DESKTOP_BUILD=1; npm run build
```

Después, dentro de `desktop/`:

```bash
cd desktop
npm install
npm run dist:win     # Windows  → .exe instalador
npm run dist:mac     # macOS    → .dmg
npm run dist:linux   # Linux    → AppImage y .deb
```

El instalador queda en la carpeta `dist-desktop/`.

---

## Probar sin empaquetar

```bash
BIMCOST_DESKTOP_BUILD=1 npm run build   # en la raíz
cd desktop && npm install && npm start
```

---

## Cómo funciona

1. Electron arranca el servidor Next.js autónomo (`.next/standalone/server.js`)
   en `127.0.0.1:4317`, con `--max-old-space-size=8192`.
2. Espera a que `/api/health` responda y abre la ventana nativa.
3. El menú **Archivo → Abrir modelo IFC** usa el diálogo del sistema y envía
   solo la **ruta** del archivo a `/api/projects/[id]/sources/local`,
   que lo lee con `fs` en el servidor. El archivo nunca pasa por la memoria
   del navegador.
4. Al cerrar la ventana se detiene el servidor interno.

---

## Preparado para el ecosistema

- La base de datos es compartida: **BC Budget** podrá leer las cantidades
  validadas por BC Quantity y escribir los precios unitarios del catálogo maestro.
- El contrato de exportación ya existe: `formato: "BIMCost-Quantity/BC-Budget@1"`
  (pestaña Trazabilidad → Exportar JSON).
- El menú «Ecosistema BIMCost» reserva las entradas de BC Budget y BC Planning.
