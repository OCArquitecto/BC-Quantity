@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title BIMCost Quantity - Actualizar v0.6.0

echo ================================================================
echo          BIMCost Quantity - Actualizacion completa v0.6.0
 echo ================================================================
echo.
echo Esta operacion NO borra proyectos ni cantidades.
echo Reconstruira la aplicacion sin usar cache de versiones anteriores.
echo.

where docker >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Docker Desktop no esta disponible.
  pause
  exit /b 1
)

docker info >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Abre Docker Desktop y espera "Engine running".
  pause
  exit /b 1
)

echo [1/4] Deteniendo la interfaz anterior...
docker compose down

echo [2/4] Descargando imagenes base actualizadas...
docker compose pull db

echo [3/4] Reconstruyendo BIMCost Quantity SIN CACHE...
docker compose build --no-cache --pull app
if errorlevel 1 goto :failed

echo [4/4] Iniciando la version nueva...
docker compose up -d
if errorlevel 1 goto :failed

set /a n=0
:wait
for /f "delims=" %%V in ('curl.exe -fsS http://localhost:3000/api/health 2^>nul') do set "HEALTH=%%V"
if defined HEALTH goto :ready
set /a n+=1
if %n% GEQ 90 goto :failed
timeout /t 2 /nobreak >nul
goto :wait

:ready
echo.
echo Version activa:
echo %HEALTH%
echo.
echo Abriendo BIMCost Desktop (ventana nativa)...
call "%~dp0ABRIR-ESCRITORIO.bat"
exit /b 0

:failed
echo.
echo [ERROR] No se pudo completar la actualizacion.
echo Ejecuta DIAGNOSTICO.bat para obtener el detalle.
pause
exit /b 1
