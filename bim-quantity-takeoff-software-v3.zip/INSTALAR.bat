@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
title BIMCost Quantity - Instalador sencillo
color 0F

set "APP_URL=http://localhost:3000"
set "LOG_FILE=%~dp0BIMCost-DIAGNOSTICO.txt"

echo ================================================================
echo              BIMCost Quantity - Inicio sencillo
echo ================================================================
echo.
echo IMPORTANTE: Para este metodo solo se usa Docker Desktop.
echo Node.js y PostgreSQL instalados en Windows no necesitan configurarse.
echo Docker crea versiones privadas de ambos dentro de contenedores.
echo.

rem -----------------------------------------------------------------
rem 1. Verificar que los archivos se encuentran juntos
rem -----------------------------------------------------------------
if not exist "%~dp0docker-compose.yml" goto :missingFiles
if not exist "%~dp0Dockerfile" goto :missingFiles
if not exist "%~dp0package.json" goto :missingFiles

echo [1/5] Comprobando Docker Desktop...
where docker >nul 2>nul
if errorlevel 1 goto :dockerNotInstalled

docker compose version >nul 2>nul
if errorlevel 1 goto :composeMissing

rem -----------------------------------------------------------------
rem 2. Si el motor no esta listo, intentar abrir Docker Desktop
rem -----------------------------------------------------------------
docker info >nul 2>nul
if not errorlevel 1 goto :dockerReady

echo       Docker esta instalado, pero todavia no esta activo.
echo       Intentando abrir Docker Desktop...

if exist "%ProgramFiles%\Docker\Docker\Docker Desktop.exe" (
  start "" "%ProgramFiles%\Docker\Docker\Docker Desktop.exe"
) else if exist "%LocalAppData%\Docker\Docker Desktop.exe" (
  start "" "%LocalAppData%\Docker\Docker Desktop.exe"
) else (
  echo       Abre Docker Desktop manualmente desde el menu Inicio.
)

echo       Esperando a que el motor de Docker quede listo.
echo       Esto puede tardar hasta 2 minutos la primera vez...
set /a WAIT_COUNT=0
:waitDocker
docker info >nul 2>nul
if not errorlevel 1 goto :dockerReady
set /a WAIT_COUNT+=1
if !WAIT_COUNT! GEQ 60 goto :dockerNotRunning
<nul set /p="."
timeout /t 2 /nobreak >nul
goto :waitDocker

:dockerReady
echo       OK - Docker Desktop esta funcionando.
echo.

rem -----------------------------------------------------------------
rem 3. Si BIMCost ya esta encendido, no volver a construirlo
rem -----------------------------------------------------------------
for /f "delims=" %%S in ('docker inspect -f "{{.State.Running}}" bimcost-app 2^>nul') do set "APP_RUNNING=%%S"
if /i "!APP_RUNNING!"=="true" (
  echo [2/5] BIMCost Quantity ya estaba encendido.
  echo [3/5] Base de datos privada ya disponible.
  echo [4/5] Aplicacion disponible.
  goto :waitApp
)

rem -----------------------------------------------------------------
rem 4. Construir y levantar aplicacion + base privada
rem -----------------------------------------------------------------
echo [2/5] Preparando la base de datos privada PostgreSQL...
echo [3/5] Construyendo BIMCost Quantity...
echo.
echo       La PRIMERA VEZ puede tardar entre 5 y 15 minutos.
echo       Docker debe descargar varios componentes de Internet.
echo       No cierres esta ventana aunque parezca detenida.
echo.

if exist "%LOG_FILE%" del /q "%LOG_FILE%" >nul 2>nul
rem --no-cache evita que Docker conserve una interfaz de una descarga anterior.
call docker compose build --no-cache --pull app
if errorlevel 1 goto :composeFailed
call docker compose up -d
if errorlevel 1 goto :composeFailed

echo.
echo [4/5] Contenedores creados correctamente (version 0.6.0).

rem -----------------------------------------------------------------
rem 5. Esperar al servidor web antes de abrir el navegador
rem -----------------------------------------------------------------
:waitApp
echo [5/5] Esperando a que la aplicacion responda...
set /a APP_WAIT=0
:waitHealth
curl.exe -fsS "%APP_URL%/api/health" >nul 2>nul
if not errorlevel 1 goto :success
set /a APP_WAIT+=1
if !APP_WAIT! GEQ 60 goto :appFailed
timeout /t 2 /nobreak >nul
goto :waitHealth

:success
color 0A
echo.
echo ================================================================
echo   LISTO - BIMCost Quantity esta funcionando
echo ================================================================
echo.
echo   Version: v0.6.0
echo   Backend: %APP_URL%
echo.
echo   Abrir escritorio:  ABRIR-ESCRITORIO.bat
echo   Abrir en web:       ABRIR.bat
echo   Apagar:             APAGAR.bat
echo   Actualizar:         ACTUALIZAR.bat
echo.
echo   Tus proyectos se conservan aunque apagues el PC.
echo.
echo Abriendo la ventana nativa de BIMCost (no el navegador)...
call "%~dp0ABRIR-ESCRITORIO.bat"
exit /b 0

:missingFiles
color 0C
echo [ERROR] Faltan archivos del programa.
echo.
echo INSTALAR.bat debe permanecer dentro de la carpeta descomprimida,
echo junto a docker-compose.yml, Dockerfile, package.json y la carpeta src.
echo No copies solamente el archivo INSTALAR.bat al escritorio.
echo.
pause
exit /b 1

:dockerNotInstalled
color 0C
echo [ERROR] Windows no encuentra el comando Docker.
echo.
echo 1. Comprueba que instalaste Docker Desktop, no solo PostgreSQL.
echo 2. Reinicia Windows despues de instalar Docker Desktop.
echo 3. Abre Docker Desktop y acepta sus condiciones.
echo 4. Espera a ver "Engine running" y ejecuta este archivo otra vez.
echo.
echo Descarga oficial: https://www.docker.com/products/docker-desktop/
echo.
pause
exit /b 1

:composeMissing
color 0C
echo [ERROR] Docker esta instalado pero falta Docker Compose.
echo Actualiza Docker Desktop a la version mas reciente y reinicia Windows.
echo.
pause
exit /b 1

:dockerNotRunning
color 0C
echo.
echo [ERROR] Docker Desktop no pudo iniciar su motor.
echo.
echo Abre Docker Desktop y mira el mensaje que presenta. Lo mas habitual es:
echo - Windows necesita reiniciarse despues de instalar Docker.
echo - WSL 2 o la virtualizacion del procesador no estan habilitados.
echo - Docker espera que aceptes sus condiciones iniciales.
echo.
echo Ejecuta DIAGNOSTICO.bat para obtener informacion mas precisa.
echo.
pause
exit /b 1

:composeFailed
color 0C
echo.
echo [ERROR] Docker no pudo preparar BIMCost Quantity.
echo.
echo Guardando el detalle en:
echo %LOG_FILE%
(
  echo ================================================================
  echo BIMCost Quantity - Diagnostico de instalacion
  echo Fecha: %date% %time%
  echo ================================================================
  echo.
  echo --- Version de Docker ---
  docker version
  echo.
  echo --- Version de Docker Compose ---
  docker compose version
  echo.
  echo --- Estado de los contenedores ---
  docker compose ps -a
  echo.
  echo --- Configuracion interpretada ---
  docker compose config
  echo.
  echo --- Ultimos registros ---
  docker compose logs --no-color --tail 200
) > "%LOG_FILE%" 2>&1

echo.
echo Causas frecuentes:
echo - Docker Desktop no termino de iniciar.
echo - No hay conexion a Internet para descargar las imagenes.
echo - Un antivirus o firewall bloqueo Docker.
echo - El puerto 3000 esta ocupado por otro programa.
echo.
echo Ejecuta DIAGNOSTICO.bat o comparte BIMCost-DIAGNOSTICO.txt.
echo.
pause
exit /b 1

:appFailed
color 0E
echo.
echo [AVISO] Los contenedores arrancaron, pero la web no respondio a tiempo.
echo Guardando registros en %LOG_FILE% ...
docker compose logs --no-color --tail 250 > "%LOG_FILE%" 2>&1
echo.
echo Ejecuta DIAGNOSTICO.bat. El archivo BIMCost-DIAGNOSTICO.txt
 echo contiene la causa exacta.
echo.
pause
exit /b 1
