import type { NextConfig } from "next";

/**
 * El empaquetado de escritorio (BIMCost Desktop) necesita el servidor
 * autónomo en .next/standalone. Se activa solo al compilar para Electron:
 *     BIMCOST_DESKTOP_BUILD=1 npm run build
 * En la ejecución web normal se mantiene el arranque estándar.
 */
const desktopBuild = process.env.BIMCOST_DESKTOP_BUILD === "1";

const nextConfig: NextConfig = {
  ...(desktopBuild ? { output: "standalone" as const } : {}),

  // Modelos IFC grandes
  experimental: {
    serverActions: { bodySizeLimit: "200mb" },
  },
};

export default nextConfig;
