#!/usr/bin/env bash
# BIMCost Quantity — instalador para macOS / Linux
# Uso:  chmod +x INSTALAR.sh && ./INSTALAR.sh
set -e
echo "=================================================="
echo "  BIMCost Quantity — Instalación con un comando"
echo "=================================================="

if ! command -v docker >/dev/null 2>&1; then
  echo "[X] No se encontró Docker. Instala Docker Desktop primero:"
  echo "    https://www.docker.com/products/docker-desktop/"
  exit 1
fi

echo "[1/2] Construyendo la aplicación (la primera vez tarda varios minutos)..."
docker compose up -d --build

echo "[2/2] Listo. BIMCost Quantity está corriendo en http://localhost:3000"
(sleep 4; (xdg-open http://localhost:3000 2>/dev/null || open http://localhost:3000 2>/dev/null)) >/dev/null 2>&1 &
echo "Para apagarla: docker compose down"
